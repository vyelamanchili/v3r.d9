#include<stdio.h>
#include<conio.h>
int A();
int S();
char w[10];
int  index=0;
void main()
{
	int i;
	printf(�Enter string�);
	scanf(�%s�,w);
	i=S();
	if(i)
		printf(�Valid   statement�);
	else
		printf(�Invalid  statement�);
	getch();
}
int S()
{	int j;
	if(w[index]==�c�)
	{	index++;
		j=A();
		if(j)
		{
			index++;
			if(w[index]==�d�)
				index++;
			if(w[index]==�\o�)
				return 1;
			else
				return 0;
			}
			else
				return 0;
		}
		else
			return 0;
}
int A()
{
	if(w[index]==�a�)
		index++;
	if(w[index]==�b�)
		return 1;
	else
		index--;
	if(w[index]==�a�)
		return 1;
	else
		return 0;
}