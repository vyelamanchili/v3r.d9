package graphicshape;
import java.awt.*;
import java.lang.*;

public class GraphicShape extends Frame
{
	public int x,y;
	public GraphicShape()
	{
		Frame f=new Frame("User Choice Award");
		f.setSize(500,700);
		f.setVisible(true);
	}
}
class Rectangle extends GraphicShape
{
	int a,b;
	Rectangle(int a,int b)
	{
		this.a=a;
		this.b=b;
	}
	public void paint(Graphics g)
	{
		g.drawRect(x,y,a,b);
	}
}
class Triangle extends GraphicShape
{
	int a[]=new int[3];
	int b[]=new int[3];
	Triangle(int s[],int d[])
	{
		a[0]=x;b[0]=y;a[1]=s[0];b[1]=d[0];a[2]=s[1];b[2]=d[1];
	}
	public void paint(Graphics g)
	{
		g.drawPolygon(a,b,3);
	}
}
class Circle extends GraphicShape
{
	int r;
	Circle(int r)
	{
		this.r=r;
	}
	public void paint(Graphics g)
	{
		g.drawOval(x,y,r,r);
	}
}