// Exercise 7.15 Solution: Roll36.java
// Program simulates rolling two six-sided dice 36,000 times.

// Java core packages
import java.awt.*;
import java.awt.event.*;

// Java extension packages
import javax.swing.*;

public class Roll36 extends JApplet implements ActionListener {
   int total[];
   int totalRolls;
   JTextArea outputArea;
   JButton button;

   // set up GUI components, initialize array and roll dice
   public void init()
   {
      button = new JButton("Roll 36000 times");
      outputArea = new JTextArea();
      button.addActionListener( this );

      Container container = getContentPane();
      container.setLayout( new FlowLayout() );
      container.add( outputArea );
      container.add( button );

      totalRolls = 0;
      total = new int[ 13 ];

      for ( int index = 0; index < total.length; index++ )
         total[ index ] = 0;

      rollDice();

   }  // end method init

   // simulate rolling of dice 36000 times
   public void rollDice()
   {
      int face1, face2;

      for ( int roll = 1; roll <= 36000; roll++ ) {
         face1 = ( int ) ( 1 + Math.random() * 6 );
         face2 = ( int ) ( 1 + Math.random() * 6 );
         total[ face1 + face2 ]++;
      }

      totalRolls += 36000;

      // print table on text area
      String output = "Sum\tFrequency\tPercentage";

      // ignore subscripts 0 and 1
      for ( int k = 2; k < total.length; k++ ) {
         int percent = total[ k ] / ( totalRolls / 100 );

         output += "\n" + String.valueOf( k ) + "\t" +
            String.valueOf( total[ k ] ) + "\t%" + percent;
      }

      outputArea.setText( output );

   }  // end method roll2Dice

   // roll dice again
   public void actionPerformed( ActionEvent actionEvent )
   {
     for ( int i=0; i < total.length; i++ )
      total[ i ] = 0;

     totalRolls = 0;
      rollDice();

   }  // end method actionPerformed

}  // end class Roll36
