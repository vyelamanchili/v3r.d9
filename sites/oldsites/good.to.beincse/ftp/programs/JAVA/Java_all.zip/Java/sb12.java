//Syllabus Program :: 12:: Simulation of a Screen Saver
import java.lang.*;
import java.lang.Thread.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
/*<applet code=sb12.class height=500 width=700></applet>*/
public class sb12 extends Applet implements Runnable
{
	Thread t;
	String m="";
	String n="This is Simulation of a Screen Saver ";
	public void init()
	{
		t=new Thread(this);
		t.start();
	}
	 public void paint(Graphics g)
	{
		g.drawString(m,(int)(Math.random()*500),(int)(Math.random()*700));
    	}
    	public void run()
    	{
		char c;
		while(true)
		{
			m="";
			for(int i=0;i<n.length();i++)
			{
				c=n.charAt(i);
				m=m+c;
				repaint();
				try
				{
					Thread.sleep(500);
				}
				catch(InterruptedException e){}
			}
		}
	}
}