package shape;
import java.awt.*;

public class Triangle extends Shapeinh
{
	int v[]=new int[3];
	int y[]=new int[3];
	public Triangle()
	{
		v[0]=x[0];
		y[0]=x[1];
		v[1]=100;y[1]=200;v[2]=150;y[2]=150;
	}
	public void paint(Graphics g)
	{

		g.drawPolygon(v,y,3);
	}
}