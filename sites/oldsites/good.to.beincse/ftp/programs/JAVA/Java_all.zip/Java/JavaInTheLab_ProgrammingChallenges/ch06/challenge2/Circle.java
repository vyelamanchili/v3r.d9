// Exercise 6.48 Solution: Circle.java
// Program calulates the area of a circle.

// Java core packages
import java.awt.event.*;
import java.awt.*;

// Java extension packages
import javax.swing.*;

public class Circle extends JApplet implements ActionListener {
   JTextField inputField;
   JLabel prompt;

   // set up GUI components
   public void init()
   {
      prompt = new JLabel( "Enter the radius: " );
      inputField = new JTextField( 4 );
      inputField.addActionListener( this );

      Container container = getContentPane();
      container.setLayout( new FlowLayout() );
      container.add( prompt );
      container.add( inputField );
   }

   // obtain user input and call method circleArea
   public void actionPerformed( ActionEvent actionEvent )
   {
      showStatus( "" );

      int theRadius = Integer.parseInt( inputField.getText() );
      circleArea( theRadius );
   }

   // calculate area
   public void circleArea( int radius )
   {
      showStatus( "Area is " + Math.PI * radius * radius );
   }

} // end class Circle
