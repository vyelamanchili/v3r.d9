//prog7
import java.io.*;
import java.lang.*;
class prog7
{
	public static void main(String arg[]) throws IOException
	{
		slsppl person=new slsppl();
		int count[]=new int[9];
		DataInputStream in=new DataInputStream(System.in);
		for(int i=0;i<9;i++)
			count[i]=0;
		for(int i=0;i<10;i++)
		{
			int v=0;
			System.out.println("Enter the Gross Sales of person "+i);
			int x=Integer.parseInt(in.readLine());
			person.salary[i]+=person.commission(x);
			if(person.salary[i]>1000) count[8]++;
			for(int j=0;j<7;j++)
			if((person.salary[i])>200+v && (person.salary[i])<299+v)
			{
				count[j]++;
				v+=100;
			}
		}
		System.out.println("Salary Range	-	Persons in range");
		for(int i=0,v=0;i<8;i++,v+=100)
		System.out.println((200+v)+" - "+(299+v)+"	-	"+count[i]);
	}
}
class slsppl
{
	float salary[]=new float[10];
	slsppl()
	{
		for(int i=0;i<10;i++)
			salary[i]=200;
	}
	float commission(int items)
	{
		return((float)(0.09*(items)));
	}
}
