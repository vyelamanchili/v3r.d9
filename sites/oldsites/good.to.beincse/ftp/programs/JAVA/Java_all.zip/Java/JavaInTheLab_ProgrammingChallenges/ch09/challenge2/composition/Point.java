// Exercise 9.5 solution: Point.java
// Point class definition represents an x-y coordinate pair.

public class Point {
   private int x;  // x part of coordinate pair
   private int y;  // y part of coordinate pair

   // no-argument constructor
   public Point()
   {
      // implicit call to Object constructor occurs here
   } 

   // constructor
   public Point( int xValue, int yValue )
   {
      // implicit call to Object constructor occurs here
      x = xValue;  // no need for validation
      y = yValue;  // no need for validation
   } 
 
   // set x in coordinate pair
   public void setX( int xValue )
   {
      x = xValue;  // no need for validation
   } 

   // return x from coordinate pair
   public int getX()
   {
      return x;
   } 

   // set y in coordinate pair
   public void setY( int yValue )
   {
      y = yValue;  // no need for validation
   } 

   // return y from coordinate pair
   public int getY()
   {
      return y;
   } 

   // return String representation of Point3 object
   public String toString()
   {
      return "[" + getX() + ", " + getY() + "]";
   } 

} // end class Point

/**************************************************************************
 * (C) Copyright 1992-2003 by Deitel & Associates, Inc. and               *
 * Prentice Hall. All Rights Reserved.                                    *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
