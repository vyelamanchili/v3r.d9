package shapack;
import java.lang.*;
import java.awt.*;
import java.applet.*;
import javax.swing.*;
public class BaseShape extends JApplet
{
	int[] x=new int[3];
	int[] y=new int[3];
	JRadioButton jrb[]=new JRadioButton[3];
	ButtonGroup bg=new ButtonGroup();
	public void init()
	{
		jrb[0]=new JRadioButton("Circle");
		jrb[1]=new JRadioButton("Rectangle");
		jrb[2]=new JRadioButton("Triangle");
		bg.add(jrb[0]);
		bg.add(jrb[1]);
		bg.add(jrb[2]);
	//	bg.setAlignment(BOTTOM_ALIGNMENT);
		JPanel p=new JPanel();
		p.add(bg);
	}
	public BaseShape()
	{
		for(int i=0;i<3;i++)
		{
			x[i]=(int)(Math.random()*500);
			y[i]=(int)(Math.random()*500);
		}
	}
}
class ShpRect extends BaseShape
{
	public void paint(Graphics g)
	{
		g.drawRect(x[0],x[1],x[2],y[0]);
	}
}
class ShpOle extends BaseShape
{
	public void paint(Graphics g)
	{
		g.drawOval(x[0],x[1],x[2],x[2]);
	}
}
class ShpTringl extends BaseShape
{
	public void paint(Graphics g)
	{
		g.drawPolygon(x,y,3);
	}
}

