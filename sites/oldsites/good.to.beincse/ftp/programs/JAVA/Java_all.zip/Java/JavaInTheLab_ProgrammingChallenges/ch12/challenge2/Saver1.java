// Exercise 11.20 Solution: Saver1.java
// Program simulates a simple screen saver

// Java core packages
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;

// Java extension packages
import javax.swing.*;

public class Saver1 extends JFrame {
  
   // constructor sets window's title bar string and dimensions
   public Saver1()
   {
      super( "Saver1" );

      setSize( 300, 300 );
      show();
   }

   // draw lines
   public void paint( Graphics g )
   {
      super.paint( g );
       


      for ( int i = 0; i < 100; i++ ) {
         int x = ( int ) ( Math.random() * 300 );
         int y = ( int ) ( Math.random() * 300 );
         int x1 = ( int ) ( Math.random() * 300 );
         int y1 = ( int ) ( Math.random() * 300 );  
          
         g.setColor( new Color( ( float ) Math.random(),
            ( float ) Math.random(), ( float ) Math.random() ) );
         g.drawLine( x, y, x1, y1 );
      }
   
   } // end method paint

   // execute application
   public static void main( String args[] )
   {
      Saver1 application = new Saver1();

      application.setDefaultCloseOperation(
         JFrame.EXIT_ON_CLOSE );
   }

}  // end class Saver1
