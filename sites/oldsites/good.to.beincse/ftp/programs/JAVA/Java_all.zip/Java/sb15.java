//Syllabus Program :: 15 :: Exception Super-Sub Class Handling

import java.lang.*;
import java.io.*;

class SuperClass extends Exception
{
	SuperClass()
	{
		System.out.println("Superclass: automatic call");
	}
	SuperClass(String name)
	{
		super(name);
		System.out.println("Superclass: call using Super Method");
	}
}
class SubClass extends SuperClass
{
	String in;
	SubClass()
	{
		System.out.println("Subclass: automatic call");
	}
	SubClass(String input,String name)
	{
		super(name);
		System.out.println("Subclass: Object call");
		in=input;
	}
	boolean hasError()
	{
		if(in.length()>20)
		return(true);
		return(false);
	}
}
class SubClass2 extends SuperClass
{
	void print() throws IOException
	{
		String input;
		DataInputStream in=new DataInputStream(System.in);
		try
		{
			input=in.readLine();
			SubClass s=new SubClass(input,"Input Too Long");
			if(s.hasError())
				 throw s;	// after throw control doesnt return here
			System.out.println("No Error Occured and ");
		}
		catch(SuperClass e)
		{
			System.out.println("SubClassException Caught by SuperClass in "+e);
		}
	}
}
public class sb15
{
	public static void main(String a[])
	{
		SubClass2 n=new SubClass2();
		try
		{
			n.print();
		}
		catch(IOException e){}
		System.out.println("Returned to Main Program\n");
	}
}
/*
OUTPUT 1:
Superclass: automatic call
RANJEESH	//This is Input Given with limited length
Superclass: call using Super Method
Subclass: Object call
No Error Occured and
Returned to Main Program


OUTPUT 2:
Superclass: automatic call
RANJEESHWROTETHISPROGRAM	//This Input Violates the Condition of text length
Superclass: call using Super Method
Subclass: Object call
SubClassException Caught by SuperClass in SubClass: Input Too Long
Returned to Main Program

*/