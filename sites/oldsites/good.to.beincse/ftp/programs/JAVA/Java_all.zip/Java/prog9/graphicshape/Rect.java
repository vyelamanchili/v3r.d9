package graphicshape;
import java.lang.*;
import java.awt.*;
import graphicshape.*;
public class Rect extends GraphicShape
{
	public void paint(Graphics g)
	{
		g.drawRect(x[0],x[1],200,200);
	}
}