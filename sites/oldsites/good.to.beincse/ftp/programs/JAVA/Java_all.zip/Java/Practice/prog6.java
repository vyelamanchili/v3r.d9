//Syllabus Program :: 6:: to Print prime Numbers from 1 to 10000 and tell if any no enetered is prime
import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import java.lang.*;
//<applet code=prog6.java height=500 width=1000></applet>
public class prog6 extends Applet implements ActionListener
{
	TextField tf;
	public void init()
	{
		tf=new TextField(5);
		add(new Label("Enter a no. to test whether is prime or not :"));
		add(tf);
		tf.addActionListener(this);
	}
	public void paint(Graphics g)
	{
		if(tf.getText()!=null && isPrime(Integer.parseInt(tf.getText())))
			g.drawString(tf.getText()+" is Prime",900,25);
		int v=0,h=0;
		for(int i=2;i<10000;i++)
		{
			if(isPrime(i))
			{	v+=15;
				if(v>600){	h+=33; v=0; }
				g.drawString(String.valueOf(i),2+h,50+v);
			}
		}
	}
	public boolean isPrime(int x)
	{
		int count=0;
		for(int i=1;i<=x;i++)
		if(x%i==0)
			count++;
		if(count<=2)
			return(true);
		return(false);
	}
	public void actionPerformed(ActionEvent e)
	{
		repaint();
	}
}