// Exercise 3.10 Solution: Circle.java
// Program calculates the area, circumference
// and diameter for a circle

import java.awt.Graphics;   // import class Graphics
import javax.swing.*;       // import package javax.swing

public class Circle extends JApplet {

   // Strings for output
   String line1;
   String line2;
   String line3;

   // initialize applet by obtaining values from user
   public void init()
   {
      String input;   // String entered by user
      double radius;     // radius of circle

      // read from user as String
      input = JOptionPane.showInputDialog( "Enter radius:" );

      // convert number from type String to type int
      radius = Double.parseDouble( input );

      line1 = "Diameter is " + ( 2 * radius );
      line2 = "Area is " + ( Math.PI * radius * radius );
      line3 = "Circumference is " + ( 2 * Math.PI * radius );

   } // end method init

   // draw results on applet's background
   public void paint( Graphics g )
   {
      //draw line1 as a String at (25, 30)
      g.drawString( line1, 25, 30 );

      //draw line2 as a String at (25, 45)
      g.drawString( line2, 25, 45 );

      //draw line3 as a String at (25, 60)
      g.drawString( line3, 25, 60 );

   } // end method paint

} // end class Circle

