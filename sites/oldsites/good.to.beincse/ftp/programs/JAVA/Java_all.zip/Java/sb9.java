import java.lang.*;
import shapack.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import javax.swing.*;
//<applet code=sb9.class width=1000 height=750></applet>
public class sb9 extends BaseShape implements ActionListener
{
	BaseShape obj;
	public void init()
	{
		super.init();
		jrb.addActionListener(this);
	}
	public void paint(Graphics g)
	{
		super.paint(g);
	}
	public void actionPerformed(ActionEvent e)
	{
		JRadioButton src=(JRadioButton)e.getSource();
		if(src=="Circle")
			obj=new ShpOle();
		if(src=="Rectangle")
			obj=new ShpRect();
		if(src=="Triangle")
			obj=new Tringle();
		repaint();
	}
}
