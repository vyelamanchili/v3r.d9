import java.awt.*;
import javax.swing.*;
/* <applet code = "jlab2.class" width = 250 height =200>
   </applet>
   */

   public class jlab2 extends JApplet
    {
     public void init()
      {
       Container c = getContentPane();
       JLabel j1 = new JLabel("kishore");
       c.add(j1);
       }
       }
