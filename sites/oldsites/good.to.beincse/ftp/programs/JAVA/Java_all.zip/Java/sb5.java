//Syllabus Program # 5:: Write an application to fing the pythogorean triads 
//among the first 500 no.s
import java.lang.*;
class sb5
{
	public static void main(String args[])
	{
		System.out.println("The Pythogorean Triads are :");
		for(int i=1;i<=500;i++)
		for(int j=1;j<=500;j++)
		for(int k=1;k<=500;k++)
              	  if((i*i) + (j*j) == (k*k))
		     System.out.println("combi of("+i+","+j+","+k+")");
	}
}