package shape;
import java.awt.*;
import shape.*;

public class Rect extends Shapeinh
{
	public void paint(Graphics g)
	{
		g.drawRect(x[0],x[1],100,200);
	}
}



