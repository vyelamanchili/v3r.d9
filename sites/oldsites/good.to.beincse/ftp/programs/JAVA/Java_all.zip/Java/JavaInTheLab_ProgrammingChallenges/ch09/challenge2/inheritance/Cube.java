// Exercise 9.5 solution: Cube.java
// Cube class definition.

public class Cube extends Square{
   private double depth;  // Cube's depth

   // no-argument constructor
   public Cube()
   {
      // implicit call to Square constructor occurs here
   } 

   // constructor
   public Cube( int xValue, int yValue, double sideValue )
   {
      super( xValue, yValue, sideValue );
      setDepth( sideValue );
   } 

   // set Cube's depth
   public void setDepth( double depthValue )
   {
      depth = ( depthValue < 0.0 ? 0.0 : depthValue );
   } 

   // get Cube's depth
   public double getDepth()
   {
      return depth;
   } 

   // calculate Cube area
   public double getArea()
   {
      return 6 * super.getArea();
   } 

   // calculate Cube volume
   public double getVolume()
   {
      return  super.getArea() * getDepth();
   } 

   // return String representation of Cube object
   public String toString()
   {
      return super.toString() + "; Depth = " + getDepth();
   } 
	
} // end class Cube

/**************************************************************************
 * (C) Copyright 1992-2003 by Deitel & Associates, Inc. and               *
 * Prentice Hall. All Rights Reserved.                                    *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/