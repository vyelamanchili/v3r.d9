// Exercise 10.8 Solution: TwoDimensionalShape.java
// Definition of class TwoDimensionalShape.

public abstract class TwoDimensionalShape extends Shape {
   private double dimension1, dimension2;

   // constructor
   public TwoDimensionalShape( int x, int y, double d1, double d2 )
   {
      super( x, y );
      dimension1 = d1;
      dimension2 = d2;
   }

   // set methods
   public void setDimension1( double d )
   {
      dimension1 = d;
   }

   public void setDimension2( double d )
   {
      dimension2 = d;
   }

   // get methods
   public double getDimension1()
   {
      return dimension1;
   }

   public double getDimension2()
   {
      return dimension2;
   }

   // abstract method
   public abstract double area();

}  // end class TwoDimensionalShape

