// Exercise 10.8 Solution: Sphere.java
// Definition of class Sphere.

public class Sphere extends ThreeDimensionalShape {

   // constructor
   public Sphere( int x, int y, double radius )
   {
      super( x, y, radius, radius, radius );
   }

   // overridden methods
   public String getName()
   {
      return "Sphere";
   }

   public double area()
   {
      return 4 * Math.PI * super.getDimension1() * super.getDimension1();
   }

   public double volume()
   {
      return 4.0 / 3.0 * Math.PI * super.getDimension1() *
         super.getDimension1() * super.getDimension1();
   }

   public String toString()
   {
      return "(" + super.getX() + ", " + super.getY() + ") " + "radius: " + 
         super.getDimension1();
   }

   // set method
   public void setRadius( double radius )
   {
      super.setDimension1( radius );
   }

   // get method
   public double getRadius()
   {
      return super.getDimension1();
   }

} // end class Sphere
