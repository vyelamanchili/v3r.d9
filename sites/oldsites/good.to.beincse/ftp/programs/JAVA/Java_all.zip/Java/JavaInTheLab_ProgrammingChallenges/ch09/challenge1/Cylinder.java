// Exercise 9.3 solution: Cylinder.java
// Cylinder class definition.

public class Cylinder {
   private double height;  // Cylinder's height
   private Circle4 circle;

   // no-argument constructor
   public Cylinder()
   {
      circle = new Circle4( 0, 0, 0 );
      setHeight( 0 );
   } 

   // constructor
   public Cylinder( int xValue, int yValue, double radiusValue,
      double heightValue )
   {
      circle = new Circle4( xValue, yValue, radiusValue );
      setHeight( heightValue );
   } 

   // set Cylinder's height
   public void setHeight( double heightValue )
   {
      height = ( heightValue < 0.0 ? 0.0 : heightValue );
   } 

   // get Cylinder's height
   public double getHeight()
   {
      return height;
   } 

   // set x
   public void setX( int x )
   {
      circle.setX( x );
   }

   // return x
   public int getX()
   {
      return circle.getX();
   }

   // set y
   public void setY( int y )
   {
      circle.setY( y );
   }

   // return y
   public int getY()
   {
      return circle.getY();
   }

   // set radius
   public void setRadius( double radiusValue )
   {
      circle.setRadius( radiusValue );
   } 

   // return radius
   public double getRadius()
   {
      return circle.getRadius();
   } 

   // return diameter
   public double getDiameter()
   {
      return circle.getDiameter();
   } 

   // return circumference
   public double getCircumference()
   {
      return circle.getCircumference();
   } 

   // calculate Cylinder area
   public double getArea()
   {
      return 2 * circle.getArea() + 
         circle.getCircumference() * getHeight();
   } 

   // calculate Cylinder volume
   public double getVolume()
   {
      return  circle.getArea() * getHeight();
   } 

   // return String representation of Cylinder object
   public String toString()
   {
      return  circle.toString() + "; Height = " + getHeight();
   } 
	
} // end class Cylinder

/**************************************************************************
 * (C) Copyright 1992-2003 by Deitel & Associates, Inc. and               *
 * Prentice Hall. All Rights Reserved.                                    *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/