// Exercise 3.16 Solution: Draw3.java
// Program draws an oval inside a rectangle on the applet.

// Java core packages
import java.awt.Graphics;   // import class Graphics

// Java extension packages
import javax.swing.*;       // import package javax.swing

public class Draw3 extends JApplet {

   // draw shapes on applet's background
   public void paint( Graphics g )
   {
      // draw rectangle starting at (10, 10) that is 50
      // pixels wide and 50 pixels tall
      g.drawRect( 10, 10, 50, 50 );

      // draw oval starting at (10, 10) that is 50 pixels
      // wide and 50 pixels tall
      g.drawOval( 10, 10, 50, 50 );
   }

} // end class Draw3
