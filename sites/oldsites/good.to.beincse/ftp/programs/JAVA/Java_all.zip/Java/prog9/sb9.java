import java.lang.*;
import java.awt.event.*;
import java.awt.*;
//<applet code=sb9.class height=500 width=700></applet>
public class sb9 extends graphicshape.GraphicalShape implements ActionListener
{
	TextFielld t;Label l;
	/*public void init()
	{
		t=new TextField(10);
		l=new Label("Enter Ur Choice(1,2 or 3) :");
		add(l);
		add(t);
	}*/

	public static void main(String a[])
	{
		GraphicalShape





