package shape;
import shape.*;
import java.awt.*;

public class ole extends Shapeinh
{
	public void paint(Graphics g)
	{
		g.drawOval(x[0],x[1],100,100);
	}
}