// Exercise 2.19 Solution: Circle.java
// Program that calculates area, circumference
// and diameter for a circle.

// Java extension packages
import javax.swing.JOptionPane;

public class Circle {

   // main method begins execution of Java application
   public static void main( String args[] )
   {
      String input;    // string entered by user
      String result;   // output display string
      int radius;      // radius of circle

      // read from user as a string
      input =
         JOptionPane.showInputDialog( "Enter radius:" );

      // convert number from type String to type int
      radius = Integer.parseInt( input );

      result = "Diameter is " + ( 2 * radius ) +
         "\nArea is " + ( Math.PI * radius * radius ) +
         "\nCircumference is " + ( 2 * Math.PI * radius );

      // Display results
      JOptionPane.showMessageDialog(
         null, result, "Calculation Results",
         JOptionPane.INFORMATION_MESSAGE );

      System.exit( 0 );  // terminate application

   }  // end method main

}  // end class Circle