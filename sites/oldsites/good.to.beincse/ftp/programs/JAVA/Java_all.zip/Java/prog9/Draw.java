// Program to draw shapes
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import graphicshape.*;

public class Draw extends GraphicShape implements ListSelectionListener
{
	 // setup the graphical user interface components
    // and initialize variables
    	JList shapeList;
    	String shape;
		JLabel shapeLabel;
	    JButton clearButton, erasePointsButton;
	    String [] shapes = { "Circle", "Rectangle","Triangle" };
		public void init()
		{
			int i;
			DefaultListModel shapeListModel = new DefaultListModel();

			shapeLabel = new JLabel( "Shape: ");

			clearButton = new JButton( "Clear" );
			erasePointsButton = new JButton( "Erase Points" );

			for ( i = 0; i < shapes.length; i++ )
			{
				add(shapeListModel.addElement( shapes[i] ));
			}
	        shapeList = new JList( shapeListModel );

	        Container c = getContentPane();
	        c.setLayout( new FlowLayout() );

	        c.add(shapeLabel);
	        c.add(shapeList);
	        c.add(clearButton);
	        c.add(erasePointsButton);

	        shapeList.addListSelectionListener( this );
	}
	// process user's action on the list selections
    public void valueChanged(ListSelectionEvent e)
    {
        int index;
		 if (e.getSource() == shapeList)
        {
            index = shapeList.getSelectedIndex();
            if ( index >= 0 )
            {
				shape=shapes[index];
		 	}
        }
    }
    public void paint( Graphics g )
    {
		if(shape.equals("Circle"))
			(new Circle(50)).paint(g);

		if(shape.equals("Rectangle"))
			(new Rectangle(100,100)).paint(g);

		if(shape.equals("Trianglele"))
		{
			int a[]={100,200};
			int b[]={200,300};
			(new Triangle(a,b)).paint(g);
    	}
	}

}
