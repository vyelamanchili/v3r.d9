//Syllabus Program 11::String Tokenizers

import java.util.*;
import java.io.*;

class sb11
{ 
	public static void main(String a[]) throws IOException
	{
		StringTokenizer S;
		DataInputStream in=new DataInputStream(System.in);
		String m="",n,o=in.readLine();
		S=new StringTokenizer(o);
		while(S.hasMoreTokens())
		{
			n=S.nextToken();
			m=n+" "+m;
		}	
		System.out.println(m);
	}
}
/*OUTPUT:
This is a program for String Tokenizers

Tokenizers String for program a is This */
