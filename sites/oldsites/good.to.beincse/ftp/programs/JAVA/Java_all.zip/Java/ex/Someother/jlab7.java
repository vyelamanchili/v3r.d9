import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
/* <applet code = "jlab7.class" width = 250 height =200>
   </applet>
   */

   public class jlab7 extends JApplet  implements ItemListener
    {
      JTextField t1;
      JComboBox cb;
     public void init()
      {
       Container c = getContentPane();
       c.setLayout(new FlowLayout());
       t1 =  new JTextField(5);
       c.add(t1);
       cb = new JComboBox();
       cb.addItem("C");
       cb.addItem("C++");
       cb.addItem("Java");
       cb.addItem("Pascal");
       c.add(cb);
       cb.addItemListener(this);

       }
       public void itemStateChanged(ItemEvent e)
        {
          //JComboBox x = (JComboBox)  e.getItem();
          String s = (String) e.getItem();
          t1.setText(s);
          }
        }
     

