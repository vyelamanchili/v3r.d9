// Exercise 10.8 Solution: Circle.java
// Definition of class Circle.

public class Circle extends TwoDimensionalShape {

   // constructor
   public Circle( int x, int y, double radius )
   {
      super( x, y, radius, radius );
   }

   // overridden methods
   public String getName()
   {
      return "Circle";
   }

   public String toString()
   {
      return "(" + super.getX() + ", " + super.getY() + ") " + "radius: " + 
         super.getDimension1();
   }

   public double area()
   {
      return Math.PI * super.getDimension1() * super.getDimension1();
   }

   // set method
   public void setRadius( double radius )
   {
      super.setDimension1( radius );
   }

   // get method
   public double getRadius()
   {
      return super.getDimension1();
   }

}  // end class Circle
