import java.util.*;  // for Date

public class SpeedySlow {

  public static void importantFunction() throws Exception {
    throw new Exception();
  }

  public static void main(String[] args) {
    long startTime = (new Date()).getTime();
    for (int i = 0; i < 100000; i++)
      try {
        importantFunction();
      } catch (Exception e) {}
    long stopTime = (new Date()).getTime();
    System.out.println("Time: " + (stopTime - startTime));
  }
}
