import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
/* <applet code = "jlab5.class" width = 250 height =200>
   </applet>
   */

   public class jlab5 extends JApplet  implements ItemListener
    {
      JTextField t1;
      JCheckBox c1,c2,c3;
     public void init()
      {
       Container c = getContentPane();
       c.setLayout(new FlowLayout());
       t1 =  new JTextField(5);
       c.add(t1);
       c1 = new JCheckBox("C ");
       c2 = new JCheckBox("C++");
       c3 = new JCheckBox("Java");

       c1.addItemListener(this);
       c.add(c1);
       c2.addItemListener(this);
       c.add(c2);
       c3.addItemListener(this);
       c.add(c3);
       }
       public void itemStateChanged(ItemEvent e)
        {
          JCheckBox x = (JCheckBox) e.getItem();
          t1.setText(x.getText());
          }
     }

