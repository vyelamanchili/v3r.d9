#include<stdio.h>
#include<graphics.h>
#include<conio.h>
#include<stdlib.h>
int m,n,str[50],ar[30];
static int z,pagef=0;
char c[10];
int i,j,r=0,x=50,y=100,a=100,b=150,e,k;
void main()
{
 int gdriver = DETECT,gmode;
 clrscr();
 initgraph(&gdriver,&gmode,"C:\\tc\\bg");
 printf("\n\t Enter the no. of pages in segments & no. of frames");
 scanf("%d%d",&m,&n);
 printf("\n\t Enter the sequence");
 for(i=0;i<m;i++)
 scanf("%d",str[i]);
 for(i=0;i<n;i++)
 ar[i]=-1;
 for(i=0;i<n;i++)
 {
  z=1;
   for(j=0;j<n;j++)
   if(ar[j]==str[i])
   z=0;
   if(z)
   {
    ar[r]=str[i];
    r++;
    if(r==n)
    r=0;
   }
   pagef++;
   e=y+10;
   if(z)
   {
    for(k=0;k<n;k++)
    {
     rectangle(x+10,y,a,b);
     if(ar[k]==-1)
     {
      itoa(ar[k],c,10);
      outtextxy(x+20,e,c);
      e=e+50;
      }
      b=b+50;
      }
      x=x+50,a=a+50,y=100,b=150;
      }
      if(x>500)
      x=50,a=100,y=y+200,b=b+250;
      }
      outtextxy(100,300,"The no. of pagefaults");
      itoa(pagef,c,10);
      outtextxy(330,300,c);
      getch();
      }









