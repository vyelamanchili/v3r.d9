			   /*FIRST FIT*/
			   /*02311A1293*/
#include<stdio.h>
#include<alloc.h>
typedef struct lnkdlist *list;
struct lnkdlist
{
 int info;
 int flag;
 int sloc;
 int eloc;
 int size;
 list next;
}
main()
{
 int ch;
 list mknode();
 list insert();
 list delete();
 void display();
 list head;
 list tail;
 clrscr();
 head=mknode();
 tail=mknode();
 tail->info=0;
 head->sloc=0;
 head->eloc=20;
 head->info=98;
 head->flag=1;
 head->next=tail;
 head->size=20;
 tail->sloc=head->eloc;
 tail->next=NULL;
 tail->size=620;
 tail->eloc=640;
 tail->flag=0;
 do{
    printf("1.insert\t2.delete\t3.display\texit\n");
    printf("enter the choice");
    scanf("%d",&ch);
    switch(ch)
     {
      case 1:
	     head=insert(head);
	     break;
      case 2:
	     head=delete(head);
	     break;
      case 3:
	     display(head);
	     break;
      case 4:
	     exit(0);
     }
   }while(ch!=4);
}
list mknode()
{
 list new;
 new=(list)malloc(sizeof(struct lnkdlist));
 new->next=NULL;
 return(new);
}
list insert(list head)
{
 list temp,new,prev;
 int no,sz;
 printf("enter the job number and its size");
 scanf("%d %d",&no,&sz);
 temp=head;
 while(temp->next!=NULL)
  {
   while(temp->flag==1)
    {
     prev=temp;
     temp=temp->next;
    }
   if(temp->flag==0 && sz<=temp->size)
    {
     temp->info=no;
     temp->size=sz;
     temp->sloc=prev->eloc;
     temp->eloc=temp->sloc+temp->size;
     temp->flag=1;
     prev=temp;
     new=mknode();
     temp->next=new;
     new=mknode();
     temp->next=new;
     new->flag=0;
     new->sloc=temp->eloc;
     new->eloc=640;
     new->size=new->eloc-new->sloc;
     break;
    }
 break;
}
return(head);
}
list delete(list head)
{
 list temp;
 int no;
 printf("enter the job to be deleted");
 scanf("%d",&no);
 temp=head;
 while(temp->next!=NULL)
  {
   temp=temp->next;
   if(temp->info==no)
   temp->flag=0;
  }
  return(head);
}
void display(list head)
{
 list temp;
 temp=head;
 printf("--------------------\n");
 printf("JOB ALLOCATION TABLE\n");
 printf("--------------------\n");
 printf("jobno\tjobsize\tjobloc\n");
 while(temp->next!=NULL)
  {
   if(temp->flag==0)
   temp=temp->next;
   printf("%d\t%d\t%d\n",temp->info,temp->size,temp->sloc);
   temp=temp->next;
  }
}



