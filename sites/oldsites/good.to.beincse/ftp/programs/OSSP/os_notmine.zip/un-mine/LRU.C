#include<stdio.h>
#include<conio.h>
 void main(void)
 {
  int a[20],b[20],i=0,j,k,succ=0,fault=0,n,flag=0,count,x=0;
  clrscr();
  printf("Enter the number of frames\n");
  scanf("%d",&n);
  printf("Enter the pages\n To terminate press -1\n");
  do
  {
     scanf("%d",&a[i]);
     i++;
  }while(a[i-1]!=-1);
  for(i=0;i<n;i++)
    b[i]=0;

   x=n-1;
  for(i=0;a[i]!=-1;i++)
  {
     for(j=0;j<n;j++)
     if(a[i]==b[j])
     {
       flag=1;
       count=j;
       break;
     }
     else
      flag=0;

      if(flag==0)
      {
	if(x==0)
	{
	   for(k=0;k<n-1;k++)
	    b[k]=b[k+1];

	    b[k]=a[i];
	}
	else
	{
	   for(k=0;k<n-1;k++)
	    b[k]=b[k+1];
	   b[k]=a[i];
	    x--;
	}
	   fault++;
	   printf("F\t\t");

      }
      if(flag==1)
      {
	 for(k=count;k<n-1;k++)
	   b[k]=b[k+1];
	   b[k]=a[i];
	 succ++;
	 printf("S\t\t");
      }
      for(k=0;k<n;k++)
       printf("%d\t",b[k]);
       printf("\t\t%d<-",a[i]);
       printf("\n\n");
  }
  printf("The number of Successes is: %d \n The number of Faults is: %d\n",succ,fault);
  getch();
 }