#include<stdio.h>
#include<conio.h>
 void main(void)
 {
     int a[20],i=0,j,n,k,succ=0,fault=0,flag=0,x=0,b[20],count=0,count1[5],temp=0,count2;
     clrscr();
     printf("Enter the number of frames\n");
     scanf("%d",&n);
     printf("Enter the pages array \n To terminate press -1\n");
     do
     {
	 scanf("%d",&a[i]);
	   i++;
     }while(a[i-1]!=-1);

       printf("\n");
	  x=n-1;
	for(i=0;i<n;i++)
	{
	  b[i]=0;
	  count1[i]=0;
	}
	   for(i=0;a[i]!=-1;i++)
	   {
	       if(x==-1)
		{
		      for(j=0;j<n;j++)
		       {
			   if(a[i]==b[j])
			   {
			      flag=1;
			       break;
			   }

			   else
			   {
				   for(k=temp;a[k]!=-1;k++)
				    if(a[k]==b[j])
				    {
					  flag=0;
					  count++;
					 count1[j]=1;
					  count2=j;
					    break;
				    }
				    else
				    count1[j]=0;
			   }
		       }
				 if(count==n && flag==0)
				 {
				     b[count2]=a[i];
				     temp++;
				 }

				 else if(flag==0)
				 {
				     for(j=0;j<n;j++)
				     if(count1[j]==0)
				       b[j]=a[i];
					temp++;
				 }
				      count=0;
				    if(flag==1)
				    {
					  succ++;
				       printf("S\t\t");
				    }

				   if(flag==0)
				    {
					 fault++;
					printf("F\t\t");
				    }
		}
		else
		{
			for(j=0;j<n;j++)
			if(a[i]!=b[j])
			  flag=1;
			else
			{
			  flag=0;
			  break;
			}
			       if(flag==1)
				{
					for(k=0;k<n-1;k++)
					  b[k]=b[k+1];

					    b[k]=a[i];
					     fault++;
						x--;
						temp++;
					   printf("F\t\t");
				}
				if(flag==0)
				{
					succ++;
					printf("S\t\t");
				}
	   }
     for(j=0;j<n;j++)
     printf("%d\t ",b[j]);
     printf("\t\t<-%d",a[i]);
     printf("\n");
  }
  printf("\n");
  printf("The Number of Successes are: %d\n",succ);
  printf("The Number of Faults are: %d\n",fault);
  getch();
 }