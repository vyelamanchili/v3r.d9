
//optimal
#include<stdio.h>
#include<graphics.h>
#include<conio.h>
#include<stdlib.h>
int m,n,str[50],ar[30],j;
static int z,pagef;
char ch[30];
int i,r=0,x=50,y=100,a=100,b=150,e,k,cnt[10],c,v,max,max1,temp=0;
void main(){
		 int gd=DETECT,gm;
		 initgraph(&gd,&gm,"c:\\tc\\bgi ");
		 printf("enter no of pages & no of frames\n");
		 scanf("%d%d",&m,&n);
		 printf("enter sequence\n");
		 for(i=0;i<m;i++)
		 scanf("%d",&str[i]);
		 for(j=0;j<n;j++)
		 ar[j]=-1;
		 for(i=0;i<m;i++)
		 {
		  z=1;
		  temp=0;
		  for(j=0;j<n;j++)
		  cnt[j]=0;
		  for(j=0;j<n;j++)
		  {
		 if(ar[j]==str[i])
		 { z=0;break;}}
		  if(z){
		  for(j=0;j<n;j++){
		  if(ar[j]==-1){z=2;max1=-1;break;}}}
		   if(z==1){

			for(c=0;c<n;c++)
			{
			 for(v=i+1;v<m;v++)
			 {
			 if(str[v]==ar[c])
			  {cnt[c]=v+1;break;}
			  }
			  if(cnt[c]==0)cnt[c]=m;
		.	 }
			 }
			 if(z==1){
			 max=cnt[0];max1=ar[0];
			 for(c=1;c<n;c++)
			 { if(cnt[c]>max)
			  {  max=cnt[c];max1=ar[c];} }
			 //if(temp==0)max=ar[0];

			}
	     //	     }
		 // }
       //	  }
		  if(z){
		  for(c=0;c<n;c++)
		  {
		  if(ar[c]==max1)
		   {ar[c]=str[i];break;}

		// }

		  pagef++;
		    }
		  e=y+10;
					for(k=0;k<n;k++)
					  {
			  rectangle(x+10,y,a+10,b);
				  if(ar[k]!=-1)
			  {
			   itoa(ar[k],ch,10);
			   outtextxy(x+20,e,ch);
			   e+=50;
			   }
			   b+=50;

			   }
	       }
			   x+=50;
			   a+=50;
			   y=100;
			   b=150;
			  // if(x>500)
			  // x=50;a=100;y+=200;b+=50;


			 }
			   outtextxy(100,300,"the no of page faults:");
			   itoa(pagef,ch,10);
			   outtextxy(330,300,ch);
			   getch();
			   closegraph();
			   restorecrtmode();
    }			   }
