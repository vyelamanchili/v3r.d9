	  /*	MEMORY MANAGMENT ALGORITHM	*/
		/*	BEST FIT	*/


#include<stdio.h>
struct fit
	{
	int jno;
	int sloc;
	int eloc;
	int flag;
	struct fit *next;
	}*ptr,*ptr1,*t,*ptr2;

int c,i,j,ch,temp,jno,jsize,b;
void main()
{
void add();
void map();
void del();
void table();
clrscr();
ptr1=(struct fit *)malloc(sizeof(struct fit));
ptr=(struct fit *)malloc(sizeof(struct fit));
ptr1->sloc=0;
ptr1->eloc=20;
ptr1->flag=1;
ptr1->jno=0;
ptr->sloc=20;
ptr->eloc=640;
ptr->jno=0;
ptr->flag=0;
ptr1->next=ptr;
ptr->next=NULL;
while(1)
	{
	printf("\nMENU\n");
	printf("1.ADD\n2.DELETE\n3.MEMORY MAP\n4.MEMORY TABLE\n5.EXIT\n");
	printf("ENTER UR CHOICE:");
	scanf("%d",&ch);
	switch(ch)
		{
		case 1: add();
			break;
		case 2: del();
			break;
		case 3: map();
			break;
		case 4: table();
			break;
		case 5: exit(0);
		default: printf("wrong choice\n");
		}
	}
}

void add()
{
ptr=ptr1->next;
ptr2=NULL;
printf("Enter jno,jsize:");
		scanf("%d%d",&jno,&jsize);
while(ptr!=NULL)
{
if(ptr->next==NULL && ptr->flag==1 && ptr2==NULL)
			{
			printf("not enough space\n");
			getch();
			return;
			}
if(ptr->flag==0)
	{
	if(jsize<=ptr->eloc - ptr->sloc)
		{
		if((ptr->eloc-ptr->sloc)<=(ptr2->eloc-ptr2->sloc))
			{
			ptr2=ptr;
			ptr=ptr->next;
			}
		else
			ptr=ptr->next;
		}
	else
		ptr=ptr->next;
	}
else
	ptr=ptr->next;
}

	if(ptr2==NULL)
			{
			printf("Not enough space\n");
			getch();
			return;
			}
	if(jsize==(ptr2->eloc - ptr2->sloc))
		{
		ptr2->jno=jno;
		ptr2->flag=1;
		c++;
		return;
		}

	if(jsize<(ptr2->eloc - ptr2->sloc))
		{
		temp=ptr2->eloc;
		t=(struct fit *)malloc(sizeof(struct fit));
		ptr2->jno=jno;
		ptr2->eloc=ptr2->sloc + jsize;
		t->sloc=ptr2->eloc;
		t->eloc=temp;
		ptr2->flag=1;
		t->next=ptr2->next;
		ptr2->next=t;
		t->jno=0;
		t->flag=0;
		c++;
		return;
		}
}

void map()
{
ptr=ptr1;
while(ptr!=NULL)
	{
	if(ptr->sloc==0)
		{
		printf("os  os  ");
		ptr=ptr->next;
		}
	else
		{
		b=(ptr->eloc-ptr->sloc)/10;
		for(i=1;i<=b;i++)
			printf("%d  ",ptr->jno);

		ptr=ptr->next;
		}
	}
}

void del()
{
if(c==0)
	{
	printf("THERE IS NO JOB IN MEMORY TO DELETE\n");
	return;
	}
ptr=ptr1;
printf("ENTER JOBNO TO BE DELETED:\n");
scanf("%d",&b);
while(ptr!=NULL)
	{
	if((ptr->next->jno)==b)
		{
		if(ptr->flag==0)
			{
			if(ptr->next->next->flag==0)
				{
				ptr->eloc=ptr->next->next->eloc;
				ptr->next=ptr->next->next->next;
				ptr=NULL;
				c--;
				}
			else
				{
				ptr->eloc=ptr->next->eloc;
				ptr->next=ptr->next->next;
				ptr=NULL;
				c--;
				}
			}
		 else
			{
			if(ptr->next->next->flag==0)
				{
				ptr->next->jno=0;
				ptr->next->flag=0;
				ptr->next->eloc=ptr->next->next->eloc;
				ptr->next->next=ptr->next->next->next;
				ptr=NULL;
				c--;
				}
			else
				{
				ptr->next->jno=0;
				ptr->next->flag=0;
				ptr=NULL;
				c--;
				}
			}
		}
		else
			{
			if(ptr->next->next==NULL)
				{
				printf("JOB NOT AVAILABLE\n");
				return;
				}
			else
				ptr=ptr->next;
			}
	}
}

void table()
{
int count=1;
ptr=ptr1->next;
printf("\nMEMORY ALLOCATION TABLE\n");
printf("JOB NO\tJOB SIZE\tAREA ALLOCATION\n");
while(ptr!=NULL)
	{
	if(ptr->flag==1)
		printf("%d\t%d\t\t%d\n",ptr->jno,(ptr->eloc-ptr->sloc),ptr->sloc);

	ptr=ptr->next;
	}
printf("\nFREE AREA TABLE\n");
printf("PARTITION NO\tAREA SIZE\tAREA ALLOCATION\n");
ptr=ptr1->next;
while(ptr!=NULL)
	{
	if(ptr->flag==0)
		{
		printf("%d\t\t%d\t\t%d\n",count,(ptr->eloc-ptr->sloc),ptr->sloc);
		count++;
		}
	ptr=ptr->next;
	}
}