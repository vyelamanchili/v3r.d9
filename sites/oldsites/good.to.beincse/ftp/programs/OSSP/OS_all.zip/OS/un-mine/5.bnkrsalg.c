		     /*BANKER'S ALGORITHM*/
#include<stdio.h>
main()
{
 int max[5][3],all[5][3],i,j,n,req[3],rvec[3],avec[3],work[3],count=0,finish[5],need[5][3];
 clrscr();
 printf("enter the values for resource vector");
 for(j=0;j<3;j++)
  {
   scanf("%d",&rvec[j]);
  }
 for(i=0;i<5;i++)
  {
   printf("enter the maximum resources for the process p%d:",i);
   scanf("%d %d %d",&max[i][0],&max[i][1],&max[i][2]);
  }
 for(i=0;i<5;i++)
  {
   printf("enter the allocated resources for the process p%d:",i);
   scanf("%d %d %d",&all[i][0],&all[i][1],&all[i][2]);
  }
 printf("enter the values for the available resource vector");
 for(j=0;j<3;j++)
  {
   scanf("%d",&avec[j]);
   work[j]=avec[j];
  }
 for(i=0;i<5;i++)
  {
   for(j=0;j<3;j++)
    {
     need[i][j]=max[i][j]-all[i][j];
    }
  }
 for(i=0;i<5;i++)
  {
   finish[i]=0;
  }
 printf("the safety sequence is:\n");
 while(count<5)
  {
   for(i=0;i<5;i++)
    {
     for(j=0;j<3;j++)
     if(need[i][j]<=work[j] && finish[i]==0)
      {
       for(j=0;j<3;j++)
       work[j]+=all[i][j];
       printf("p%d\t",i);
       finish[i]=1;
       count++;
      }
      else
      break;
    }
  }
printf("\nenter the process that requests for resources:p");
scanf("%d",&n);
printf("enter the request resources");
scanf("%d %d %d",&req[0],&req[1],&req[2]);
for(j=0;j<3;j++)
 {
  if(req[j]<=need[n][j])
   {
    if(req[j]<=avec[j])
     {
      avec[j]-=req[j];
      all[n][j]+=req[j];
      need[n][j]-=req[j];
     }
     else
     break;
   }
 }
count=0;
for(i=0;i<5;i++)
 {
  finish[i]=0;
 }
while(count<5)
{
 for(i=0;i<5;i++)
  {
   for(j=0;j<3;j++)
    {
     if(need[i][j]<=avec[j] && finish[i]==0)
      {
       for(j=0;j<3;j++)
       avec[j]+=all[i][j];
       printf("p%d\t",i);
       finish[i]=1;
       count++;
      }
      else
      break;
    }
  }
}
  getch();
}