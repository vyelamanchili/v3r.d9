#include<stdio.h>
#define size 10
int cq[size];
int f=0,r=0;
void insert(),del(),display();
main()
{
	int ch;
	void menu();
	menu();
	printf("\nEnter ur Choice\n:");
	scanf("%d",&ch);
	while(ch!=4)
	{
		switch(ch)
		{
			case 1 :insert();
				break;
			case 2 :del();
				break;
			case 3 :display();
				break;
			default:printf("\nUNKNOWN OPTION\n");
		}
		menu();
		printf("\nEnter Ur Choice\n:");
		scanf("%d",&ch);
	}
	printf("\n\nBYE BYE\n\n\n\n");
}
void menu()
{
	printf("\n\n1.Insert an Element\n");
	printf("2.Delete an Element\n");
	printf("3.Display The elements\n");
	printf("4.Exit\n");
}

void insert()
{
	int e;
	if(f==((r+1)%size))
	printf("\nQUEUE IS FULL\n");
	else
	{       printf("\nr=%d\nf=%d\n",r,f);
		printf("\nEnter the Element\n");
		scanf("%d",&e);
		cq[r]=e;
		r=(r+1)%size;
	}
}
void del()
{
	int e;
	if(f==r)
	printf("\nQUEUE IS EMPTY\n");
	else
	{
		e=cq[f];
		f=(f+1)%size;
		printf("\nThe Deleted Element is %d\n",e);
	}
}
void display()
{
	int i=f;
	if(f==r)
	printf("\nThe QUEUE IS EMPTY\n");
	else
	{
		while(i!=r)
		{
			printf("\n|\t%d\t|",cq[i]);
			i=(i+1)%size;
		}
	}
}

