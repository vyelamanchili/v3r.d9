   /*Program for sum of x+x3/3!+x5/5!+......n terms*/

#include<stdio.h>

main()
{
	int x,i,n;
	float sum,den=1,num;
	printf("Enter value of x\n");
	scanf("%d",&x);
	printf("enter n value(no. of terms)\n");
	scanf("%d",&n);
	sum=x;
	num=x;
	for(i=1;i<=n;i++)
	{
		num=num*x*x;
		den=den*(2*i)*((2*i)+1);
		sum+=num/den;
	}
	printf("\nSum of the series x+x3/3!+x5/5!+.......upto %d terms is %f\n\n",n,sum);
}