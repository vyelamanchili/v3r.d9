# include <stdio.h>
main()
{
        int a[3][3],b[3][2],c[3][2],i,j;
        printf("Enter the Values of A and B");
        for(i=0;i<=2;i++)
        {
	 for(j=0;j<=2;j++)
	         scanf("%d%d",&a[i][j],&b[i][j]);
        }
        for(i=0;i<=2;i++)
	 scanf("%d",&a[2][i]);
        for(j=0;j<=2;j++)
        {
	 for(i=0;i<=1;i++)
	         c[j][i]=0;
        }
        for(j=0;j<=1;j++)
        {
	 for(i=0;i<=2;j++)
	         x=a[j][i]*b[i][j];
	 c[j][i]=c[j][i]+x;
	 printf("%d X %d = %d",a[j][i],b[i][j],c[j][i]);
        }
        for(j=0;j<=1;j++)
        {
	 for(i=0;i<=2;i++)
	         y=a[2][i]*b[i][j];
	 c[2][i]=c[2][i]+y;
	 printf("%d X %d = %d",a[2][i],b[i][j],c[2][i]);
        }
}
	 
