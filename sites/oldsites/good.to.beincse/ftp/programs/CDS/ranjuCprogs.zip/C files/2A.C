	    /*Printing 3 no.s in ascending  order*/

#include<stdio.h>

main()
{
	int a,b,c;
	printf("Enter 3 no.s for printing ascending order\n:");
	scanf("%d%d%d",&a,&b,&c);
	if(a<b && a<c)
	{
		if(b<c)
		printf("%d , %d , %d\n\n",a,b,c);
		else
		printf("%d , %d , %d\n\n",a,c,b);
	}
	if(b<a && b<c)
	{
		if(a<c)
		printf("%d , %d , %d \n\n",b,a,c);
		else
		printf("%d , %d , %d\n\n ",b,c,a);
	}
	else
	{
		if(a<b)
		printf("%d , %d , %d\n\n",c,a,b);
		else
		printf("%d , %d , %d\n\n",c,b,a);
	}
}
