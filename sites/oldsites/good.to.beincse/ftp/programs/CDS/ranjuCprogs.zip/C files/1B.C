  /*Program to evaluate value of 2.5logx + cos 32 + |x^2+y^2| + (2xy)^1/2*/

#include<stdio.h>
#include<math.h>

main()
{
	float x,y,res,a;
	printf("Enter values of x,y\n:");
	scanf("%f%f",&x,&y);
	a=32*3.14/180;
	a=cos(a);
	res=2.5*log(x)+a+abs(x*x+y*y)+pow(2*x*y,1/2);
	printf("2.5logx + cos32 + |x2+y2| + (2xy)^1/2 = %f\n",res);
}