#include<stdio.h>
#define size 5
int dq[size];
int r=-1,f=0,e;
void inr(),inf(),outr(),outf(),display(),menu();
main()
{
	int ch;
	menu();
	printf("\nEnter Ur Choic\n:");
	scanf("%d",&ch);
	while(ch!=6)
	{
		switch(ch)
		{
			case 1:inr();
			       break;
			case 2:inf();
			       break;
			case 3:outr();
			       break;
			case 4:outf();
			       break;
			case 5:display();
				break;
			default:printf("\nUNKNOWN OPTION\n");
		}
		menu();
		printf("\nEnter Ur Choic\n:");
		scanf("%d",&ch);
	}
	printf("\nASTALA VISTA BABY\n");
}
void menu()
{
	printf("\n1.Insert element from rear end\n");
	printf("2.Insert element from front end\n");
	printf("3.Delete element from rear end\n");
	printf("4.Delete element from front end\n");
	printf("5.Display element in Double Ended Queue\n");
	printf("6.EXIT\n");
}
void inr()
{
	if(r==size-1)
		printf("\nCannot insert element from rear\n");
	else
	{
		printf("Enter The element\n");
		scanf("%d",&e);
		r++;
		dq[r]=e;
	}
}
void inf()
{
	if(f==0)
		printf("\nCannot Insert from Front end\n");
	else
	{
		printf("\nEnter The element\n");
		scanf("%d",&e);
		f--;
		dq[f]=e;
	}
}
void outr()
{
	if(r==0)
		printf("\n Cannot Delete from Rear\n");
	else
	{
		e=dq[r];
		r--;
		printf("\nDeleted Element is %d\n",e);
	}
}
void outf()
{
	if(f>r)
		printf("\n Cannot Delete from Front\n");
	else
	{
		e=dq[f];
		f++;
		printf("\nDeleted Element is %d\n",e);
	}
}
void display()
{
	int i;
	if(f>r)
		printf("\nEmpty\n");
	else
		for(i=f;i<=r;i++)
			printf("\n|\t%d\t|",dq[i]);

}
