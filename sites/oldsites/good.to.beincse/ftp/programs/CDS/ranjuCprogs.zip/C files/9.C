/*     PROGRAM FOR REVERSING A NUMBER USING WHILE LOOP          */
 
#include<stdio.h>

main()
{
	int num,dig;
	printf("enter the number to be reversed");
	scanf("%d",&num);
	while(num!=0)
	{
		dig=num%10;
		printf("%d",dig);
		num/=10;
	}
}