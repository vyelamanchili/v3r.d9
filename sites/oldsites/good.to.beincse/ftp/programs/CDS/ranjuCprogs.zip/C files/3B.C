/*Program to find no. of Odd no.s between a given set of 20 integers */

#include<stdio.h>
main()
{
	int i,count=0,t;
	printf("Enter the no. from where u want to");
	printf(" know odd no.s(till next 20 no.s)\n:");
	scanf("%d",&i);
	t=i;
	for(;i<=t+20;i++)
	{
		if(i%2!=0)
		count++;
	}
	printf("The total no. of odd no. between %d and %d is %d\n\n",t,t+20,count);
}

/*
OUTPUT:

$./a.out
Enter the no. from where u want to know odd no.s(till next 20 no.s)
3
The total no. of odd no. between 3 and 23d is 10
$
	*/