#include<stdio.h>
#include<string.h>
main()
{
	char s[60];
	int i,length;
	printf("Enter the string\n");
	gets(s);
	length=strlen(s);
	for(i=0;i<length;i++)
	{
		if(isalpha(s[i]))
		{
			s[i]=toupper(s[i]);
                	printf("%c",s[i]);
        	}    
		else
  		        printf("%c",s[i]);
	}
}