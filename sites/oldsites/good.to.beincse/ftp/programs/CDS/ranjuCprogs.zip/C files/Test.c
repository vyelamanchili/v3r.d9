#include<stdio.h>
main()
{
	int num=0,n,rem;
	printf("Enter N\n");
	scanf("%d",&n);
	while(rem!=0)
	{
		rem=n%10;
		n=n/10;
		num=num*10+rem;
	}
	printf("Reverse No. is %d",num);
}
