
	/*Program to find sum of even no.s for a given set of 20 integers */

#include<stdio.h>
main()
{
	int i,sum=0,t;
	printf("Enter the no. from where u want to");
	printf(" find sum of even no.s(till next 20 no.s)\n:");
	scanf("%d",&i);
	t=i;
	for(;i<=t+20;i++)
	{
		if(i%2==0)
		sum+=i;
	}
	printf("The Sum of Even no. from %d and %d is %d\n\n",t,t+20,sum);
}      /*

OUTPUT:

$./a.out
Enter the no. from where u want to know even no.s(till next 20 no.s)
3
The total no. of Even no. between 3 and 23d is 10
$        */