#include<stdio.h>
void main()
{
	char k;
	int f=65;
	for(k=1;k<=10;k++)
	{
		f-=0.1;
	}
	printf("%d\n",f)
}
