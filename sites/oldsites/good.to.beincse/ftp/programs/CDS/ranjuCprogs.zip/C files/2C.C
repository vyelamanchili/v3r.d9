   /*Program for sum of 1+x2/2!+x4/4!+......10terms*/

#include<stdio.h>

main()
{
	int x,i;
	float sum=0,den=1,num=1;
	printf("Enter value of x\n");
	scanf("%d",&x);
	for(i=1;i<=10;i++)
	{
		sum+=num/den;
		num=num*x*x;
		den=den*(2*i)*((2*i)-1);
	}
	printf("\nSum of the series 1+x2/2!+x4/4!+.......upto 10 terms is %f\n\n",sum);
}