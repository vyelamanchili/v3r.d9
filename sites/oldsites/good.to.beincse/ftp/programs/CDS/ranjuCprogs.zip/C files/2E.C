	/*Program for printing y value for corresponding x value*/
#include<stdio.h>

main()
{
		int x,y;
		printf("Enter value of x\n:");
		scanf("%d",&x);
		if(x<0)
		printf("Y=-1");
		if(x==0)
		printf("Y=0")
		if(x>0)
		printf("Y=1");
}
