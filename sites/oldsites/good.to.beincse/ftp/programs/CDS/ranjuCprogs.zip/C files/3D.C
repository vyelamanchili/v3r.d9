/*Program to find Sum of odd no.s for a given set of 20 integers */

#include<stdio.h>
main()
{
	int i,sum=0,t;
	printf("Enter the no. from where u want to");
	printf(" find the sum of odd no.s(till next 20 no.s)\n:");
	scanf("%d",&i);
	t=i;
	for(;i<=t+20;i++)
	{
		if(i%2!=0)
		sum+=i;
	}
	printf("The Sum of Odd no. between %d and %d is %d\n\n",t,t+20,sum);
}
/*
OUTPUT:

$./a.out
Enter the no. from where u want to find the sum of odd no.s(till next 20 no.s)
1
The Sum of Odd no. between 1 and 21 is 10
$*/