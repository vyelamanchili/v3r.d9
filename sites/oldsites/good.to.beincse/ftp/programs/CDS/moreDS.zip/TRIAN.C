#include <stdio.h>
#include <conio.h>

main()
{
 int i,j,n;
 clrscr();
 printf("Enter any number:");
 scanf("%d",&n);
 for(i=1;i<=n;i++)
  {
   printf("\n\n\t\t\t");

   for(j=1;j<=i;j++)
    {
     printf("%d  ",j);
  /*   if(i==n)
     {
      printf("%d �",i);
     } */
    }
  }
  getch();
}