#include <stdio.h>
//#include <conio.h>
#include <string.h>

main()
{
char name[25];
unsigned long int i=0,*x[25],n;
clrscr();
printf("Enter your name:");
//or scanf("%s",&name);
gets(name);
do
 {
  x[i]=&name[i];
  printf("Address=%d<Scancode=%d>Character=%c\n\n ",x[i],name[i],name[i]);
  i++;
 }while(name[i]!='\0');

getch();
}
