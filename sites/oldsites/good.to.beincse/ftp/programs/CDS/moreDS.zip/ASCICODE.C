#include <stdio.h>
#include <conio.h>
main()
{
// program for ascii chart
int ch;
clrscr();
for(ch=0;ch<=255;ch++)
{
 textbackground(0);
 textcolor(2);
 cprintf("SCANCODE=%d,  ASCII-Ch=%c",ch,ch);
 printf("\n\n");
 printf("**************************");
 printf("\n\n");
 getch();
}
}