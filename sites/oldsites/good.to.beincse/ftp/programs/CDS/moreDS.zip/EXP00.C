#include <stdio.h>
#include <conio.h>

main()
 {
  int i,j,n;
  clrscr();
  printf("Enter n:");
  scanf("%d",&n);

 for(i=1;i<=n;i++)
  {
   printf("\n");
   for(j=1;j<=i;j++)
    {
     printf("A");
    }
   for(j=0;j<i;j++)
    {
     printf("B");
    }
  }

 for(i=i;i>=1;i--)
  {
   printf("\n");
   for(j=i;j>=1;j--)
    {
     printf("A");
    }
   for(j=i;j>=1;j--)
    {
     printf("B");
    }
  }
 getch();
}