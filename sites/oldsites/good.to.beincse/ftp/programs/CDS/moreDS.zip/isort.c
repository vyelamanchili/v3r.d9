#include<stdio.h>

/* This is a insertion sort program */

#define SIZE 5

int x[SIZE], index;

void insertionsort(int a[]) {
	int i, j, t;

	for (i = 0; i <= SIZE; i++) {
		t = a[i];
		a[0] = t;
		j = i;
		while(t < a[j-1]) {
			a[j] = a[j-1];
			j--;
		}
		a[j] = t;
	}
}

int main() {
	index = 1;
	while (index <= SIZE) {
		printf("Enter Integer:\n");
		scanf("%d", &x[index]);
		printf("\n");
		index++;
	}

	insertionsort(x);

	printf("\n\n");
	printf("Sorted array:");
	index = 1;
	while(index <= SIZE) {
		printf("%d", x[index]);
		index++;
	}
	printf("\n");
	scanf("%d", &x[index]);
	return 0;
}



