#include <stdio.h>
#include <conio.h>

main()
{
 int n,x,i,ch;
 clrscr();
 textmode(3);
 printf("Press use left and right key to increament or decreament n\n\n");

 printf("Enter The number whose table you want to create:");
 scanf("%d",&n);
 while(ch!=27)
 {
 clrscr();
 gotoxy(25,25);
 printf("Press Esc to close program\n\n");
 gotoxy(1,1);
 for(i=1;i<=10;i++)
  {
   x=i*n;
   printf("%d X %d = %d\n\n",n,i,x);
  }
//  getch();
  ch=getch();
  switch(ch)
    {
      case 77:n++;break;
      case 75:n--;break;
      case 27:break;
      default:printf("Enter valid key");break;
    }
 }
}