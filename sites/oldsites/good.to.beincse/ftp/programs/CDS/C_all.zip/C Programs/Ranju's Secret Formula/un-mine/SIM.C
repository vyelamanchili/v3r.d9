/*----------------------------------------------------------------------------*//*                  			SIMPSON'S (1/3)RD RULE                                    *//*----------------------------------------------------------------------------*/

#include<stdio.h>
float y(float x)
{
	return(x*x);
}

main()
{
	float x0,xn,n,m,h,i,s;
	printf("\nenter the values for x0,xn,n\n");
	scanf("%f %f %f",&x0,&xn,&n);
	h=(xn-x0)/n;
	s=y(x0)+y(xn)+4*(y(x0+h));
	for(i=3;i<=(n-1);i=i+2)
			s=s+4*y(x0+i*h)+2*(y(x0+(i-1)*h));
	m=(h/3)*s;
	printf("result is %f\n",m);
}