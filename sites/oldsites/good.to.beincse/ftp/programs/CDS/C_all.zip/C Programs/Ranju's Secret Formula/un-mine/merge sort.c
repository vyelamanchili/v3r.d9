list sort( n )
     int n;
     {
     list fi, la, temp;
     extern list r;
     if ( r == NULL ) return( NULL );
     else if ( n&gt;1 )
          return( merge( sort( n/2 ), sort( (n+1)/2 )));
     else     {
          fi = r; la = r;
          /*** Build list as long as possible ***/
          for ( r=r-&gt;next; r!=NULL; )
               if ( r-&gt;k &gt;= la-&gt;k ) {
                    la-&gt;next = r;
                    la = r;
                    r = r-&gt;next;
                    }
               else if ( r-&gt;k &lt;= fi-&gt;k ) {
                    temp = r;
                    r = r-&gt;next;
                    temp-&gt;next = fi;
                    fi = temp;
                    }
               else break;
          la-&gt;next = NULL;
          return( fi );
          }
     };
