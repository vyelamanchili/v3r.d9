/*
 ********************************************************************************
 *                                                                              *
 * This program is free software; you can redistribute it and/or modify         *
 * it under the terms of the GNU General Public License as published by         *
 * the Free Software Foundation; either version 2 of the License, or            *
 * (at your option) any later version.                                          *
 *                                                                              *
 * This program is distributed in the hope that it will be useful,              *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of               *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                *
 * GNU General Public License for more details.                                 *
 *                                                                              *
 * You should have received a copy of the GNU General Public License            *
 * along with this program; if not, write to the Free Software                  *
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA    *
 *                                                                              *
 ********************************************************************************
 */


#include "list.h"
#include <time.h>

int main( void )
{
  int      x     = 0x00;
  st_list *list  = NULL;
  st_list *merg  = NULL;
  st_node *lnode = NULL;
  

  for ( ; !(x & 0x0011); x++ )
   printf ("Hello\n");
  /* creates an empty list and returns it back */
  printf ("Create the list :: \n" );
  list = create_list();

  /* inserts the given value to the list supplied, returns > 0 if successful */
  for ( x = 0 ; x < 10; ++x ) {
    printf ("Insert to list\t:: %d\n", (x * 1024) );
    assign( list, (x * 1024) );
  }

  printf ("Show the list contents :: "); print( list ); printf("\n");
  printf ("Print the mid of list  :: %ld\n", mid(list)->ui_value_ );
  printf ("Search for 9216 on list:: %ld\n", search_f( list, 9216 ) );

  /* get the end of list */
  printf ("Get the end of list    :: ");
  lnode = (st_node*) back( list );
  printf ("%d\n", lnode->ui_value_ );

  /* get the start point of list */
  printf ("Get the end of list    :: "); lnode = (st_node*) begin( list );
  printf ("%d\n", lnode->ui_value_ );

  /* erase all the elements in this list */
  printf ("Clear the list         :: %d\n", clear( list ) );
  printf ("Show the list contents :: "); print( list ); printf("\n");

  /* destroy the list and its contents */
  printf ("Destroy the list       :: %d\n", destroy( list ) );
  printf ("Show the list contents :: "); print( list ); printf("\n");

  /* tests for the emptyness of the list */
  printf ("Is the list empty      :: %d\n", empty( list ) );

  /* inserts the given value to the list supplied, returns > 0 if successful */
  for ( x = 0 ; x < 10; ++x ) {
    printf ("Insert to list\t:: %d\n", (x * 1024) );
    assign( list, (x * 1024) );
  }

  printf ("Show the list contents :: "); print( list ); printf("\n");
  printf ("Print the mid of list  :: %ld\n", mid(list)->ui_value_ );

  /* get modifiable pointer to end of the list */
  printf ("Get the end of  list   :: "); lnode = end( list );
  printf ("%d\n", lnode->ui_value_ );

  /* remove element at the given position; starts with 0 */
  printf ("Remove the first value :: %d\n", erase( list, 0) );
  printf ("Show the list contents :: "); print( list ); printf("\n");

  /* returns the value of the st_node at the given position */
  printf ("Try to sneek to pos 30 :: %d\n",  find( list, 30 ));
  printf ("Try to sneek to pos 0  :: %d\n",  find( list, 0 ));

  /* returns highest value on the list */
  printf ("Highest value on list  :: %d\n", high( list ) );

  /* returns lowest value on the list */
  printf ("Lowest value on list   :: %d\n", low( list ) );

  /* returns the maximum expandable size of the list */
  printf ("Max allowed elements   :: %d\n", max_size( list ) );

  /* creates an empty list and returns it back */
  printf ("Create the list merge  :: \n" );
  merg = create_list();

  /* inserts the given value to the list supplied, returns > 0 if successful */
  for ( x = 0 ; x < 10; ++x ) {
    printf ("Insert to list\t:: %d\n", (x * 1024) );
    assign( merg, (x * 1024) );
  }

  printf ("Show the list contents :: "); print( merg ); printf("\n");
  printf ("Print the mid of list  :: %ld\n", mid(merg)->ui_value_ );
  
  /* merges two lists into one, always child to list */
  printf ("Merge list and merge   :: %d\n", merge( list, merg ));
  printf ("Show the list contents :: "); print( list ); printf("\n");

  /* push the value to the end of the list */
  printf ("Push back value 3026   :: %d\n", push_back( list, 3026 ) );
  printf ("Show the list contents :: "); print( list ); printf("\n");

  /* push the value to the begining of the list */
  printf ("Push front value 2630  :: %d\n", push_front( list, 2630 ) );
  printf ("Show the list contents :: "); print( list ); printf("\n");

  /* get the last element of list out */
  lnode = pop_back ( list );
  printf ("Pop out the last value :: %d\n", lnode->ui_value_ );
  free ( lnode); lnode = NULL;
  printf ("Show the list contents :: "); print( list ); printf("\n");

  /* get the first element of the list out */
  lnode = pop_front ( list );
  printf ("Pop out the last value :: %d\n", lnode->ui_value_ );
  free ( lnode); lnode = NULL;
  printf ("Show the list contents :: "); print( list ); printf("\n");

  /* remove all occurances given value */
  printf ("Remove all 0 from list :: %d\n", remove_if( list, 0 ) );
  printf ("Show the list contents :: "); print( list ); printf("\n");

  /* returns number of occurance for value */
  printf ("How many 1024 in list  :: %d\n", repeat( list, 1024 ) );

  /* try to resize the maximum size of list */
  printf ("Size and max size      :: %d, %d\n", size( list), max_size ( list ) );
  printf ("Resize the max_size    :: %d\n", resize( list, 10 ) );
  printf ("Resize the max size    :: %d\n", resize( list, 30 ) );
  printf ("Size and max size      :: %d, %d\n", size( list), max_size ( list ) );

  /* tries to locate the value on the list; if found returns the position */
  printf ("Search for value 3072  :: %d\n", search( list, 3072 ) );

  /* kick the clone out */
  printf ("Show the list contents :: "); print( list ); printf("\n");
  printf ("Make the list unique   :: %d\n", unique( list ) );
  printf ("Show the list contents :: "); print( list ); printf("\n");

  return 0;
}