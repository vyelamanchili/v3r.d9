/*
 ********************************************************************************
 *                                                                              *
 * This program is free software; you can redistribute it and/or modify         *
 * it under the terms of the GNU General Public License as published by         *
 * the Free Software Foundation; either version 2 of the License, or            *
 * (at your option) any later version.                                          *
 *                                                                              *
 * This program is distributed in the hope that it will be useful,              *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of               *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                *
 * GNU General Public License for more details.                                 *
 *                                                                              *
 * You should have received a copy of the GNU General Public License            *
 * along with this program; if not, write to the Free Software                  *
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA    *
 *                                                                              *
 ********************************************************************************
 */

#ifndef __COMMON_FOR_C_IMPLEMENTATION__
#define __COMMON_FOR_C_IMPLEMENTATION__

#include <stdio.h>
#include <stdlib.h>

/*
 *  On some platform some stupid forgot to define TRUE and FALSE
 */

#define TRUE  1
#define FALSE 0 

/*
 * typdefine for unsigned category for basic native types
 */

typedef unsigned int    uint;
typedef unsigned long   ulong; 

/*
 * From here classification starts!. I have grouped the fundamental
 * data structures into two categories, extremely simple link list
 * and bit larger pointer oriented doubly linked list, stack, queue
 * , circular list, binary tree.  The former needs a single pointer
 * which is like one way road traffic and the latter is two way road
 * except for the binary tree, which is like a road forking into two
 * exits.
 *
 */

#ifdef __LISTS__
  struct node {
    int          ui_value_;
    struct node *p_next_;

    #ifdef __DOUBLE_NODE__
        struct node *p_prev_;
    #endif

  };

  typedef struct node st_node;
#endif

/* 
 * variables to track, the size of the list, minimum value on list
 * maximum value on list, maximum possible to which list can grow
 * starting point of list and end of the list
 */

#ifdef __LINEAR__
  struct linear_list {
    uint      ui_size_,  ui_max_size_, ui_mid_;

    #ifndef __QUEUES_TYPE__
      uint      ui_max_, ui_min_;
    #endif

    st_node  *p_base_;
    st_node  *p_end_;
    st_node  *p_mid_;
  };

  typedef struct linear_list st_list;
  typedef struct linear_list st_clist;
  typedef struct linear_list st_queue;
  typedef struct linear_list st_deque;
  typedef struct linear_list st_dlist;
  typedef struct linear_list st_stack;

#endif

#ifdef __BINARY__
  struct binary_node {
    uint               ui_value_;
    struct binary_node *p_right_;
    struct binary_node *p_left_;
  };

  typedef struct binary_node st_node;
#endif

#define Malloc(__ptr, __struct)                                   \
  if ( !(__ptr = (__struct*) malloc( sizeof(__struct) ))) {       \
    printf ( "%s# %d # Out of memory.\n", __FILE__, __LINE__ );   \
    return FALSE;                                                 \
  }

#define Free(__ptr)                                               \
  if (__ptr) {                                                    \
    free(__ptr);                                                  \
    __ptr = NULL;                                                 \
  }

#define error( __expr )                                                               \
  if ( __expr ) {                                                                      \
   printf ( "%s# %d ## Error evaluating %s returning\n", __FILE__, __LINE__, __expr ); \
   return FALSE;                                                                       \
  }

#ifdef __XOR_LIST__
  
  struct node {
    uint    ui_value_;
    ulong   ul_prvxt_;
  };

  typedef struct node st_node;

  struct xor_list {
    uint  ui_size_, ui_max_size_, ui_max_, ui_min_;
    
    st_node *p_base_, *p_end_;
  };

  typedef struct xor_list st_xlist;

#endif

#endif