/*
 ********************************************************************************
 *                                                                              *
 * This program is free software; you can redistribute it and/or modify         *
 * it under the terms of the GNU General Public License as published by         *
 * the Free Software Foundation; either version 2 of the License, or            *
 * (at your option) any later version.                                          *
 *                                                                              *
 * This program is distributed in the hope that it will be useful,              *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of               *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                *
 * GNU General Public License for more details.                                 *
 *                                                                              *
 * You should have received a copy of the GNU General Public License            *
 * along with this program; if not, write to the Free Software                  *
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA    *
 *                                                                              *
 ********************************************************************************
 */

#ifndef __LINEAR_LINKED_LIST__
#define __LINEAR_LINKED_LIST__

/* 
 * To tell the pre-processor that we are working on linear lists, if you take 
 * effort in removing the following line, things might be bit funny.
 */

#define __LISTS__   1
#define __LINEAR__  1

/*
 * Get all the common stuff from common.h defination for st_node and value is there
 * IMPORTANT  if you are intended to change the type of data you want to store
 * then you need to modify common.h file; otherwise DON NOT GO NEAR IT, if you are
 * happy with unsigned integer data.
 */
#include "common.h"

/*
 * Start of API signature
 */

/* creates an empty list and returns it back */
st_list* create_list( void );

/* inserts the given value to the list supplied, returns > 0 if successful */
char  assign( st_list *list, uint value );

/* get the end of list */
const st_node* back( st_list *list );

/* get the start point of list */
const st_node* begin( st_list *list );

/* erase all the elements in this list */
char  clear( st_list *list );

/* destroy the list and its contents */
char destroy ( st_list *list );

/* tests for the emptyness of the list */
char  empty( st_list *list );

/* get modifiable pointer to end of the list */
st_node* end( st_list *list );

/* remove element at the given position; starts with 0 */
char erase( st_list *list, uint pos );

/* get modifiable pointer to begining of the list */
st_node* front( st_list *list );

/* returns the value of the st_node at the given position */
int  find( st_list *list, uint pos );

/* returns highest value on the list */
uint  high( st_list *list );

/* returns lowest value on the list */
uint  low( st_list *list );

/* returns the maximum expandable size of the list */
uint  max_size( st_list *list );

/* merges two lists into one, always child to list */
char merge( st_list *list, st_list *child );

/* returns the mid point of the list */
st_node* mid ( st_list *list );

/* 
 * prints the contents; if you change the type from 
 * uint don't forget to modify here 
 */
void  print( st_list *list );

/* push the value to the end of the list */
char push_back( st_list *list, uint value );

/* push the value to the begining of the list */
char push_front( st_list *list, uint value );

/* get the last element of list out */
st_node* pop_back( st_list *list );

/* get the first element of the list out */
st_node* pop_front( st_list *list );

/* remove all occurances given value */
char remove_if( st_list *list, uint value );

/* returns number of occurance for value */
uint  repeat( st_list *list, uint value );

/* try to resize the maximum size of list */
char resize( st_list *list, uint value );

/* evaluate the value of max min once again */
char revaluate ( st_list *list );

/* tries to locate the value on the list; if found returns the position */
int search( st_list *list, uint value );
int search_f( st_list *list, uint value );

/* returns the number of elements in the list */
uint  size( st_list *list );

/* kick the clone out */
char unique( st_list *list );

/*
 * End of API signature and Start of definition 
 */

st_list* create_list( void ) {
  st_list *list = NULL;

  Malloc( list, st_list );
 
  list->ui_size_ = list->ui_min_ = list->ui_max_ = list->ui_mid_ = 0;
  list->ui_max_size_ = 1073741823;
  list->p_base_ = list->p_end_ = list->p_mid_ = NULL;

  return list;
}/* end of st_list* create_list() */

char  assign( st_list *list, uint value ) {
  if ( !(list) ) {
    printf ( "List# assign # %d # Invalid list supplied\n", __LINE__ );
    return FALSE;
  }/* if ( !(list) ) */

  if ( list->ui_size_ >= list->ui_max_size_ )
    return FALSE;

  if ( list->p_base_ == NULL ) {
    Malloc ( list->p_base_, st_node );
    list->p_base_->p_next_ = NULL;
    list->p_base_->ui_value_ = value;
    list->p_end_  = list->p_base_;
    list->p_mid_  = list->p_base_;
  } else {
    Malloc ( list->p_end_->p_next_, st_node );
    list->p_end_ = list->p_end_->p_next_;
    list->p_end_->p_next_   = NULL;
    list->p_end_->ui_value_ = value;
    ++list->ui_size_;
  }/* end of if else */

  if ( list->ui_mid_ < ( list->ui_size_ / 2 ) ) {
    ++list->ui_mid_;
    list->p_mid_ = list->p_mid_->p_next_;
  }/* if ( list->ui_mid_ < ( list->ui_size_ / 2 ) ) */

  if ( list->ui_min_ > value ) list->ui_min_ = value;
  if ( list->ui_max_ < value ) list->ui_max_ = value;

  return TRUE;
}/* char  assign( st_list *list, uint value ) */

const st_node* back( st_list *list ) {
  return ( ( list ) ? ( list->p_end_ ) : NULL );
}/* const st_node* back( st_list *list ) */

const st_node* begin( st_list *list ) {
  return ( (list) ? (list->p_base_) : NULL );
}/* const st_node* begin( st_list *list ) */

char  clear( st_list *list ) {
  register st_node *prev = NULL;

  if ( ( list ) && ( list->p_base_ != NULL ) ) {
    prev = list->p_base_;

    for ( list->p_base_ = list->p_base_->p_next_; list->p_base_ != NULL; 
          prev = list->p_base_, list->p_base_ = list->p_base_->p_next_ )
       Free(prev);

    list->ui_size_ = list->ui_mid_ = 0;
  }/* if ( !( list ) && ( list->p_base_ != NULL ) ) */
 
  return TRUE;
}/* char  clear( st_list *list ) */

char destroy ( st_list *list ) {

  if ( list ) 
    clear ( list );

  list->ui_size_ = list->ui_min_ = list->ui_max_ = 0;

  return TRUE;
}/* char destroy ( st_list *list ) */

char  empty( st_list *list ) {
  return ( ( list->p_base_ ) ? FALSE : TRUE );
}/* char  empty( st_list *list ) */

st_node* end( st_list *list ) {
  return ( ( list ) ? ( list->p_end_ ) : NULL );
}/* st_node* end( st_list *list ) */

char erase( st_list *list, uint pos ) {
  register st_node *search = NULL, *prev = NULL;
  register uint  loc = 0;

  if ( list ) {
    search = list->p_base_;

    if ( pos == 0 ) {
      list->p_base_ = search->p_next_;
      free( search );
      --list->ui_size_;
    } else {
      for ( search = list->p_base_; ( search->p_next_ != NULL ) && ( loc < pos ); 
        loc++, prev = search, search = search->p_next_ );
      
      if ( loc != pos ) {
          return FALSE;
      } else if ( search->p_next_ != NULL ) {
        prev->p_next_ = search->p_next_;
        free( search );
      } else {
        prev->p_next_ = NULL;
        free( search );
        list->p_end_ = prev;
      }
      --list->ui_size_;
    }/* if else */

    if ( !( search->ui_value_ ^ list->ui_max_ ) ||
      !( search->ui_value_ ^ list->ui_min_ ) )
      revaluate ( list );

    return TRUE;
  }/* if ( list ) */
  
  return FALSE;
}/* char erase( st_list *list, uint pos ) */

st_node* front( st_list *list ) {
  return ( ( list ) ? ( list->p_base_ ) : NULL );
}/* st_node* front( st_list *list ) */

int  find( st_list *list, uint pos ) {
  register st_node *start, *end = NULL;
  register uint     loc = 0;

  if ( ( list ) && ( pos < list->ui_size_ ) ) {
    if ( pos == 0 ) 
      return list->p_base_->ui_value_;

    if ( pos < list->ui_mid_ ) {
      start = list->p_base_;
      end   = list->p_mid_;
    } else {
      start = list->p_mid_;
    }

    for ( ; start != end; start = start->p_next_, ++loc );
    
    return start->ui_value_;
  }/* if ( ( list ) && ( pos < list->ui_size_ ) ) */

  return -1;
}/* int  find( st_list *list, uint pos ) */

uint  high( st_list *list ) {
  return ( ( list ) ? ( list->ui_max_ ) : 0 );
}/* uint  high( st_list *list ) */

uint  low( st_list *list ) {
  return ( ( list ) ? ( list->ui_min_ ) : 0 );
}/* uint  low( st_list *list ) */

uint  max_size( st_list *list ) {
  return ( ( list ) ? ( list->ui_max_size_ ) : 0 );
}/* uint  max_size( st_list *list ) */

char merge( st_list *list, st_list *child ) {
  if ( child != NULL ) {
    if ( list->p_base_ != NULL) {
      list->p_end_->p_next_ = child->p_base_;
      list->p_end_ = child->p_end_;
    } else {
      list->p_base_ = child->p_base_;
      list->p_end_  = child->p_end_;
    }/* if ( base_ != NULL ) */
    
    if ( list->ui_max_ > child->ui_max_ ) list->ui_max_ = child->ui_max_;
    if ( list->ui_min_ > child->ui_min_ ) list->ui_min_ = child->ui_min_;

    return TRUE;
  }/* if ( child != NULL ) */

  return FALSE;
}/* char merge( st_list *list, st_list *child ) */

/* returns the mid point of the list */
st_node* mid ( st_list *list ) {
  return ( ( list ) ? ( list->p_mid_ ) : NULL );
}/* st_node* mid ( st_list *list ) */


void  print( st_list *list ) {
  if ( ( list ) && ( list->p_base_ ) ) {
    register st_node *pos = list->p_base_;

    if ( pos ) {
      for ( ; pos ; pos = pos->p_next_ )
        printf("%d ", pos->ui_value_ );
    }/* if ( base_ != NULL ) */
  }/* if ( list ) */
}/* void  print( st_list *list ) */

char push_back( st_list *list, uint value ) {
  return ( assign ( list, value ) );  
}/* char push_back( st_list *list, uint value ) */

char push_front( st_list *list, uint value ) {
  register st_node *base;

  if ( !( list ) ) return FALSE;

  if ( list->p_base_ ) {
    Malloc ( base, st_node );  
    base->ui_value_ = value;
    base->p_next_   = list->p_base_;
    list->p_base_   = base;
    ++list->ui_size_;

    return TRUE;
  } else {
    return ( assign ( list, value ) );
  }

  return FALSE;
}/* char push_front( st_list *list, uint value ) */

st_node* pop_back( st_list *list )
{
  register st_node *start = NULL, *prev = NULL, *rtn = NULL;

  if ( list ) {
    for ( start = list->p_base_; start; 
          prev = start, start = start->p_next_ ) {
      if ( start == list->p_end_ ) {
        rtn = list->p_end_;
        list->p_end_  = prev;
        list->p_end_->p_next_ = NULL;
        --list->ui_size_;

        if ( ( rtn ) && ( !( rtn->ui_value_ ^ list->ui_max_ ) ||
          !( rtn->ui_value_ ^ list->ui_min_ ) ) )
          revaluate ( list );

        return rtn;
      }/* if ( start == end_ ) */
    }/* for ( prev = list->p_base_; start != NULL; 
      prev = start, start = start->p_next_ ) */
  }/* if ( start != NULL ) */

  return 0;
}/* st_node* pop_back( st_list *list ) */

st_node* pop_front( st_list *list ) {
  register st_node *start = NULL;

  if ( list ) {
    start = list->p_base_;

    list->p_base_ = start->p_next_;
    --list->ui_size_;

    if ( ( start ) && (!( start->ui_value_ ^ list->ui_max_ ) ||
      !( start->ui_value_ ^ list->ui_min_ ) ) )
      revaluate ( list );

    return start;
  }/* if ( start != NULL ) */

  return 0;
}/* st_node* pop_front( st_list *list ) */

char remove_if( st_list *list, uint value ) {
  register st_node *start = NULL, *prev = NULL;
 
  if ( list ) {
    for ( start = list->p_base_, prev = list->p_base_; start;
          prev = start, start = start->p_next_ ) {
            if ( !( start->ui_value_ ^ value ) ) {
              if ( start == list->p_base_ ) {
                list->p_base_ = start->p_next_;
                free( start );
                start = list->p_base_;
                --list->ui_size_;
              } else if ( start == list->p_end_ ) {
                free( list->p_end_ );
                list->p_end_ = prev;
                list->p_end_->p_next_ = NULL;
                --list->ui_size_;
              } else {
                prev->p_next_ = start->p_next_;
                free( start );
                start = prev;
                --list->ui_size_;
              }/* if ( start == base_ ) */
            }/* if ( !( start->ui_value_ ^ value ) ) */
    }/* for ( start = list->p_base_, prev = list->p_base_; start != NULL;
          prev = start, start = start->p_next_ ) */
    
    if ( ( list ) && ( !( value ^ list->ui_max_ ) 
          || !( value ^ list->ui_min_ ) ) )
      revaluate ( list );
    
    return TRUE;
  }/* if ( list ) */

  return FALSE;
}/* char remove_if( st_list *list, uint value ) */

uint  repeat( st_list *list, uint value ) {
  register st_node *cearch = NULL;
  register uint  repeat = 0;

  if ( list ) {
    cearch = list->p_base_;

    for ( ; cearch; cearch = cearch->p_next_ )
      if ( !( cearch->ui_value_ ^ value ) ) ++repeat;

    return repeat;
  }/* if ( list ) */

  return 0;
}/* uint  repeat( st_list *list, uint value ) */

char resize( st_list *list, uint value ) {
  return ( ( list && ( list->ui_size_ < value ) ) ? 
           ( list->ui_max_size_ = value, TRUE ) : 
           ( FALSE) 
          );
}/* char resize( st_list *list, uint value ) */

char revaluate ( st_list *list ) {
  register st_node *temp = NULL;

  if ( list && ( list->p_base_ != NULL ) ) {
    list->ui_max_ = list->ui_min_ = list->p_base_->ui_value_;

    for (temp = list->p_base_; temp ; 
      temp = temp->p_next_ ) {
        if ( list->ui_max_ < temp->ui_value_ ) 
          list->ui_max_ = temp->ui_value_;
        if ( list->ui_min_ > temp->ui_value_ )
          list->ui_min_ = temp->ui_value_;
      }/* for (temp = list->p_base_; temp != NULL; 
      temp = temp->p_next_ ) */
    return TRUE;
  }/* if ( list->p_base_ != NULL ) */
  return FALSE;
}/* char revaluate ( st_list *list ) */


int search( st_list *list, uint value ) {
  register st_node *search = NULL;
  register uint  pos    = 0;

  if ( ( list ) && ( list->p_base_ != NULL )
       && ( value <= list->ui_max_ ) ) {
    search = list->p_base_;

    for ( ; ( search ) && ( search->ui_value_ != value ); 
      ++pos, search = search->p_next_ );

    if ( ( search ) && !( search->ui_value_ ^ value ) )
      return pos;
  }/* if ( list->p_base_ != NULL ) */
  return -1;
}/* uint search( st_list *list, uint value ) */

int search_f ( st_list *list, uint value ) {
  st_node *p_base = NULL, *p_mid = NULL;
  uint     pos    = 0, done = 0x0000;

  if ( ( list ) && ( list->p_base_ ) 
       && ( value <= list->ui_max_ ) ) {
    for ( p_base = list->p_base_, p_mid = list->p_mid_;
          !( done & 0x0011 ); pos += 2 ) {

      if ( p_base->ui_value_ == value )          return pos;
      if ( p_base->p_next_->ui_value_ == value ) return ( pos + 1 );
      if ( p_mid->ui_value_ == value )           return ( pos + list->ui_mid_ );
      if ( p_mid->p_next_->ui_value_ == value )  return ( pos + list->ui_mid_ + 1);

      if ( p_base == p_mid ) done |= 0x0001;
      if ( p_mid  == NULL  ) done |= 0x0010;

      if ( p_base != list->p_mid_ ) {
        if  ( p_base->p_next_ != list->p_mid_ )
          p_base = p_base->p_next_->p_next_;
        else
          p_base = p_base->p_next_;
      }

      if ( p_mid != NULL ) {
        if ( p_mid->p_next_ != NULL )
          p_mid = p_mid->p_next_->p_next_;
        else
          p_mid = p_mid->p_next_;
      }

    }/* for ( p_base = list->p_base_, p_mid = list->p_mid_;
          !( done & 0x0011 ); pos += 2 ) */
  }/* if ( !list && ( value < list->ui_max_ ) ) */

  return -1;
}/* int search_f ( st_list *list, uint value ) */


uint  size( st_list *list ) {
  return ( ( list ) ? ( list->ui_size_ ) : 0 );
}/* uint  size( st_list *list ) */

char unique( st_list *list ) {
  register st_node *start = NULL;
  register st_node *ptr   = NULL;
  register st_node *prev  = NULL;
  register uint     value = 0;

  if ( !( list->p_base_ ) ) return FALSE;

  for ( start = list->p_base_; start; start = start->p_next_ ) {
    value = start->ui_value_;

    for ( ptr = start->p_next_, prev  = start; ptr;
          prev = ptr, ptr = ptr->p_next_ ) {
            if ( !( ptr->ui_value_ ^ value ) ) {
              if ( ptr == list->p_base_ ) {
                list->p_base_ = ptr->p_next_;
                free( ptr );
                ptr = list->p_base_;
                --list->ui_size_;
              } else if ( ptr == list->p_end_ ) {
                free( ptr );
                ptr = prev;
                ptr->p_next_ = 0;
                --list->ui_size_;
              } else {
                prev->p_next_ = ptr->p_next_;
                free( ptr );
                ptr = prev;
                --list->ui_size_;
              }
            }/* if ( !( ptr->ui_value_ ^ value ) )  */
     }/* for ( ptr = start->p_next_, prev  = start; ptr != NULL;
          prev = ptr, ptr = ptr->p_next_ ) */
  }

  revaluate ( list );

  return TRUE;
}/* end of unique() */

#endif
