#include "list.h"
#include <windows.h>

#define ONE_ML 1000000
#define TEN_ML 10000000

int main()
{
  st_list *p_list = NULL;
  st_node *p_node = NULL;

  long     lc_begin = 0, lc_end = 0;
  long     ld_begin = 0, ld_end = 0;

  uint     counter = 0, inner = 0;

  p_list = create_list();

  /* Setup incremental destroy once */

  lc_begin = GetTickCount();

  for ( inner = 0; inner < TEN_ML; inner++ )
    assign ( p_list, rand() );

  lc_end = GetTickCount();

  printf ("Time taken to create list of 10 Million key(s) # %ld\n", ( lc_end - lc_begin ) );

  ld_begin = GetTickCount();
  
  destroy ( p_list );

  ld_end = GetTickCount();

  printf ("Time taken to delete list of 10 Million Key(s) # %ld\n", ( ld_end - ld_begin ) );

  /* setp by step 

  for ( counter = 1; counter < 11; counter++ ) {
    lc_begin = GetTickCount();

    for ( inner = 0; inner < ( ONE_ML * counter ); inner++ )
      assign ( p_list, rand() );

    lc_end = GetTickCount();

    printf ("Time taken to create %ld Million Random Numbers  # %ld\n", 
          counter, ( lc_end - lc_begin ) );

    ld_begin = GetTickCount();
   
    destroy ( p_list );

    ld_end = GetTickCount();

    printf ("Time taken to delete list of %ld Million Key(s)  # %ld\n", 
          counter, ( ld_end - ld_begin ) );

  } 
  */

  return 0;
}