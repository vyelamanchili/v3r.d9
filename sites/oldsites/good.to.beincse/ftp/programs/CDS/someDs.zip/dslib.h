/******************************************************************************
 *                          DSLIB Library for use with C                      *
 *                       (C)Copyright 2003 by Abram Magner                    *
 *        This software is licensed under the GNU General Public License.  For*
 *  details, consult COPYING.DOC.                                             *
 ******************************************************************************/


#include <assert.h>

typedef unsigned char bool;
#define RIGHT 1
#define LEFT 0
typedef struct tree
{
	union
		{
			char *stringdata;
			char cdata;
			int numdata;
			float flodata;
		} data;
	struct tree *left, *right;                // Left and right branches
	struct tree *parent;
} tree;

tree *make_tree (void);
tree *make_node (tree *, bool);
void goto_parent (tree *);
void go_left (tree *);
void go_right (tree *);
void destroy_tree (tree *);

typedef struct dlink
{
	  union
		{
			char *stringdata;
			char cdata;
			int numdata;
			float flodata;
		} data;
	struct dlink *prev, *next;
} dlink;

dlink *make_list (void);
dlink *make_elmnt(dlink *);
void destroy_dlink (dlink *);
void goto_next_elmnt (dlink *);
void goto_prev_elmnt (dlink *);

typedef struct stack
{
	int *st_array;        //The actual stack.
	int index;
	int max_size;
}stack;

stack *make_stack (int);
int pop (stack *);
int peek (stack *);
bool push (stack *, int);        //This function returns 1 on success, 0 on fail
stack *copy_stack (stack *);
void destroy_stack (stack *);
void resize_stack (stack *, int);


