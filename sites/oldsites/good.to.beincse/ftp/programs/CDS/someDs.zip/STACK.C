#include <stdio.h>
#include <stdlib.h>
#include "dslib.h"

/*Remember that stacks are FILO*/
/*Index should always point above top*/

stack *make_stack (int how_big)        //works
{
	int x=0;
	stack *start;
	start=malloc (sizeof (stack));
	if (start==NULL) return (NULL);
	start->st_array=malloc ((how_big+1) * sizeof (int));
	if (start->st_array==NULL) return (NULL);
	start->index=0;
	start->max_size=how_big;
	for (;x<=start->max_size;++x)
		{
			start->st_array[x]=0;
		}
	return (start);
}

int pop (stack *st)        //works
{
	int extra=st->st_array[st->index-1];        //thing to pop
	st->st_array[st->index-1]=0;
	if (st->index>0) --st->index;
	return (extra);
}

int peek (stack *st)        //works
{
	return (st->st_array[st->index-1]);
}

bool push (stack *st, int value)        //works
{
	if ((st->index) < (st->max_size))
		{
			if (st->st_array!=NULL && st!=NULL)
				{
					st->index++;
					st->st_array[st->index-1]=value;
					return (1);
				}
			else return (0);
		}
	else return (0);
}

stack *copy_stack (stack *st)
{
	int x=0;
	stack *new_stack=make_stack (st->max_size);        //sets index to 0
	for (x=0;x<=st->index;++x)
		{
			push (new_stack, st->st_array[x]);
		}
	new_stack->index=st->index;
	return (new_stack);
}

void destroy_stack (stack *st)
{
	free (st->st_array);
	free (st);
}

void resize_stack (stack *st, int how_big)
{
	stack *extra;
	int x=0;
	extra=copy_stack (st);
	st=realloc (st, how_big);
	st->index=extra->index;
	for (x=0;x<=st->index;++x)
		{
			st->st_array[x]=extra->st_array[x];
		}
	destroy_stack (extra);
}








