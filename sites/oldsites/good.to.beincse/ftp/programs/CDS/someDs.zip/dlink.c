#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dslib.h"

dlink *make_list (void)
{
	dlink *top;
	top=malloc (sizeof(dlink));
	if (top==NULL)
		{
			return (NULL);
		}
	top->next=NULL;
	top->prev=NULL;
	return (top);
}


dlink *make_elmnt (dlink *top)
{
	dlink *insert_ptr;
	insert_ptr=top;
	while (1)
		{
			insert_ptr=insert_ptr->next;
			if(insert_ptr==NULL) break;
		}
	insert_ptr=malloc (sizeof(dlink));
	insert_ptr->next=NULL;
	insert_ptr->prev->next=insert_ptr;
	return (insert_ptr);
}

void destroy_dlink(dlink *top)
{
	dlink *destroy_ptr, *extra;
	destroy_ptr=top;
	while (destroy_ptr!=NULL)
		{
			extra=destroy_ptr->next;
			free (destroy_ptr);
			destroy_ptr=extra;
		}
}

void goto_next_elmnt(dlink *this_elmnt)
{
	if (this_elmnt->next!=NULL) this_elmnt=this_elmnt->next;
	else return;
}

void goto_prev_elmnt(dlink *this_elmnt)
{
	if (this_elmnt->prev!=NULL) this_elmnt=this_elmnt->prev;
	else return;
}







