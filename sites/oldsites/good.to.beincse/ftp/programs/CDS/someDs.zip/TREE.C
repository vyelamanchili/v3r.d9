#include "dslib.h"
#include <stdio.h>
#include <stdlib.h>

tree *make_tree (void)
{
	tree *root;
	root=malloc (sizeof (tree));        //allocate space for the root
	if (root==NULL)
		{
			assert (root);
			return (NULL);
		}
	root->left=NULL;
	root->right=NULL;
	root->parent=NULL;
	return (root);
}

tree *make_node (tree *parent, bool rorl)
{
	switch (rorl)
		{
		case RIGHT:
			if (parent->right==NULL)
				{
					parent->right=malloc (sizeof (tree));
					if (parent->right==NULL) 
						{
							assert (parent->right);
							return (NULL);
						}
					parent->right->left=NULL;
					parent->right->right=NULL;
					return (parent->right);
				}
		case LEFT:
			if (parent->left==NULL)
				{
					parent->left=malloc (sizeof(tree));
					if (parent->left==NULL)
						{
							assert (parent->left);
							return (NULL);
						}
					parent->left->left=NULL;
					parent->left->right=NULL;
					return (parent->left);
				}
		default:
			return (NULL);
		}
}


void goto_parent (tree *place)
{
	if (place->parent!=NULL) place=place->parent;
}

void go_left (tree *place)
{
	if (place->left!=NULL) place=place->left;
}

void go_right (tree *place)
{
	if (place->right!=NULL) place=place->right;
}

void destroy_tree (tree *root)
{
	tree *lefty=root->left, *righty=root->right;
	free (root);
	if (lefty==NULL && righty==NULL) return;
	destroy_tree (lefty);
	destroy_tree (righty);
}



