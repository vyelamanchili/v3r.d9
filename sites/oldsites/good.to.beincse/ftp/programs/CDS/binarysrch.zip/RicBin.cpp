#include <iostream.h>
#include <stdlib.h>


// Description:         Algorithm of Binary Research
// Source name:         RicBin.CPP  
// Date:                10/12/2001 
// Author:              Generoso Immediato 
// e-mail:              generoso_immediato@hotmail.com


main()
{ 
 //
 int array[10]={1,2,3,4,5,6,7,8,9,10};
 int left=0,right=9,middle;
 int number,i;
 bool sw=false;
 //
 cout<<"ARRAY: ";
 for (i=0;i<=9;i++)
 {
  cout<<array[i]<<";";
 } 
 cout<<" \n"<<"Number to find: ";
 cin>>number;
 while (sw == false && left <= right)
 { 
  middle=(left+right)/2; 
  if (number == array[middle]) 
  {
   sw=true;
   cout<<"number found.\n";
  }
  else
  {
   if (number < array[middle]) right=middle-1;
   if (number > array[middle]) left=middle+1;
  }
 }
 if (sw == false) cout<<"number not found.\n";
 system("Pause");
}
