#include<stdio.h>
main()
{
	int amount,i;
	float hp,mp,ha;
	printf("\nEnter the amount,type(1. Mill Cloth 2.Handloom Cloth)\n");
	scanf("%d%d",&amount,&i);
	switch(i)
	{
		case 2 :if(amount<=100)
			{
				hp=amount*5/100;
				ha=amount-hp;
			}
			else if(amount>100 && amount<=200)
			{
				hp=amount*7.5/100;
				ha=amount-hp;
			}
			else if(amount>200 && amount<=300)
			{
				hp=amount*10/100;
				ha=amount-hp;
			}
			else
			{
				hp=amount*15/100;
				ha=amount-hp;
			}
			printf("Discounted price = %f\n",ha);
			break;
		case 1 :if(amount<=100)
			{
				mp=0;
				ha=amount;
			}
			else if(amount>100 && amount<=200)
			{
				mp=amount*5/100;
				ha=amount-mp;
			}
			else if(amount>200 && amount<=300)
			{
				mp=amount*7.5/100;
				ha=amount-mp;
			}
			else
			{
				mp=amount*10/100;
				ha=amount-mp;
			}
			printf("\nDiscounted price= %f\n",ha);
			break;
	}
}