/*Program foe evaluating a postfix expression*/

#include<stdio.h>
#include<string.h>
#include<stdio.h>
int top=-1;
int size=20;
int stack[20];
main()
{       int isoper(char);
	void push(int);
	int pop();
	char p[20];
	int n,i=0,a,x1,x2;
	printf("Enter the postfix expression\n:");
	scanf("%s",p);
	n=strlen(p);
	printf("%d",n);
	p[n]=')';
	while(p[i]!=')')
	{
		if(!isoper(p[i]))
		{
			printf("\nEnter the Value of %c\n",p[i]);
			scanf("%d",&a);
			push(a);
		}
		else
		{
			x1=pop();
			x2=pop();
			switch(p[i])
			{
				case '+':
					 push(x1+x2);
					 break;
				case '-':
					 push(x1-x2);
					 break;
				case '*':
					 push(x1*x2);
					 break;
				case '/':
					 push(x1/x2);
					 break;
				case '%':
					 push(x1%x2);
					 break;
				case '^':
					 push(pow(x1,x2));
					 break;
			}
		}
		i++;
	}
	printf("\n\nThe Final Answer is %d\n\n",stack[top]);
}

void push(int x)
{
	if(top==size)
	printf("\nThe Stack is Full \n");
	else
	{
		top++;
		stack[top]=x;
	}
}

int pop()
{       int y;
	if(top==-1)
	printf("\n\nThe Stack is Empty\n\n");
	else
	{
		y=stack[top];
		top--;
		return(y);
	}
}

int isoper(char y)
{
	if(y=='+'||y=='-'||y=='*'||y=='/'||y=='^'||y=='%')
	return(1);
	else
	return(0);
}

