/*Infix to Postfix Expression     */
#include<stdio.h>
#include<ctype.h>
#define size 20
char stack[size];
char in[size],post[size];
int top=-1,i=0,j=0;
void push(char);
char tos(),pop();
int isoper(char),prior(char,char),islow(char);
main()
{       int n;
	char x;
	printf("Enetr the Infix expression\n:");
	scanf("%s",in);
	n=strlen(in);
	in[n]=')';
	push('(');
	while(top!=-1)
	{
		if(isalpha(in[i]))
		{
			post[j]=in[i];
			j++;
		}
		else if(isoper(in[i]))
		{
			while(isoper(tos()) && prior(in[i],tos()))
			{
				x=pop();
				post[j]=x;
				j++;
			}
			push(in[i]);
		}
		else if(in[i]=='(')
			push('(');
		else if(in[i]==')')
		{
			while(tos()!='(')
			{
				x=pop();
				post[j]=x;
				j++;
			}
			pop();
		}
		i++;
	}
	post[j]='\0';
	j++;
	printf("The Postfix exopression is %s\n",post);
}
int isoper(char c)
{
	if(c=='+'||c=='-'||c=='*'||c=='/'||c=='^')
	return 1;
	else
	return 0;
}
char tos()
{
	if(top==-1)
	printf("Stack is Empty\n");
	else
	return(stack[top]);
}
char pop()
{       char c;
	if(top==-1)
	printf("Stack is Empty\n");
	else
	{
	       c=stack[top];
	       top--;
	       return(c);
	}
}
void push(char c)
{
	if(top==size-1)
	printf("Stack is Full\n");
	else
	{
		top++;
		stack[top]=c;
	}
}
int prior(char x, char y)
{
	if(islow(x)<islow(y))
	return 1;
	else
	return 0;
}
int islow(char c)
{
	switch(c)
	{
		case '+':return 4;
		case '-':return 5;
		case '*':return 3;
		case '/':return 2;
		case '^':return 1;
	}
}


