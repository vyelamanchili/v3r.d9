                      /*  Range Kutta Method  */
#include<stdio.h>
#include<math.h>
float f(float x,float y)
{
     return(((y*y)-(x*x))/((y*y)+(x*x)));
}
main()
{
	float x0,y0,xn,h,k1,k2,k3,k4,k;
	printf("\nEnter the values of x,y,h,xn\n");
	scanf("%f%f%f%f",&x0,&y0,&h,&xn);
	while(x0!=xn)
	{
		k1=h*f(x0,y0);
		k2=h*f((x0+h/2),(y0+k1/2));
		k3=h*f((x0+h/2),(y0+k2/2));
		k4=h*f((x0+h),(y0+k3));
		k=(k1+2*(k2+k3)+k4)/6;
		x0=x0+h;
		y0=y0+k;
	}
	printf("\nX=%f\tY=%f\n",x0,y0);
}