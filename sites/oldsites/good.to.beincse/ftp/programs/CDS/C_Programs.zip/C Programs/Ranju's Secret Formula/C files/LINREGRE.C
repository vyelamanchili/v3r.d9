/*Linear Regression*/
#include<stdio.h>
float x[20],y[20],sx=0,sxsq=0,sy=0,sxy=0,denom,a0,a1;
int i,n,j;
main()
{
	printf("\n\t\t\tLinear Regression\n");
	printf("Enter The TotalPairs of Values\n:");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		printf("\nEnetr The Value of x[%d]\n:",i);
		scanf("%f",&x[i]);
		printf("\nEnetr The Value of y[%d]\n:",i);
		scanf("%f",&y[i]);
	}
	for(i=1;i<=n;i++)
	{
		sx+=x[i];
		sxsq+=x[i]*x[i];
		sy+=y[i];
		sxy+=x[i]*y[i];
	}
	denom=(n*sxsq-sx*sx);
	a0=(sy*sxsq-sx*sxy)/denom;
	a1=(n*sxy-sx*sxy)/denom;
	printf("\n\tx\t\ty\t\tx^2\t\txy\n");
	for(i=1;i<=n;i++)
		printf("\n\t%f\t%f\t%f\t%f",x[i],y[i],x[i]*x[i],x[i]*y[i]);
	printf("\n\ta0=%f\ta1=%f",a0,a1);
	printf("\n\ty=%f\tx=%f",a0,a1);		
}
