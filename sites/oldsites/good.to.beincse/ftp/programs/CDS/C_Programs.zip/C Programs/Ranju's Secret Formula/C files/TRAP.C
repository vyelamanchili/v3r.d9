                   /*   Trapezoidal Rule   */
#include<stdio.h>
#include<math.h>

float y(float x)
{
	return(1/(1+(x*x)));
}

main()
{
	float x0,xn,h,s,n,m,i;
	printf("Enter the values of x0,xn,n\n");
	scanf("%f%f%f",&x0,&xn,&n);
	h=(xn-x0)/n;
	s=y(x0)+y(xn);
	for(i=1;i<(n-1);i++)
	s=s+2*y(x0+i*h);
	m=(h/2)*s;
	printf("re=%f",m);
}

