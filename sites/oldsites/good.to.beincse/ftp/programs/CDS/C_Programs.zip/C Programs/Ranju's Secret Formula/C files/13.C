#include<stdio.h>
struct car
{
char type[20];
int mm;
int yy;
float price;
};
main()
{
	static struct car s[4]={{"maruti800",2,87,75000.00},
			{"maruti-dx",7,87,95000.00},
			{"gypsy",4,87,110000.00},
			{"marutivan",8,88,85000.00}
                        };
	char type[20];
	int sm,em,ey,sy,f=0,i,y;
	printf("\nEnter the vehicle type(name)\n:");
	scanf("%s",type);
	printf("\nEnter the period starting and ending\n:");
	scanf("%d%d",&sm,&em);
	printf("\nEnter the year(87/88)\n");
	scanf("%d",&sy);
	for (i=0;i<4;i++)
	{
	if((strcmp(s[i].type,type)==0)&&((sm<=s[i].mm)&&(em>=s[i].mm))&&((sy<=s[i].yy)/*&&(ey>=s[i].yy)*/))
	{
		printf("\n%s type vehicle is sold\n",type);
		printf("\n %d month",s[i].mm);
		printf("%d year of price is %f\n",s[i].yy,s[i].price);
		f=1;
	}
	}
	if (f==0)
	printf("\nSpecified vehicle not found\n\n");
}
