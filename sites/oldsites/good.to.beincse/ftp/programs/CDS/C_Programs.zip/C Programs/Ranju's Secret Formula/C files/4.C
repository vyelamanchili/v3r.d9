/*product of 2 matrices a[3][3] X b[3][2]=c[3][2]*/

#include<stdio.h>
main()
{
	int a[3][3],b[3][2],c[3][2],i,j,k;
	printf("Enter Matrix A values\n");
	for(i=0;i<3;i++)
	for(j=0;j<3;j++)
		scanf("%d",&a[i][j]);
	printf("\nEnter Matrix B Values\n");
	for(i=0;i<3;i++)
	for(j=0;j<2;j++)
		scanf("%d",&b[i][j]);
	for(i=0,i<3;i++)
	for(j=0;j<2;j++)
	{
		c[i][j]=0;
		for(k=0;k<3;k++)
			c[i][j]+=a[i][k]*b[k][j];
	}
	printf("The Product of the matrix is \n");
	for(i=0;i<3;i++)
	{
		printf("\n");
		for(j=0;j<3;j++)
		{
			printf("%5d",a[i][j]);
			if(i==1)
			printf("\tX\t");
		}
		for(k=0;k<2;k++)
		{
			printf("%5d",b[i][k]);
			if(i==1)
			printf("\t=\t");
		}
		for(j=0;j<2;j++)
			printf("%5d",c[i][j]);
	}
	printf("\n");
}

	