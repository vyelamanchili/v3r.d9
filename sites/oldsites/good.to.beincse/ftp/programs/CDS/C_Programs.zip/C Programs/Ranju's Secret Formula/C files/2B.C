/* Program for printing sum of 1+2+3+.......upto n terms */

#include<stdio.h>

main()
{
	int n,i,sum=0;
	printf("Enter the value of n\n");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
		sum=sum+i;
	printf("\nSum of 1+2+3+.....upto %d terms is %d\n",n,sum);
}
