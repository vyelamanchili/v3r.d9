#include<stdio.h>
main()
{
	float a,x,b,y;
	printf("Enter The value of a,x,b in (ax+b)/(ax-b)\n:");
	scanf("%f%f%f",&a,&x,&b);
	if(a*x-b==0)
		printf("\nNo solution\n");
	else
	{
		y=(a*x+b)/(a*x-b);
		printf("\n(ax+b)/(ax-b) = %f\n",y);
	}
}
