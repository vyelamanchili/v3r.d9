/*     PROGRAM TO PRINT FIBONACCI SERIES     */
#include<stdio.h>
main()
{
	int f,s,n,k,i;
	f=1,s=1,i=0;
	printf("\nEnter the value for n(no. of no.s to print):");
	scanf("%d",&n);
	printf("\n%d\n%d\n",f,s);
	do
	{
		k=f+s;
		printf("%d\n",k);
		s=f;
		f=k;
		i++;
	}
	while(i<(n-2));
}
