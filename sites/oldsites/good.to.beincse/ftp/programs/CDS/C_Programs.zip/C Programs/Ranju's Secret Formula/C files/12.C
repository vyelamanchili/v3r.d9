/**********************PROGRAM TO PRINT EXTRACTED STRING**********************/

#include<stdio.h>

main()
{
	char a[30];
	int m,n,i;
	printf("\nEnter the characters in the string\n:");
	scanf("%s",a);
	printf("\nEnter values for m(char no.) & n(no.s of chars) to print\n");
	scanf("%d%d",&m,&n);
	for(i=m-1;i<m+n-1;i++)
		printf("%c",a[i]);
}