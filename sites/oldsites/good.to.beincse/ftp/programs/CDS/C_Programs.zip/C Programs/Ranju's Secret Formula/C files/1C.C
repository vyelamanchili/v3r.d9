	/*To evaluate value of (1/a(2pi)^1/2) * e^(x-m/(2*s)^2 */

#include<stdio.h>
#include<math.h>

main()
{
	float a,x,m,s,res;
	printf("Enter the values of a,x,m,s\n: ");
	scanf("%f%f%f%f",&a,&x,&m,&s);
	res=(1/(a*sqrt(2*3.14))) * exp(pow(x-(m/(2*s)),2));
	printf("\n 1/a(2pi)^1/2 * e^(x-(m/(2*s)))^2 = %f\n",res);
}