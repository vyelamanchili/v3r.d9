import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
/* <applet code = "jlab6.class" width = 250 height =200>
   </applet>
   */

   public class jlab6 extends JApplet  implements ActionListener
    {
      JTextField t1;
      JRadioButton r1,r2,r3;
     public void init()
      {
       Container c = getContentPane();
       c.setLayout(new FlowLayout());
       t1 =  new JTextField(5);
       c.add(t1);
       r1 = new JRadioButton("C ");
       r2 = new JRadioButton("C++");
       r3 = new JRadioButton("Java");

       r1.addActionListener(this);
       c.add(r1);
       r2.addActionListener(this);
       c.add(r2);
       r3.addActionListener(this);
       c.add(r3);

       /* defining a button group */

        ButtonGroup bg = new ButtonGroup();
        bg.add(r1);
        bg.add(r2);
        bg.add(r3);
       }
       public void actionPerformed(ActionEvent e)
        {
          t1.setText(e.getActionCommand());
          }
     }

