#include<stdio.h>
#include<conio.h>
struct fifo
{
 int page,present;
 };
 void main()
 {
  struct fifo f[10];
  int frames, pge,i,faults=0,hit=0,full;
  printf("\n Enter the no. of frames");
  scanf("%d",&frames);
  for(i=0;i<frames;i++)
  f[i].page = -9;
  f[i].present =0;
  printf("Enter the pages[At end press -9");
  scanf("%d",&pge);
while(pge!=-9)
  {
   hit=0;
     for(i=0;i<frames;i++)
     {
       if(f[i].page ==pge)
       hit=1;
       }
       if(hit==0)
       {
	full=1;
	faults++;
	  for(i=0;i<frames;i++)
	  {
	   if(f[i].present ==0)
	   {
	    f[i].page=pge;
	    full=0;
	    f[i].present = 1;
	    break;
	    }
	   }
	   if(full==1)
	   {
	      for(i=0;i<frames;i++)
	       {
		f[i-1].page=f[i].page;
		f[i-1].page=pge;
	       }
	   }
	     scanf("%d",&pge);
	  }
	  }
	   printf("\n Total no. of pagefaults=%d",faults);
	   }



