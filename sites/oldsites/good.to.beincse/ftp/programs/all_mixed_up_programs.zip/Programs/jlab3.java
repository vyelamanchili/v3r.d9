import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
/* <applet code = "jlab3.class" width = 250 height =200>
   </applet>
   */

   public class jlab3 extends JApplet
    {
     public void init()
      {
       Container c = getContentPane();
       c.setLayout(new FlowLayout());
       JTextField t =  new JTextField("kishore",15);
       c.add(t);
       }
     }

