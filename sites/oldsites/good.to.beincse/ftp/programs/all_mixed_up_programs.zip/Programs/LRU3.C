//lru

#include<stdio.h>
#include<graphics.h>
#include<conio.h>
#include<stdlib.h>
int m,n,str[50],ar[30],j;
static int z,pagef;
char c[30];
int u,i,r=0,x=50,y=100,a=100,b=150,e,k,v=0,lr1,lr2;
void main(){
		 int gd=DETECT,gm,lru[30],l=0,w,s,t,max,temp,f[30],cnt[30];
		 initgraph(&gd,&gm,"c:\\tc\\bgi ");
		 printf("enter no of pages & no of frames\n");
		 scanf("%d%d",&m,&n);
		 printf("enter sequence\n");
		 for(i=0;i<m;i++)
		scanf("%d",&str[i]);
		 for(j=0;j<n;j++)
		 {
		 ar[j]=-1;cnt[j]=0;}
		 for(i=0;i<m;i++)
		 {
		   z=1;
		   s=0;
		   v=0;
		 for(j=0;j<n;j++)
		 {
		 if(ar[j]!=-1){cnt[j]++;v++;}}

		 if(v==n)z=1;
		   for(lr1=0;lr1<n;lr1++)
		   {
		    if(ar[lr1]==str[i]){z=0;cnt[lr1]=0;break;}}
		    if(z)
		    {

		    for(lr2=0;lr2<n;lr2++)
		    {
		     if(ar[lr2]==-1){max=-1;z=2;break;}}  }
		     if(z==1)
		     {
						 max=cnt[0]; temp=0;
					 for(l=1;l<n;l++){

				  if(cnt[l]>max)
					  {
					  max=cnt[l];temp=l;}   }


					  }

		   if(z==1){
		   for(u=0;u<n;u++)
		   {
		    if(u==temp)
		    {
		    max=ar[u];
				    break;}}
		    }



				  if(z){
		  for(v=0;v<n;v++)

		  {
		  if(ar[v]==max)
		    {ar[v]=str[i];pagef++;cnt[v]=0;break;}


			  }


		       }
		   //if(z){
		  e=y+10;
		  if(z){
		    for(k=0;k<n;k++)											for(k=0;k<n;k++)
					  {
			  rectangle(x+10,y,a+10,b);
				  if(ar[k]!=-1)
			  {
			   itoa(ar[k],c,10);
			   outtextxy(x+20,e,c);
			   e+=50;
			   }
			   b+=50;

			   }


			   x+=50;
			   a+=50;
			   y=100;
			   b=150;

			  }


			}


		    outtextxy(100,300,"the no of page faults:");
			   itoa(pagef,c,10);
			   outtextxy(330,300,c);
			   getch();
			   closegraph();
			   restorecrtmode();


			   }



























































