import javax.swing.*;
import java.awt.*;


class labelde extends JApplet
 {
  public void init()
   {
     // Getting content pane
     Container cn = getContentPane();

     // Creating an icon

        ImageIcon i1 = new ImageIcon("wuicon1.gif");

    // Create a label

        JLabel j1 = new JLabel("image",i1,JLabel.CENTER);

    // Add label to the content pane

       cn.add(j1);
    }
  }
