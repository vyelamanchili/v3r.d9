import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
/* <applet code = "jlab4.class" width = 250 height =200>
   </applet>
   */

   public class jlab4 extends JApplet  implements ActionListener
    {
      JTextField t1,t2,t3;
      JButton b;
     public void init()
      {
       Container c = getContentPane();
       c.setLayout(new FlowLayout());
       t1 =  new JTextField(5);
       t2 =  new JTextField(5);
       c.add(t1);
       c.add(t2);
       t3 =  new JTextField(5);
       c.add(t3);

       b = new JButton("add");
       b.addActionListener(this);
       c.add(b);

       }
       public void actionPerformed(ActionEvent e)
        {
         int x,y,z;
         String s,s1,s2;
         if (e.getSource()== b)
          {
           s1= t1.getText();
           s2= t2.getText();
           x = Integer.parseInt(s1);
           y = Integer.parseInt(s2);
           z = x + y;
           s = String.valueOf(z);
           t3.setText(s);

           }
         }
     }

