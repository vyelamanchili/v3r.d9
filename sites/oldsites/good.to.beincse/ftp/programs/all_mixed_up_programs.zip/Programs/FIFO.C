//fifo





#include<stdio.h>
#include<graphics.h>
#include<conio.h>
#include<stdlib.h>
int m,n,str[50],ar[30],j;
static int z,pagef;
char c[30];
int i,r=0,x=50,y=100,a=100,b=150,e,k;
void main(){
		 int gd=DETECT,gm;
		 initgraph(&gd,&gm,"c:\\tc\\bgi ");
		 printf("enter no of pages & no of frames\n");
		 scanf("%d%d",&m,&n);
		 printf("enter sequence\n");
		 for(i=0;i<m;i++)
		 scanf("%d",&str[i]);
		 for(j=0;j<n;j++)
		 ar[i]=-1;
		 for(i=0;i<m;i++)
		 {
		  z=1;
		  for(j=0;j<n;j++)
		  if(ar[j]==str[i])
		  z=0;
		  if(z){
		  ar[r]=str[i];
		  r++;
		  if(r>=n)r=0;
		  }
		  pagef++;
		  e=y+10;
					for(k=0;k<n;k++)
					  {
			  rectangle(x+10,y,a+10,b);
				  if(ar[k]!=-1)
			  {
			   itoa(ar[k],c,10);
			   outtextxy(x+20,e,c);
			   e+=50;
			   }
			   b+=50;

			   }

			   x+=50;
			   a+=50;
			   y=100;
			   b=150;
			  // if(x>500)
			  // x=50;a=100;y+=200;b+=50;


			 }
			   outtextxy(100,300,"the no of page faults:");
			   itoa(pagef,c,10);
			   outtextxy(330,300,c);
			   getch();
			   closegraph();
			   restorecrtmode();
			   }
