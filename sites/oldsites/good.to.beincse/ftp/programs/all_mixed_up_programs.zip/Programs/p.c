 #include<stdio.h>
    main()
      {
        int a,b,c;
        a=10;
b=20;
c=a+b;
printf("the sum of two numbers %d",c);
}
