for i in *
	do
		if [ �s �$1�]
		then
			echo $i is not a Zero size file
		else
			echo $i is of Zero size
			rm �$i�
		fi
	done
