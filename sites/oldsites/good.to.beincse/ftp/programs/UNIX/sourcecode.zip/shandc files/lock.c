#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
int main(void)
{
	int i, pid, fd;
	fd=creat(�locktest.c�,O_RDWR | O_APPEND);
	fd=fopen(�locktest.c�,O_RDWR | O_APPEND);
	lockf(fd,F_lock,0);
	pid=fork();
	if(pid==0)
	{
		fd=fopen(�locktest.c�,O_RDWR | O_APPEND);
		for(i=0;i<10;i++)
		write(fd,�A�,1);
	}
else
	{
		fd=fopen(�locktest.c�,O_RDWR | O_APPEND);
		for(i=0;i<10;i++)
		write(fd,�B�,1);
	}
	close(fd);
}
