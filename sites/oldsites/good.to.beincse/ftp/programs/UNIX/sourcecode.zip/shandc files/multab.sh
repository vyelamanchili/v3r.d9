i=1
	echo Enter the number
	read no
	for i in 1 2 3 4 5 6 7 8 9 10
	do
		j= � expr �$no� \* �$i� �
		echo $no * $i = $j
	done
