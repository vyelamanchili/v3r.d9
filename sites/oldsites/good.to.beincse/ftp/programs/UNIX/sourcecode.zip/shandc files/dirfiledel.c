#include<stdio.h>
#include<conio.h>
#include<sys/stat.h>
#include<fcntl.h>
int main(void)
{
	int fd;
	if (mkdir(�mydir�, 0777)== -1)
		exit(1);
	if((fd=creat(�mydir/f1�, 0777))== -1)
		exit(2);
	sleep(30);
	unlink(�mydir/f1�);
	close(fd);
	exit(0);
}