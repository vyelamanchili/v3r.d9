#include<stdio.h>
#include<sys/stat.h>
#include<sys/types.h>
int main(void)
{
	int i, pid, sum=0, sum2=0;
	pid=fork();
	if(pid==0)
	{
		for(i=0;i<20;i+=2)
		{	sum+=i;	}
		printf(�Sum of Even no.s is %d\n�,sum);
	}
else
{
		for(i=1;i<20;i+=2)
		{	sum2+=i;	}
		printf(�Sum of Odd no.s is %d\n�,sum);
}
}
