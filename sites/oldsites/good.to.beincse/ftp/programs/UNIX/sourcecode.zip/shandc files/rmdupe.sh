diff	$f1,	$f2
	if	[ �$?� -eq 0]
	then
		rm $f2
		echo $f2 is Removed
	else
		echo $f1 and $f2 are different files
	fi