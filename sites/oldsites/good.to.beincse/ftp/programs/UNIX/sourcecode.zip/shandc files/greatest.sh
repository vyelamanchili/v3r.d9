X=(1 13 11 30 20)
	big = ${ x[0] }
	i=0
	while [ �$i� �lt 5 ]
	do
	if [ $big �lt ${ x[i] } ]
	then
		big = ${ x[i] }
	fi
	i= � expr $i+1 �
	done
	echo $big is the largest number in the array