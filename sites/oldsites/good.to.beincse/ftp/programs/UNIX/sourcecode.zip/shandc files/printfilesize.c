#include<stdio.h>
void main(int argc, char *argv[])
{
	FILE *fd;
	if (argc!=2)
	{
		printf(�One argument is needed�);
		exit(-1);
	}
	fd=fopen(argv[1],�r�);
	if(fd==0)
	{
		printf(�Error in opening file�);
		exit(-1);
	}
	fseek(ip,0,SEEK_END);
	printf(�filesize=%ld�,ftell(ip));
}
