#include<stdio.h>
void main(int argc, char *argv[])
{
	FILE *ip, *op;
	if (argc!=3)
	{	printf(�Two arguments are needed�);
		exit(-1);
	}
	ip=fopen(argv[1],�r�);
	if(ip==0)
	{
		printf(�Error in opening file�);
		exit(-1);
	}
	op=fopen(argv[2],�w�);
	while (!feof(ip))
	fputc(fgetc(ip),op);
	fclose(ip);
	fclose(op);
	printf(�Done Copying�)
}
