for i in *
	do
		wc �m $i > temp
		j = � awk � {printf $1} � temp�
		if [ �$j� �gt 250]
		then
			echo $i has more than specified number of characters.
		fi
	done