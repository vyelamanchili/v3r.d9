#include<stdio.h>
#include<conio.h>
		#include<process.h>
		#include<ctype.h>
		int exp();
		int term();
		int factor();
		void match(char);
		void error();
		char token;
   		void main();
		{
			int r;
			clrscr();
			printf(�Enter any expression  :\n�);
			token=getchar();
			r=exp();
			if(token==�\n�)
				printf(�parsing  completed  successfully   \n  result   is %d�,r);
else
				error();
			getch();
		}
		int exp()
		{
			int temp;
			temp=term();
			while(token==�+�)
			{
    				match(�+�);
temp+=term();
}
			return temp;
		}
int term()
{
int temp;
		temp=factor();
		while(token==�*�)
		{
			match(�*�);
			temp*=factor();
		}
		return temp;
     	}
	int factor()
	{
		 int temp;
		 if(token==�(�)
		{
   			match(�(�);
			temp=exp();
			match(�(�);
		}
		else if(isdigit(token))
		{
			ungetc(token,stdin);
			scanf(�%d�,&temp);
			token=getchar();
		}
		else
			error();
		return temp;
	}
void match(char expectedtok)
	{
		if(token==expectedtok)
token=getchar();
		else
error();
	}
	
void error()
   	{
printf(�parsing  error�);
    		exit(1);
}
