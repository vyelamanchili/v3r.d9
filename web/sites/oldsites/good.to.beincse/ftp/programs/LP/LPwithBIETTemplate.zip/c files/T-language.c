#include<stdio.h>
#include<ctype.h>
#include<conio.h>
#define BUFLEN 80
#define MAXRES 9
#define MAXTOKEN 10
char bufstr[BUFLEN+1];
char tokenstr[MAXTOKEN+1];
int linepos=0;
int true=1;
int false=0;
typedef enum {ERROR,BEGIN,END,IF,THEN,ELSE,REPEAT,UNTIL,READ,WRITE,ID,NUM,ASSIGN,EQ,LT, GT,PLUS,MINUS,TIMES, OVER,LPAREN,RPAREN,SEMI} tokentype;

typedef enum {START,INASSIGN,INCOMMENT,INID,INNUM,DONE} starttype;

tokentype gettoken(void);
tokentype rlookup(char *);

void main()
{
	tokentype stoken;
	int i=1;
	clrscr();
	fflush(stdin);
	printf("Enter ur Program\n");
	gets(bufstr);
	while(bufstr[linepos]!='$')
	{
		stoken=gettoken();
		printf("\n%d :toke is %d",i++,stoken);
		printf("->%s\n",tokenstr);
	}
	getch();
}
tokentype gettoken(void)
{
	int tokenstr_index=0;
	tokentype ctoken;
	statetype state=START;
	int save;
	while(state!=DONE)
	{
		char c=bufstr[linepos++];
		save=true;
		switch(state)
		{
			case START:
					if(isdigit(c))
						state=INNUM;
					else if (isalpha(c))
						state=INID;
					else if(c==':')
						state=INASSIGN
					else if((c==' ')||(c=='\t'))
						save=false;
					else if(c=='{')
					{
						state=INCOMMENT;	
						save=false;
					}
					else
					{
						state=DONE;
						switch(c)
						{
							case '=':	 ctoken=EQ;	break;
							case '<':	ctoken=LT;	break;
							case '>':	ctoken=GT;	break;				
							case '+':	ctoken=PLUS;	break;
							case '-':	ctoken=MINUS;	break;
							case '*':	ctoken=TIMES;	break;
							case '/':	ctoken=OVER;	break;
							case '(':	ctoken=LPAREN;	break;
							case ')':	ctoken=RPAREN;	break;
							case ';':	ctoken=SEMI;	break;
							default:	ctoken=ERROR;	exit(0);
						}
					}
					break;
			case INCOMMENT:
					save=false;
					if(c=='}')
						state=START;
					break;
			case INASSIGN:
					if(c=='=')
					{
						state=DONE;
						ctoken=ASSIGN;
					}
					else
					{
						linepos--;
						save=false;
						ctoken=ERROR;
						exit(0);
					}
			case INNUM:
					if(!!isdigit(c))
					{
						linepos--;
						save=false;
						ctoken=NUM;
						state=DONE;
					}
					break;
			case INID:
					if(!isalpha(c))
					{	
						linepos--;
						save=false;
						ctoken=ID;
						state=DONE;
					}
					break;
			case DONE:	
			default:
					printf("SCANNER BUG : STATE =%d",state);
					state=DONE;
					ctoken=ERROR;
					break;
		}
		if((save)&&(tokenstr_index<=MAXTOKENLEN))
			tokenstr[tokenstr_index++]=c;
		if(state==DONE)
			tokenstr[tokenstr_index]='\o';
		if(ctoken==ID)
			ctoken=rlookup(tokenstr);
	}
	return ctoken;
}
static struct
{
	char *str;
	tokentype tok;
}rword[MAXRES]={{"begin",BEGIN},{"end",END},{"if",IF},{"then",THEN},{"else",ELSE},{"repeat",REPEAT},{"until",UNTIL},{"read",READ},{"write",WRITE}};
tokentype rlookup(char *s)
{
	int i;
	for(i=0;i<=MAXRES;i++)
	{	
		if(!strcmp(s,rword[i].str))
			return rword[i].tok;
	}
	return ID;
}
	