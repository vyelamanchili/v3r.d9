#include<stdio.h>
#include<ctype.h>
char prod[10][30],L[10][10],T[10][20],p[20][20];
int n,amb=0;
main()
{
 int i,j,k,flag=1;
 clrscr();
 printf("\nEnter the number of productions:");
 scanf("%d",&n);
 for(i=0;i<n;i++)
 {
  printf("\nEnter the production %d:",i+1);
  scanf("%s",prod[i]);
 }
 for(i=0;i<n;i++)
  for(j=0;prod[i][j]!='\0';j++)
  {
    if(isupper(prod[i][j])&&isupper(prod[i][j+1]))
    flag=0;
  }
 if(flag==0)
 {
  printf("not operator grammer");
  exit(0);
 }
 for(i=0;i<n;i++)
  preleading(prod[i][0]);
 for(i=0;i<n;i++)
  leading(prod[i][0],prod[i][0],prod[i][0]);
 for(i=0;i<n;i++)
  pretrailing(prod[i][0]);
 for(i=0;i<n;i++)
  trailing(prod[i][0],prod[i][0],prod[i][0]);
 for(i=0,k=1;i<n;i++)
 {
  for(j=3;prod[i][j]!='\0';j++)
  {
   if(prod[i][j]!='/')
   {
    if(prod[i][j]<'A'||prod[i][j]>'Z')
    {
     p[0][k]=prod[i][j];
     p[k][0]=prod[i][j];
     k++;
    }
   }
  }
 }
 p[0][k]='$';
 p[k][0]='$';
 p[0][0]=' ';
 for(i=0;i<n;i++)
  prectable(i);
 for(i=1;i<k;i++)
 {
  p[i][k]='>';
  p[k][i]='<';
 }
 p[k][k]='  ';
 clrscr();
 printf("operator precendece table for given grammer is \n\n");
  for(i=0;p[i-1][0]!='$';i++)
   {
    for(j=0;p[0][j-1]!='$';j++)
     printf("%c  ",p[i][j]);
     printf("\n\n");
   }
/* if(amb==1)
 printf("ambiguous grammer");*/
 getch();
}
leading(char x,char temp1,char temp2)                    /*function to calculate first of nonterminal*/
{
 int i,j,k,l;
 for(i=0;prod[i][0]!=x;i++);
 for(j=3;prod[i][j-1]!='\0';j++)
 {
  if(prod[i][j-1]=='/'||j==3)
  {
   if(isupper(prod[i][j]))
   {
    if(prod[i][j]!=temp1&&prod[i][j]!=temp2)
    {
     leading(prod[i][j],prod[i][0],temp2);
     for(l=0;prod[l][0]!=prod[i][j];l++);
     for(k=0;L[l][k]!='\0';k++)
     insert(L[l][k],i);
    }
   }
  }
 }
}
preleading(char x)                    /*function to calculate first of nonterminal*/
{
 int i,j,flag=0;
 for(i=0;prod[i][0]!=x;i++);
 for(j=3;prod[i][j-1]!='\0';j++)
 {
  if(prod[i][j-1]=='/'||j==3||flag==1)
  {
   if(prod[i][j]<'A'||prod[i][j]>'Z')
   {
    insert(prod[i][j],i);
    flag=0;
   }
   else
    if(isupper(prod[i][j])&&flag==0)
     if(prod[i][j+1]!='/')
      flag=1;
  }
 }
}
trailing(char x,char temp1,char temp2)                    /*function to calculate first of nonterminal*/
{
 int i,j,k,l,m;
 for(i=0;prod[i][0]!=x;i++);
 for(k=3;prod[i][k]!='\0';k++);
 for(j=k-1;prod[i][j]!='>';j--)
 {
  if(prod[i][j+1]=='/'||j==k-1)
  {
   if(isupper(prod[i][j]))
   {
    if(prod[i][j]!=temp1&&prod[i][j]!=temp2)
    {
     trailing(prod[i][j],prod[i][0],temp2);
     for(l=0;prod[l][0]!=prod[i][j];l++);
     for(m=0;T[l][m]!='\0';m++)
     insertt(T[l][m],i);
    }
   }
  }
 }
}
pretrailing(char x)                    /*function to calculate first of nonterminal*/
{
 int i,j,k,flag=0;
 for(i=0;prod[i][0]!=x;i++);
 for(k=3;prod[i][k]!='\0';k++);
 for(j=k-1;prod[i][j]!='>';j--)
 {
  if(prod[i][j+1]=='/'||j==k-1||flag==1)
  {
   if(prod[i][j]<'A'||prod[i][j]>'Z')
   {
    insertt(prod[i][j],i);
    flag=0;
   }
   else
    if(isupper(prod[i][j])&&flag==0)
     if(prod[i][j-1]!='/')
      flag=1;
  }
 }
}
insertt(char x,int i)
{
 int j;                           /*function to insert terminal in first set*/
 for(j=0;T[i][j]!='\0';j++)
  if(T[i][j]==x)
   return;
 T[i][j]=x;
}
insert(char x,int i)
{
 int j;                           /*function to insert terminal in first set*/
 for(j=0;L[i][j]!='\0';j++)
  if(L[i][j]==x)
   return;
 L[i][j]=x;
}
prectable(int i)
{
 int j,k,l,flag=0;
 for(j=3;prod[i][j]!='\0';j++)
 {
  if(prod[i][j-1]=='/'||j==3||flag==1)
  {
   if(prod[i][j+1]!='/'||j==3||flag==1)
   {
    if(prod[i][j+1]!='/'&& prod[i][j+2]!='/')
 /*give equal precedence to terminals seperated by a nonterminal*/
    if((prod[i][j]<'A'||prod[i][j]>'Z')&&isupper(prod[i][j+1])
				     &&(prod[i][j+2]<'A'||prod[i][j+2]>'Z'))
   {
     putpreced(prod[i][j],prod[i][j+2],'=');
     flag=1;
   }
   if(prod[i][j+1]!='/')
   {
   /*give equalprecedence to terminals*/
  if((prod[i][j]<'A'||prod[i][j]>'Z')&&(prod[i][j+1]<'A'||prod[i][j+1]>'Z'))
    putpreced(prod[i][j],prod[i][j+1],'=');

  /*production of form A->aB then give less prec to 'a' than lead(B)*/
  if((prod[i][j]<'A'||prod[i][j]>'Z')&&isupper(prod[i][j+1]))
  {
   for(l=0;prod[l][0]!=prod[i][j+1];l++);
    for(k=0;L[l][k]!='\0';k++)
     putpreced(prod[i][j],L[l][k],'<');
  }
  /*production of form A->Ba then give greater prec to trail(B) than 'a'*/
  if(isupper(prod[i][j])&&(prod[i][j+1]<'A'||prod[i][j+1]>'Z'))
  {
   for(l=0;prod[l][0]!=prod[i][j];l++);
   for(k=0;T[l][k]!='\0';k++)
   putpreced(T[l][k],prod[i][j+1],'>');
  }
  flag=1;
  }
 }
}
}
}
putpreced(char x,char y,char z)
{
 int i,j;
 for(i=0;p[i][0]!=x;i++);
 for(j=0;p[0][j]!=y;j++);
/* if(p[i][j]=='\0')*/
 p[i][j]=z;
/* else
 amb=1;*/
}

