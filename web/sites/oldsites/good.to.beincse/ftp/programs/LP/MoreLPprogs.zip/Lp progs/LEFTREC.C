#include<stdio.h>
#include<ctype.h>
char prod[10][20],alpha[10][10][10],beta[10][10][10];
int n,top=5;
char extranonter[6]={'U','V','W','X','Y','Z'};
main()
{
 int i,j,flag=0;
 clrscr();
 printf("\nEnter the number of productions:");
 scanf("%d",&n);
 for(i=0;i<n;i++)
 {
  printf("\nEnter the number of production %d:",i+1);
  scanf("%s",prod[i]);
 }
 for(i=0;i<n;i++)
 {
  flag=leftrec(i);
  if(flag)
   i++;
 }
 printf("\nThe productions after eliminating Left Recursion are");
 for(i=0;i<n;i++)
  printf("\n%s",prod[i]);
 getch();
}
int leftrec(int i)
{
 int j,k=0,l,m,c=0,flag=0;
 for(j=3;prod[i][j]!='\0';j++)
 {
  if(prod[i][j-1]=='/'||j==3)
  {
   if(prod[i][0]==prod[i][j])
   {
    for(l=j+1,m=0;prod[i][l]!='/'&&prod[i][l]!='\0';l++,m++)
     alpha[i][k][m]=prod[i][l];
    if(alpha[i][k][m]=='\0')
     alpha[i][k][m]='@';
    k++;
    flag=1;
   }
   else
   {
    for(l=j,m=0;prod[i][l]!='/'&&prod[i][l]!='\0';l++,m++)
     beta[i][c][m]=prod[i][l];
    c++;
   }
  }
 }
 if((beta[i][0][0]!='\0'||alpha[i][0][0]!='\0')&&flag==1)
 {
  for(j=n;j>i;j--)
   strcpy(prod[j+1],prod[j]);
  strcpy(prod[j+1],"");
  n++;
  if(beta[i][0][0]=='\0')
  { prod[i][3]=extranonter[top];
   prod[i][4]='\0';
  }
  for(c=0,k=3;beta[i][c][0]!='\0';c++,k++)
  {
   for(j=0;beta[i][c][j]!='\0';j++)
   {
    prod[i][k]=beta[i][c][j];
    k++;
   }
   prod[i][k]=extranonter[top];
   k++;
   if(beta[i][c+1][0]!='\0')
    prod[i][k]='/';
   else
    prod[i][k]='\0';
  }
  i++;
  prod[i][0]=extranonter[top];
  prod[i][1]='-';
  prod[i][2]='>';
  for(c=0,k=3;alpha[i-1][c][0]!='\0';c++,k++)
  {
   for(j=0;alpha[i-1][c][j]!='\0';j++)
   {
    if(alpha[i-1][c][j]!='@')
    {
     prod[i][k]=alpha[i-1][c][j];
     k++;
    }
   }
   prod[i][k]=extranonter[top];
   k++;
   prod[i][k]='/';
   if(alpha[i-1][c+1][0]=='\0')
    prod[i][k+1]='@';
   prod[i][k+2]='\0';
  }
 top--;
 return 1;
 }
 return 0;
}