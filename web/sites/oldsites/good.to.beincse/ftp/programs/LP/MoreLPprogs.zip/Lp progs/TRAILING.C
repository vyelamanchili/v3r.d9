#include<stdio.h>
#include<ctype.h>
char prod[10][20],T[10][10];
int n;
main()
{
 int i,j,flag=1,l;
 clrscr();
 printf("\nEnter the number of productions:");
 scanf("%d",&n);
 for(i=0;i<n;i++)
 {
  printf("\nEnter the production %d:",i+1);
  scanf("%s",prod[i]);
 }
 for(i=0;i<n;i++)
  for(j=0;prod[i][j]!='\0';j++)
  {
    if(isupper(prod[i][j])&&isupper(prod[i][j+1]))
    flag=0;
  }
  if(flag==0)
  {
   printf("not operator grammer");
   exit(0);
  }
 for(i=0;i<n;i++)
 {
  for(j=3;prod[i][j]!='\0';j++)
  {
   if(isupper(prod[i][j]))
   {
    for(l=0;prod[l][0]!=prod[i][j];l++);
     if(l>n)
     {
      printf("some nonterminals are not expanded");
      exit(0);
     }
    }
   }
  }
 for(i=0;i<n;i++)
  pretrailing(prod[i][0]);
 for(i=0;i<n;i++)
  trailing(prod[i][0],prod[i][0],prod[i][0]);
 for(i=0;i<n;i++)
 {
  printf("\nTRAILING[%c]={",prod[i][0]);
  for(j=0;T[i][j]!='\0';j++)
   printf(" %c ",T[i][j]);
  printf("}");
 }
 getch();
}
trailing(char x,char temp1,char temp2)                    /*function to calculate first of nonterminal*/
{
 int i,j,k,l,m;
 for(i=0;prod[i][0]!=x;i++);
 for(k=3;prod[i][k]!='\0';k++);
 for(j=k-1;prod[i][j]!='>';j--)
 {
  if(prod[i][j+1]=='/'||j==k-1)
  {
   if(isupper(prod[i][j]))
   {
    if(prod[i][j]!=temp1&&prod[i][j]!=temp2)
    {
     trailing(prod[i][j],prod[i][0],temp2);
     for(l=0;prod[l][0]!=prod[i][j];l++);
     for(m=0;T[l][m]!='\0';m++)
     insert(T[l][m],i);
    }
   }
  }
 }
}
pretrailing(char x)                    /*function to calculate first of nonterminal*/
{
 int i,j,k,flag=0;
 for(i=0;prod[i][0]!=x;i++);
 for(k=3;prod[i][k]!='\0';k++);
 for(j=k-1;prod[i][j]!='>';j--)
 {
  if(prod[i][j+1]=='/'||j==k-1||flag==1)
  {
   if(prod[i][j]<'A'||prod[i][j]>'Z')
   {
    insert(prod[i][j],i);
    flag=0;
   }
   else
    if(isupper(prod[i][j])&&flag==0)
     if(prod[i][j-1]!='/')
      flag=1;
  }
 }
}
insert(char x,int i)
{
 int j;                           /*function to insert terminal in first set*/
 for(j=0;T[i][j]!='\0';j++)
  if(T[i][j]==x)
   return;
 T[i][j]=x;
}