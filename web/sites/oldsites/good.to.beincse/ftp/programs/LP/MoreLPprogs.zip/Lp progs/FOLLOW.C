/*program to find follow set*/
#include<stdio.h>
#include<ctype.h>
char prod[10][20],F[10][10],FL[10][10];
int n;
main()
{
 int i,j;
 clrscr();
 printf("\nEnter the number of productions:");
 scanf("%d",&n);
 for(i=0;i<n;i++)
 {
  printf("\nEnter the production %d:",i+1);
  scanf("%s",prod[i]);
 }
 for(i=0;i<n;i++)
  first(prod[i][0]);
 for(i=0;i<n;i++)
  prefollow(prod[i][0]);
 for(i=0;i<n;i++)
  follow(prod[i][0]);
 for(i=0;i<n;i++)                    /* to print the follow set */
 {
  printf("\nFOLLOW[%c]={",prod[i][0]);
  for(j=0;FL[i][j]!='\0';j++)
   printf(" %c ",FL[i][j]);
  printf("}");
 }
 getch();
}
prefollow(char x)                  /*function to insert all corresponding teminals in follow set*/
{
 int i,j,k,l,m;
 for(i=0;prod[i][0]!=x;i++);
 if(i==0)                          /* implementing rule1 */
  insertfl('$',i);
 for(j=3;prod[i][j]!='\0';j++)
 {
  if(prod[i][j+1]!='/')
  {
   if(isupper(prod[i][j]))         /* implementing rule2 */
   {
    if(isupper(prod[i][j+1]))
    {
     for(l=0;prod[l][0]!=prod[i][j+1];l++);
     for(k=0;prod[k][0]!=prod[i][j];k++);
     for(m=0;F[l][m]!='\0';m++)
      if(F[l][m]!='@')
       insertfl(F[l][m],k);
    }
    else
    {
     for(k=0;prod[k][0]!=prod[i][j];k++);
      insertfl(prod[i][j+1],k);
    }
   }
  }
 }
}
follow(char x)              /*function to include one follow set to another*/
{
 int i,j,k,l,m;
 for(i=0;prod[i][0]!=x;i++);
 for(j=3;prod[i][j]!='\0';j++)
 {
   if(prod[i][j+1]=='/'||prod[i][j+1]=='\0')
  {
   if(isupper(prod[i][j]))              /* to implement rule3(a) */
   {
    for(l=0;prod[l][0]!=prod[i][j];l++);
    for(m=0;FL[i][m]!='\0';m++)
     insertfl(FL[i][m],l);
   }
  }
  if(prod[i][j+2]=='/'||prod[i][j+2]=='\0') /* to implement rule3(b) */
  {
   if(isupper(prod[i][j])&&isupper(prod[i][j+1])&&isepsilon(prod[i][j+1]))
   {
    for(l=0;prod[l][0]!=prod[i][j];l++);
    for(m=0;FL[i][m]!='\0';m++)
     insertfl(FL[i][m],l);
   }
  }
 }
}
first(char x)                    /*function to calculate first of nonterminal*/
{
 int i,j,k,l,flag=0;
 for(i=0;prod[i][0]!=x;i++);
 for(j=3;prod[i][j]!='\0';j++)
 {
  if(prod[i][j-1]=='/'||j==3||flag==1)
  {
   flag=0;
   if(prod[i][j]=='/'||prod[i][j]=='\0')
      insert('@',i);
   else
   {
    if(prod[i][j]<'A'||prod[i][j]>'Z')
     insert(prod[i][j],i);
    else
    {
     if(isepsilon(prod[i][j]))
     {
      first(prod[i][j]);
      for(l=0;prod[l][0]!=prod[i][j];l++);
      for(k=0;F[l][k]!='\0';k++)
      if(F[l][k]!='@')
      insert(F[l][k],i);
      flag=1;
     }
     else
     {
      first(prod[i][j]);
      for(l=0;prod[l][0]!=prod[i][j];l++);
      for(k=0;F[l][k]!='\0';k++)
      if(F[l][k]!='@')
      insert(F[l][k],i);
     }
    }
   }
  }
 }
}
int isepsilon(char x)
{                                    /*function to check whether the nonteminal*/
 int i,j;                            /*derives epsilon or not*/
 for(i=0;prod[i][0]!=x;i++);
 for(j=3;prod[i][j]!='\0';j++)
 {
  if(prod[i][j-1]=='/'||j==3)
  {
   if(prod[i][j]=='@')
    return 1;
   else
   {
    if(isupper(prod[i][j]))
     if(isepsilon(prod[i][j]))
      return 1;
   }
  }
 }
 return 0;
}
insert(char x,int i)
{
 int j;                           /*function to insert terminal in first set*/
 for(j=0;F[i][j]!='\0';j++)
  if(F[i][j]==x)
   return;
 F[i][j]=x;
}
insertfl(char x,int i)
{
 int j;                           /*function to insert terminal in follow set*/
 for(j=0;FL[i][j]!='\0';j++)
  if(FL[i][j]==x)
   return;
 FL[i][j]=x;
}