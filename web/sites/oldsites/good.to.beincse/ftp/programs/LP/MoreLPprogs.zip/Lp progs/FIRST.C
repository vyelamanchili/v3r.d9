#include<stdio.h>
#include<ctype.h>
char prod[10][20],F[10][10];
int n;
main()
{
 int i,j;
 clrscr();
 printf("\nEnter the number of productions:");
 scanf("%d",&n);
 for(i=0;i<n;i++)
 {
  printf("\nEnter the production %d:",i+1);
  scanf("%s",prod[i]);
 }
 for(i=0;i<n;i++)
  first(prod[i][0]);
 for(i=0;i<n;i++)
 {
  printf("\nFIRST[%c]={",prod[i][0]);
  for(j=0;F[i][j]!='\0';j++)
   printf(" %c ",F[i][j]);
  printf("}");
 }
 getch();
}
first(char x)                    /*function to calculate first of nonterminal*/
{
 int i,j,k,l,flag=0;
 for(i=0;prod[i][0]!=x;i++);
 for(j=3;prod[i][j-1]!='\0';j++)
 {
  if(prod[i][j-1]=='/'||j==3||flag==1)
  {
   flag=0;
   if(prod[i][j]=='/'||prod[i][j]=='\0')
      insert('@',i);
   else
   {
    if(prod[i][j]<'A'||prod[i][j]>'Z')
     insert(prod[i][j],i);
    else
    {
     if(isepsilon(prod[i][j]))
     {
      first(prod[i][j]);
      for(l=0;prod[l][0]!=prod[i][j];l++);
      for(k=0;F[l][k]!='\0';k++)
      if(F[l][k]!='@')
      insert(F[l][k],i);
      flag=1;
     }
     else
     {
      first(prod[i][j]);
      for(l=0;prod[l][0]!=prod[i][j];l++);
      for(k=0;F[l][k]!='\0';k++)
      if(F[l][k]!='@')
      insert(F[l][k],i);
     }
    }
   }
  }
 }
}
int isepsilon(char x)
{                                    /*function to check whether the nonteminal*/
 int i,j;                            /*derives epsilon or not*/
 for(i=0;prod[i][0]!=x;i++);
 for(j=3;prod[i][j]!='\0';j++)
 {
  if(prod[i][j-1]=='/'||j==3)
  {
   if(prod[i][j]=='@')
    return 1;
   else
   {
    if(isupper(prod[i][j]))
     if(isepsilon(prod[i][j]))
      return 1;
   }
  }
 }
 return 0;
}
insert(char x,int i)
{
 int j;                           /*function to insert terminal in first set*/
 for(j=0;F[i][j]!='\0';j++)
  if(F[i][j]==x)
   return;
 F[i][j]=x;
}