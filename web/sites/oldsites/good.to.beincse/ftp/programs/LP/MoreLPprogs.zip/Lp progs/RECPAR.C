#include<stdio.h>
int i=0;
char a[20];
int E();    /*E*/
int G();    /*E1*/
int T();    /*T*/
int H();    /*T1*/
int F();    /*F*/
void main()
{
 clrscr();
 printf("\nEnter the string:");
 gets(a);
 if(E())
 {
  if(a[i]=='\0')
   printf("\nThe string is  accepted");
  else
   printf("\nThe string is not accepted");
 }
 else
  printf("\n the string is not accepted");
 getch();
}
E()
{
 if(T())
 {
  if(G())
   return 1;
  else
  return 0;
 }
 else
 return 0;
}
G()
{
 if(a[i]=='+')
 {
  i++;
  if(T())
  {
   if(G())
    return 1;
   else
    return 0;
  }
 else
  return 0;
 }
 else
  return 1;
}
T()
{
 if(F())
 {
  if(H())
   return 1;
 else
  return 0;
 }
 else
  return 0;
}
H()
{
 if(a[i]=='*')
 {
  i++;
  if(F())
 {
  if(H())
    return 1;
  else
   return  0;
 }
 else
 return 0;
}
 else
  return 1;
}
F()
{
 if(a[i]=='a')
 {
  i++;
  return 1;
 }
 else
 {
 if(a[i]=='(')
  {
   i++;
  if(E())
  {
   if(a[i]==')')
   {
    i++;
    return 1;
   }
  else
   return 0;
 }
 else
  return 0;
 }
else
return 0;
}
}
