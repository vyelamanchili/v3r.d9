#include<stdio.h>
#include<ctype.h>
char prod[10][20],L[10][10];
int n;
main()
{
 int i,j,flag=1,l;
 clrscr();
 printf("\nEnter the number of productions:");
 scanf("%d",&n);
 for(i=0;i<n;i++)
 {
  printf("\nEnter the production %d:",i+1);
  scanf("%s",prod[i]);
 }
 for(i=0;i<n;i++)
  for(j=0;prod[i][j]!='\0';j++)
  {
    if(isupper(prod[i][j])&&isupper(prod[i][j+1]))
    flag=0;
  }
 if(flag==0)
 {
  printf("not operator grammer");
  exit(0);
 }
 for(i=0;i<n;i++)
 {
  for(j=3;prod[i][j]!='\0';j++)
  {
   if(isupper(prod[i][j]))
   {
    for(l=0;prod[l][0]!=prod[i][j];l++);
    if(l>n)
    {
      printf("some nonterminals are not expanded");
      exit(0);
    }
   }
  }
 }
 for(i=0;i<n;i++)
  preleading(prod[i][0]);
 for(i=0;i<n;i++)
  leading(prod[i][0],prod[i][0],prod[i][0]);
 for(i=0;i<n;i++)
 {
  printf("\nLEADING[%c]={",prod[i][0]);
  for(j=0;L[i][j]!='\0';j++)
   printf(" %c ",L[i][j]);
  printf("}");
 }
 getch();
}
leading(char x,char temp1,char temp2)
{
 int i,j,k,l;
 for(i=0;prod[i][0]!=x;i++);
 for(j=3;prod[i][j-1]!='\0';j++)
 {
  if(prod[i][j-1]=='/'||j==3)
  {
   if(isupper(prod[i][j]))
   {
    if(prod[i][j]!=temp1&&prod[i][j]!=temp2)
    {
     leading(prod[i][j],prod[i][0],temp2);
     for(l=0;prod[l][0]!=prod[i][j];l++);
     for(k=0;L[l][k]!='\0';k++)
     insert(L[l][k],i);
    }
   }
  }
 }
}
preleading(char x)                    /*function to calculate first of nonterminal*/
{
 int i,j,flag=0;
 for(i=0;prod[i][0]!=x;i++);
 for(j=3;prod[i][j-1]!='\0';j++)
 {
  if(prod[i][j-1]=='/'||j==3||flag==1)
  {
   if(prod[i][j]<'A'||prod[i][j]>'Z')
   {
    insert(prod[i][j],i);
    flag=0;
   }
   else
    if(isupper(prod[i][j])&&flag==0)
     if(prod[i][j+1]!='/')
      flag=1;
  }
 }
}
insert(char x,int i)
{
 int j;                           /*function to insert terminal in first set*/
 for(j=0;L[i][j]!='\0';j++)
  if(L[i][j]==x)
   return;
 L[i][j]=x;
}