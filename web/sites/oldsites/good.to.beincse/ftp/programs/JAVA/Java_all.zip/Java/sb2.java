//Syllabus Programs #2 :: Reading Radius and Printing Dia,Circumference and area of Circle using Applets

import java.applet.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;

/*<applet code="sb2.class" width=700 height=500></applet>*/

public class sb2 extends Applet implements ActionListener
{
	TextField t;
	public void init()
	{
		t=new TextField("Enter Radius");
		add(t);
		t.addActionListener(this);
	}
	public void paint(Graphics g)
	{
		int r=Integer.parseInt(t.getText());
		g.drawString("Radius entered is "+r,55,125);
		g.drawString("Thus the Diameter is "+(2*r),155,225);
		g.drawString(" and Area of Circle is "+(Math.PI*r*r),255,325);
		g.drawString(" and Circumference is "+(Math.PI*2*r),355,425);
	}
	public void actionPerformed(ActionEvent e)
	{
		repaint();
	}
}