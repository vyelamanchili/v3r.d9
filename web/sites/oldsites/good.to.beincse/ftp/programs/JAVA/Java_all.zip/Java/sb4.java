// Sylabaus Book program # 4:: Find two largest Values of the 10 no.s entered.

import java.lang.*;
import java.io.*;

class sb4
{
	static int[] x=new int[10];
	public static void main(String arg[]) throws IOException
	{		
		DataInputStream ip=new DataInputStream(System.in);

		System.out.println("Enter 10 Random Non-Repeated No.s:");
		for(int i=0;i<10;i++)
			x[i]=Integer.parseInt(ip.readLine());
	
		sort();
		System.out.println("The Greatest two no's are "+x[8]+" and "+x[9]);
	}
	static void sort()
	{		
		for(int i=0;i<10;i++)
		for(int j=i+1;j<10;j++)
		{
			if(x[i]>x[j])
			{
				int temp=x[i];
				x[i]=x[j];
				x[j]=temp;
			}
		}
	}		
}

