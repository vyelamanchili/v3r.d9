//prog2
import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
import java.lang.*;
//<applet code=prog2.class height=500 width=700></applet>
public class prog2 extends Applet implements ActionListener
{
	TextField tf;
	Label l=new Label("Enter the Radius as floating point variable:");
	public void init()
	{
		tf=new TextField();
		add(l);
		add(tf);
		tf.addActionListener(this);
	}
	public void paint(Graphics g)
	{
		g.drawString("Radius    = "+tf.getText(),400,210);
		g.drawString("Diameter  = "+(2*Float.parseFloat(tf.getText())),400,230);
		g.drawString("Area      = "+(area()),400,250);
		g.drawString("Perimeter = "+(perimeter()),400,270);
	}
	float area()
	{
		float r=Float.parseFloat(tf.getText());
		return((float)(r*r*(Math.PI)));
	}
	float perimeter()
	{
		float r=Float.parseFloat(tf.getText());
		return((float)(2*r*(Math.PI)));
	}
	public void actionPerformed(ActionEvent e)
	{
		repaint();
	}
}