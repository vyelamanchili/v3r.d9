// Exercise 10.8 Solution: Cube.java
// Definition of class Cube.

public class Cube extends ThreeDimensionalShape {

   // constructor
   public Cube( int x, int y, double side )
   {
      super( x, y, side, side, side );
   }

   // overridden methods
   public String getName()
   {
      return "Cube";
   }

   public double area()
   {
      return 6 * super.getDimension1() * super.getDimension1();
   }

   public double volume()
   {
      return super.getDimension1() * super.getDimension1() * super.getDimension1();
   }

   public String toString()
   {
      return "(" + super.getX() + ", " + super.getY() + ") " + "side: " + 
         super.getDimension1();
   }

   // set method
   public void setSide( double side )
   {
      super.setDimension1( side );
   }

   // get method
   public double getSide()
   {
      return super.getDimension1();
   }

}  // end class Cube

