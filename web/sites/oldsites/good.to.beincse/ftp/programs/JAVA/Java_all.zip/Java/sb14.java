//Syllabus Program::14 ::Creating own Color Chooser
import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.*;
import java.util.*;
/*<applet code=sb14.class width=1000 height=750></applet>*/
public class sb14 extends Applet implements ChangeListener
{
	Label l[]=new Label[3];
	JSlider sl[]=new JSlider[3];
	int a=0,b=0,c=0;
	public void init()
	{
		l[0]=new Label("Red");l[1]=new Label("Green");l[2]=new Label("Blue");
		Color clr=new Color(a,b,c);
		for(int i=0;i<3;i++)
       	{
			add(l[i]);
		 	sl[i]=new JSlider(SwingConstants.HORIZONTAL,0,255,0);
			sl[i].addChangeListener(this);
			add(sl[i]);
		}
    }
    public void update(Graphics g)
    {paint(g);}

   	public void paint(Graphics g)
   	{
		g.setColor(new Color(a,b,c));
		g.fillRect(400,100,100,100);
    }
	public void stateChanged(ChangeEvent e)
	{
		JSlider x=(JSlider)e.getSource();
		if(!x.getValueIsAdjusting())
		{
			if(x==sl[0])
			{
				a=(int)x.getValue();
			}
			if(x==sl[1])
			{
				b=(int)x.getValue();
			}
			if(x==sl[2])
			{
				c=(int)x.getValue();
			}
		}repaint();
	}
}