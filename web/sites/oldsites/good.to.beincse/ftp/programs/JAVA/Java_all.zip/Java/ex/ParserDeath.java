public class ParserDeath {
  public static void main(String[] args) {
    int x = 0;
    try {
      x += 2 + Parser.string2Integer("3");
      x += 4 + Parser.string2Integer("a");
    } catch (Exception e) {
      //System.out.println("Error: " + e.getMessage() + " ocurred at ");
      //e.printStackTrace();
      System.out.println("x = " + x);
    }
  }
}
