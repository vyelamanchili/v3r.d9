import java.awt.*;
import java.applet.*;
/*<applet code = draw.class width=500 height=500></applet>*/
public class draw extends Applet
{
	public void paint(Graphics g)
	{	
		g.drawString("Hello Reetu at 50,30",50,30);
		g.drawString("Hello Reetu at 30,50",30,50);
	}
}