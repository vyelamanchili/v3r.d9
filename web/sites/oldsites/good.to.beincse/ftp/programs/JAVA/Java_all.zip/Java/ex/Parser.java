public class Parser {

  public static int string2Integer(String s) throws Exception {
    int value = 0;  // Integer value of string
  
    for (int i = 0; i < s.length(); i++)
      if (Character.isDigit(s.charAt(i)))  // Is the character a digit?
        value = (value * 10) + Character.digit(s.charAt(i), 10);
      else
        throw new Exception("Bad Number");
  
    return value;
  }

}
