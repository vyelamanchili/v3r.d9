// Syllabus Program, #8:: Comission Basis

import java.applet.*;
import java.awt.*;
import java.lang.*;
import java.awt.event.*;

/*<applet code ="rectngle.class" width=700 height=500></applet>*/

public class rectngle extends Applet implements ActionListener
{
	int length,width;TextField t[]= new TextField[2];
	public void init()
	{
		Label l[]=new Label[2];
		l[0]=new Label("Length:");
		l[1]=new Label("Width:");
		length=1;width=1;
		for(int i=0;i<2;i++)
		{
		t[i]=new TextField(20);
		add(l[i]);
		add(t[i]);
		t[i].addActionListener(this);
		}
	}
	public void paint(Graphics g)
	{
		//Rectangle r=new Rectangle();
		get();
		g.drawString("Length = "+length,100,100);
		g.drawString("Width = "+width,100,150);
		g.drawString("Perimeter is = "+(perimeter()),100,200);
		g.drawString("Area = "+(area()),100,250);
		//g.drawString("Length = "+length,100,300);
	}
	public String perimeter()
	{
		return(String.valueOf(2*(length+width)));
	}
	public String area()
	{
		return(String.valueOf(length*width));
	}
	public void actionPerformed(ActionEvent e)
	{repaint();}
	public void get()
	{
		length=Integer.parseInt(t[0].getText());
		width=Integer.parseInt(t[1].getText());

	}
}
