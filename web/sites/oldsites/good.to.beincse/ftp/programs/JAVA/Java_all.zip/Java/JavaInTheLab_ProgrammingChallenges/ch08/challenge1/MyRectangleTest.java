// Exercise 8.7 Solution: MyRectangleTest.java
// Program tests class MyRectangle.

// Java core packages
import java.awt.*;
import java.awt.event.*;

// Java extension packages
import javax.swing.*;

public class MyRectangleTest extends JApplet
   implements ActionListener {

   private JLabel prompt1, prompt2;
   private JTextField inputField1, inputField2;
   private JLabel outputLabel;
   private JTextArea outputArea;
   private MyRectangle rectangle;

   // set up GUI components and instantiate new MyRectangle
   public void init()
   {
      prompt1 = new JLabel( "Length:" );
      prompt2 = new JLabel( "Width:" );
      inputField1 = new JTextField( 10 );
      inputField2 = new JTextField( 10 );
      inputField2.addActionListener( this );

      outputLabel = new JLabel( "Test Output" );
      outputArea = new JTextArea( 4, 10 );
      outputArea.setEditable( false );

      // add components to GUI
      Container container = getContentPane();
      container.setLayout( new FlowLayout() );
      container.add( prompt1 );
      container.add( inputField1 );
      container.add( prompt2 );
      container.add( inputField2 );
      container.add( outputLabel );
      container.add( outputArea );

      // create a new Rectangle with no initial values
      rectangle = new MyRectangle();
   }

   // create rectangle with user input
   public void actionPerformed( ActionEvent actionEvent )
   {
      double double1, double2;

      double1 = Double.parseDouble( inputField1.getText() );
      double2 = Double.parseDouble( inputField2.getText() );

      rectangle.setLength( double1 );
      rectangle.setWidth( double2 );

      // see the results of the test
      outputArea.setText( rectangle.toString() );
   }

} // end class RectangleTest