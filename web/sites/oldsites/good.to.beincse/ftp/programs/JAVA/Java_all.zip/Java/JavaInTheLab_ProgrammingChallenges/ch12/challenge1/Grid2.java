// Exercise 11.16 Solution: Grid2.java
// Program draws 10x10 grid using draw().

// Java core packages
import java.awt.*;
import java.awt.geom.*;

// Java extension packages
import javax.swing.*;

public class Grid2 extends JFrame {

   // constructor sets window's title bar string and dimensions
   public Grid2()
   {
      super( "Drawing Characters" );

      setSize( 500, 500 );
      show();
   }

   // draw grid
   public void paint( Graphics g )
   {
      Graphics2D g2d = ( Graphics2D ) g;

      for ( int x = 30; x <= 300; x += 30 )
         for ( int y = 30; y <= 300; y += 30 )
            g2d.draw( new Rectangle2D.Double( x, y, 30, 30 ) );
   }

   // execute application
   public static void main( String args[] )
   {
      Grid2 application = new Grid2();

      application.setDefaultCloseOperation(
         JFrame.EXIT_ON_CLOSE );
   }

}  // end class Grid2