import java.awt.*;
import javax.swing.*;

public class ImageFrame extends JFrame
{
	public ImageFrame()
	{
		setTitle("Auction Bid");
		setSize(300, 200);

		ImagePanel bp = new ImagePanel();
		Container contentPane = getContentPane();
		contentPane.add(bp);
	}
	public static void main(String[] args)
	{
		ImageFrame hi = new ImageFrame();
		hi.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		hi.show();
	}
}
