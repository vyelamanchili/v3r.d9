// Exercise 9.5 solution: Square.java
// Definition of class Square.

public class Square extends Point {
   private double sideLength;   // Square's side length

   // no-argument constructor
   public Square()
   {
      // implicit call to Point constructor occurs here
   }
   
   // constructor
   public Square( int xValue, int yValue, double sidelength )
   {
      // instantiate point object
      super( 0, 0 );
      setSideLength( sidelength );
   }

   // set sideLength
   public void setSideLength( double sidelength )
   {
      sideLength = ( sidelength < 0.0 ? 0.0 : sidelength );
   } 

   // return sideLength
   public double getSideLength()
   {
      return sideLength;
   } 

   // calculate and return circumference
   public double getCircumference()
   {
      return 4 * getSideLength();
   } 

   // calculate and return area
   public double getArea()
   {
      return getSideLength() * getSideLength();
   } 

   // return String representation of Square object
   public String toString()
   {
      return "Up-left point = " + super.toString() + "; Side = " + 
         getSideLength();
   } 

} // end class square

/**************************************************************************
 * (C) Copyright 1992-2003 by Deitel & Associates, Inc. and               *
 * Prentice Hall. All Rights Reserved.                                    *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
