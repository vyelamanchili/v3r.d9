//Syllabus Program #3::Reading 4 parametrs of a DrawOval Method and Draw

import java.awt.*;
import java.applet.*;
import java.awt.event.*;

/*<applet code=sb3.class width=700 height=500></applet>*/

public class sb3 extends Applet implements ActionListener
{
	TextField t[]=new TextField[4];
	public void init()
	{
		for(int i=0;i<4;i++)
		{
			t[i]=new TextField("Enter Parameter "+(i+1));
			add(t[i]);		
			t[i].addActionListener(this);
		}
	}
	public void paint(Graphics g)
	{
		int x[]=new int[4];
		for(int i=0;i<4;i++)
			x[i]=Integer.parseInt(t[i].getText());
		
		g.drawOval(x[0],x[1],x[2],x[3]);
	}
	public void actionPerformed(ActionEvent e)
	{
		repaint();
	}
}