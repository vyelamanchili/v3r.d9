// Exercise 5.8 Solution: Factorial.java
// Program calculates factorials.

// Java extension packages
import javax.swing.*;

public class Factorial {

   // main method begins execution of Java program
   public static void main( String args[] )
   {
      JTextArea outputArea = new JTextArea( 5, 10 );
      String outputString = "X\tX!\n";

      for ( int number = 1; number <= 5; number++ ) {
         int factorial = 1;

         for ( int smaller = 1; smaller <= number; smaller++ )
            factorial *= smaller;

         outputString += "\n" + number + "\t" + factorial;
      }

      outputArea.setText( outputString );
      JOptionPane.showMessageDialog( null, outputArea,
         "Factorial", JOptionPane.INFORMATION_MESSAGE );

      System.exit( 0 );
   }

} // end class Factorial
