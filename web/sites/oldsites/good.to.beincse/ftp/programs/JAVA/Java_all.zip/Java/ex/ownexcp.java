import java.lang.*;

class Account
{
	private int ID;
	private double balance;
	Account(int ID,double balance)
	{
		this.ID=ID;this.balance=balance;
	}
	public int accountID()
	{return ID;}
	public void setBalance(double balance)
	{this.balance=balance;}
	public double accountBalance()
	{
		return balance;}
	public void  deposit(double amount) throws NegativeAmountException
	{
		if(amount<0) throw new NegativeAmountException(this,amount,"Deposit");
		balance=balance+amount;
	}
	public void withdraw(double amount)throws NegativeAmountException,InsufficientFundException
	{
		if(amount<0)
		throw new NegativAmountException(this,amount,"Withdraw");
		if(balance<amount)
		throw new InsufficientFundException(this,amount);
		balance-=amount;
	}
}

class NegativAmountException extends Exception
{
	private Account account;
	private double amount;
	private String transactionType;
	public NegativAmountException(Account account,double amount,String transa)
	{
		super("-Ve amount");
		this.account=account;
		this.amount=amount;
		transactionType=transa;
	}
}
class InsufficientFundException extends Exception
{
	private Account account;
	private double amount;
	public InsufficientFundException()
	{}
	public String toString()
	{
		return "Account Balance is "+account.accountBalance();
	}
}
public class ownexcp
{
	public static void main(String a[])
	{
		Account[] account=new Account[10];
		for(int i=0;i<10;i++)
			account[i]=new Account(i,1000);
		try{
			account[0].deposit(-10);
		}catch(NegativeAmountException e)
		{System.out.println(e);}
		try{
				account[0].withdraw(-10);
		}catch(InsuffecientFundException e)
		{System.out.println(e);}
		catch(NegativeAmountException e)
		{System.out.println(e);}
		for(int j=0;j<10;j++)
		{
			boolean enoughFund=true;
			try{
					account[j].deposit(-10);
				}catch(InsuffecientFundException e)
				{
					enoughFund=false;
					System.out.println(e);
				}
				catch(NegativeAmountException e)
		{System.out.println(e);}
	}
}
}

