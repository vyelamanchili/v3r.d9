// Exercise 10.8 Solution: ShapeTest.java
// Program tests the Shape hierarchy.
import javax.swing.*;

public class ShapeTest {
   private Shape shapeArray[];

   // create shapes
   public ShapeTest() {
      shapeArray = new Shape[ 4 ];

      shapeArray[ 0 ] = new Circle( 22, 88, 1.25 );
      shapeArray[ 1 ] = new Square( 71, 96, 2.5 );
      shapeArray[ 2 ] = new Sphere( 8, 89, 3.75 );
      shapeArray[ 3 ] = new Cube( 79, 61, 5.0 );
   }

   // display shape info
   public void displayShapeInfo()
   {
      String output = "";

      // call method toString on all shapes
      for ( int i = 0; i < shapeArray.length; i++ ) {
         output += shapeArray[ i ].getName() + ": " + shapeArray[ i ] + "\n";

         if ( shapeArray[ i ] instanceof TwoDimensionalShape ) {
            TwoDimensionalShape current = 
               ( TwoDimensionalShape ) shapeArray[ i ];

            output += current.getName() + "'s area is " + current.area() + "\n";
         }

         if ( shapeArray[ i ] instanceof ThreeDimensionalShape ) {
            ThreeDimensionalShape current = 
               ( ThreeDimensionalShape ) shapeArray[ i ];

            output += current.getName() + "'s area is " + current.area() + 
               "\n" + current.getName() + "'s volume is " + current.volume() + 
               "\n";
         }

         output += "\n";
      }

      JOptionPane.showMessageDialog( null, output );
   }

   // create ShapeTest object and display info
   public static void main( String args[] )
   {
      ShapeTest driver = new ShapeTest();
      driver.displayShapeInfo();
      System.exit( 0 );
   }

}  // end class ShapeTest
