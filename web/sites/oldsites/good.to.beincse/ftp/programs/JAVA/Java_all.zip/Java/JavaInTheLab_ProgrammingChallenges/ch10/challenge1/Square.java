// Exercise 10.8 Solution: Square.java
// Definition of class Square.

public class Square extends TwoDimensionalShape {

   // constructor
   public Square( int x, int y, double side )
   {
      super( x, y, side, side );
   }

   // overridden methods
   public String getName()
   {
      return "Square";
   }

   public String toString()
   {
      return "(" + super.getX() + ", " + super.getY() + ") " + "side: " + 
         super.getDimension1();
   }

   public double area()
   {
      return super.getDimension1() * super.getDimension1();
   }

   // set method
   public void setSide( double side )
   {
      super.setDimension1( side );
   }

   // get method
   public double getSide()
   {
      return super.getDimension1();
   }

} // end class Square

