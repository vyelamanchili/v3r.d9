//Testing user Interface Objects
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.lang.*;
//<applet code=ui.class width=500 height=500></applet>
public class ui extends Applet implements ActionListener
{
	Checkbox cb;Menu m;MenuItem mi;TextArea ta;MenuBar mb;public Button b;String s;Graphics g;
	public void init()
	{
		mb=new MenuBar();
		ta=new TextArea();
		m=new Menu("File");
		mi=new MenuItem("Close");
		cb=new Checkbox("Hello");
		b=new Button("Add");
		m.add(mi);
		b.addActionListener(this);
		add(b);
		mb.add(m);
		//add(mb);
		add(ta);
		add(cb);
	}
	public void paint(Graphics g)
	{
		g.drawString(s,250,250);
	}
	public void actionPerformed(ActionEvent e)
	{
		s=ta.getText();
		g=getGraphics();
		g.drawString(s,250,250);repaint();
	}

}
