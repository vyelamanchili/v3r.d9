// Exercise 9.5 solution: CubeTest.java
// Testing class Cube.
import java.text.DecimalFormat;
import javax.swing.JOptionPane;

public class CubeTest {

   public static void main( String[] args ) 
   {
      // create Cube object
      Cube cube = new Cube( 10, 20, 45.5 );

      // get Cube's initial x-y coordinates, side and depth
      String output = "X coordinate is " + cube.getX() +
         "\nY coordinate is " + cube.getY() + "\nRadius is " + 
         cube.getSideLength() + "\nDepth is " + cube.getDepth();

      cube.setX( 35 );          // set new x-coordinate
      cube.setY( 15 );          // set new y-coordinate
      cube.setSideLength( 25.25 );   // set new side length
      cube.setDepth( 25.25 );   // set new depth

      // get String representation of new cube value
      output += "\n\nThe new location, side and depth of cube are\n" + 
         cube.toString();

      // format floating-point values with 2 digits of precision
      DecimalFormat twoDigits = new DecimalFormat( "0.00" );

      // get Cube's area
      output += "\nArea is " + twoDigits.format( cube.getArea() );

      // get Cube's volume
      output += "\nVolume is " + twoDigits.format( cube.getVolume() );

      JOptionPane.showMessageDialog( null, output ); // display output

      System.exit( 0 );

   } // end main

} // end class CubeTest

/**************************************************************************
 * (C) Copyright 1992-2003 by Deitel & Associates, Inc. and               *
 * Prentice Hall. All Rights Reserved.                                    *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
