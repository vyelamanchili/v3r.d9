// Exercise 13.17 Solution: Painter.java
// Paint program with different shapes, colors, fills
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Painter extends JFrame {
   private int topX, topY, height, width, bottomY, bottomX, shape;
   private boolean clear, filled;
   private Color drawingColor;

   private JPanel panel1, panel2, panel3, panel4;
   private JRadioButton ovalBox, rectBox, lineBox;
   private ButtonGroup shapeGroup;
   private JCheckBox fillBox;
   private JList colorList;
   private JButton clearButton;

   private String colorNames[] = { "Black", "Green", "Blue",
      "Red", "Cyan", "Yellow" };
   private Color colors[] = { Color.black, Color.green,
      Color.blue, Color.red, Color.cyan, Color.yellow };
   private final int OVAL = 1, LINE = 2, RECT = 3;

   // constructor
   public Painter()
   {
      super( "Painter" );

      // set default to black oval
      setShape( OVAL );
      setDrawingColor( Color.black );

      // set this to make the window white
      clear = true;

      addMouseListener( new MouseHandler() );

      // sets up GUI
      createToolWindow();

      Container container = getContentPane();
      container.add( panel4, BorderLayout.SOUTH );

      setSize( 500, 500 );
      setVisible( true );
   }

   // accessor methods
   public int getTopX()
   {
      return topX;
   }

   public int getTopY()
   {
      return topY;
   }

   public int getWidth()
   {
      return width;
   }

   public int getHeight()
   {
      return height;
   }

   public int getBottomX()
   {
      return bottomX;
   }

   public int getBottomY()
   {
      return bottomY;
   }

   public int getShape()
   {
      return shape;
   }

   public Color getDrawingColor()
   {
      return drawingColor;
   }

   public boolean getFill()
   {
      return filled;
   }

   // mutator methods
   public void setTopX( int x )
   {
      topX = x;
   }

   public void setTopY( int y )
   {
      topY = y;
   }

   public void setBottomX( int x )
   {
      bottomX = x;
   }

   public void setBottomY( int y )
   {
      bottomY = y;
   }

   public void setWidth( int wide )
   {
      width = wide;
   }

   public void setHeight( int high )
   {
      height = high;
   }

   public void setShape( int preference )
   {
      if ( preference >= OVAL && preference <= RECT )
         shape = preference;
   }

   public void setDrawingColor( Color color )
   {
      for ( int i = 0; i < colors.length; i++ )

         if ( color == colors[ i ] ) {
            drawingColor = color;
            return;
         }
   }

   public void setClear()
   {
      clear = true;
   }

   public void setFill()
   {
      filled = true;
   }

   public void clearFill()
   {
      filled = false;
   }

   // draw new shape with specified color, fill, position
   public void paint( Graphics g )
   {
      g.setColor( drawingColor );
      width = Math.abs( topX - bottomX );
      height = Math.abs( topY - bottomY );

      if ( shape != LINE ) {
         topX = Math.min( topX, bottomX );
         topY = Math.min( topY, bottomY );

         // draw filled shapes
         if ( filled && shape != LINE )
            switch ( shape ) {

               case OVAL:
                  g.fillOval( topX, topY,  width, height );
                  break;

               case RECT:
                  g.fillRect( topX, topY, width, height );
                  break;
            }

         // draw unfilled shapes
         else
            switch ( shape ) {

               case OVAL:
                  g.drawOval( topX, topY,  width, height );
                  break;

               case RECT:
                  g.drawRect( topX, topY, width, height );
                  break;
            }
      }

      // draw line
      else if ( shape == LINE )
         g.drawLine( topX, topY, bottomX, bottomY );

      // erase entire canvase
      if ( clear == true ) {
         g.setColor( Color.white );
         g.fillRect( 0, 0, 500, 500 );
         clear = false;
      }

      // ensure that the control panel is still visible
      panel4.repaint();

   }  // end method paint

   // set up the buttons and controls
   public void createToolWindow()
   {
      // set up to handle clear button
      clearButton = new JButton( "Clear" );
      clearButton.addActionListener( new ClearButtonHandler() );

      // set up to choose shapes
      ovalBox = new JRadioButton( "Oval", true );
      lineBox = new JRadioButton( "Line", false );
      rectBox = new JRadioButton( "Rectangle", false );
      RadioButtonHandler handler = new RadioButtonHandler();
      ovalBox.addItemListener( handler );
      lineBox.addItemListener( handler );
      rectBox.addItemListener( handler );

      // group the shapes
      shapeGroup = new ButtonGroup();
      shapeGroup.add( ovalBox );
      shapeGroup.add( lineBox );
      shapeGroup.add( rectBox );

      // set up to choose if filled
      fillBox  = new JCheckBox( "filled" );
      FillBoxHandler fillHandler = new FillBoxHandler();
      fillBox.addItemListener( fillHandler );

      // set up to choose color
      colorList = new JList( colorNames );
      colorList.setVisibleRowCount( 5 );
      colorList.setSelectionMode( ListSelectionModel.SINGLE_SELECTION );
      colorList.setSelectedValue( "Black", true );

      // set up event handler
      colorList.addListSelectionListener(

         new ListSelectionListener() {

            public void valueChanged( ListSelectionEvent e )
            {
               drawingColor = colors[ colorList.getSelectedIndex() ];
            }
         }
      );

      // create panels and layout
      panel1 = new JPanel();
      panel2 = new JPanel();
      panel3 = new JPanel();
      panel4 = new JPanel();

      panel1.setLayout( new GridLayout( 3, 1 ) );
      panel2.setLayout( new GridLayout( 2, 1 ) );
      panel4.setLayout( new GridLayout( 1, 3 ) );

      panel1.add( ovalBox );
      panel1.add( lineBox );
      panel1.add( rectBox );
      panel2.add( fillBox );
      panel2.add( clearButton );
      panel3.add( new JScrollPane( colorList ) );

      panel4.add( panel1 );
      panel4.add( panel2 );
      panel4.add( panel3 );
   }

   // class determines location and size of shapes
   private class MouseHandler extends MouseAdapter {

      // initial coordinates
      public void mousePressed( MouseEvent e )
      {
         setTopX( e.getX() );
         setTopY( e.getY() );
      }

      // end coordinates
      public void mouseReleased( MouseEvent e )
      {
         setBottomX( e.getX() );
         setBottomY( e.getY() );
         repaint();
      }

   }  // end inner class MouseHandler

   // class responds to desire to erase canvas
   private class ClearButtonHandler implements ActionListener {

      public void actionPerformed( ActionEvent e )
      {
         setClear();
         repaint();
      }

   }  // end inner class ClearButtonHandler

   // class determines which shape to draw
   private class RadioButtonHandler implements ItemListener {

      public void itemStateChanged( ItemEvent e )
      {
         if ( e.getSource() == ovalBox )
            setShape( OVAL );

         else if ( e.getSource() == lineBox )
            setShape( LINE );

         else if (  e.getSource() == rectBox )
            setShape( RECT );
      }

   }  // end inner class RadioButtonHandler

   // class determines whether shape is to be filled
   private class FillBoxHandler implements ItemListener {

      public void itemStateChanged( ItemEvent e )
      {
         if ( e.getSource() == fillBox )
            if ( e.getStateChange() == ItemEvent.SELECTED )
               setFill();

            else
               clearFill();
      }

   }  // end inner class FillBoxHandler

   public static void main( String args[] )
   {
      Painter app = new Painter();
      app.setDefaultCloseOperation( EXIT_ON_CLOSE );
   }

}  // end class Painter