// Syllabus Program #7:: Gross Income
import java.lang.*;
import java.io.*;
class income
{
	static float incm[]=new float[10];
	income()
	{	for(int i=0;i<10;i++)
			incm[i]=200;
	}
	public static void main(String A[]) throws IOException
	{	int[] ct=new int[10];
		int v;
		for(int i=0;i<10;i++) ct[i]=0;
		income comission=new income();
		System.out.println("Enter the no. of products sold:");
		DataInputStream in=new DataInputStream(System.in);
		for(int i=0;i<10;i++)
		{	v=0;
			incm[i]+=(float)(0.09*(Integer.parseInt(in.readLine())));
			if(incm[i]>1000) ct[9]++;
			for(int j=0;j<9;j++)
			{	if(incm[i]>=(200+v) && incm[i]<=(299+v))
					ct[j]++;
				v+=100;
			}
		}
		System.out.println("The no. of Workers salaries between  are :");
		v=0;
		for(int j=0;j<9;j++,v+=100)
		if((200+v)<1000) 
			System.out.println("\t"+(200+v)+" - "+(299+v)+"\t"+ct[j]);
		System.out.println("\tabove 1000\t"+ct[9]);
	}
}
/*Output:
Enter the no. of products sold:
1000
2000
3000
5000
10000
1000
30000
5000
40000
4000
The no. of Workers salaries between  are :
	200 - 299		2
	300 - 399		1
	400 - 499		1
	500 - 599		1
	600 - 699		2
	700 - 799		0
	800 - 899		0
	900 - 999		0
	above 1000	3*/
