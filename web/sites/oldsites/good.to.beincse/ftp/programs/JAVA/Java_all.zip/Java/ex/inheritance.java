import java.lang.*;

class x extends y
{
	x()
	{
		System.out.println("Im in X class");
	}	
	public static void main(String a[])
	{
		x o=new x();
		System.out.println("Im in main fn X class");
		o.m();
	}
}
class y
{
	y()
	{
		System.out.println("Im in Y class");
	}
	public void m()
	{
		y p=new x();
	}
}
	