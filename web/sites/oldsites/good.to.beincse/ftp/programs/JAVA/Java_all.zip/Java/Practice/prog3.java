//prog3
import java.applet.*;
import java.awt.event.*;
import java.awt.*;
//<applet code=prog3.class height=500 width=1000></applet>
public class prog3 extends Applet implements ActionListener
{
	TextField[] tf=new TextField[4];
	Label[] l=new Label[4];
	public void init()
	{
		for(int i=0;i<4;i++)
		{
			tf[i]=new TextField(6);
			if(i==0) l[0]=new Label("X:");
			if(i==1) l[1]=new Label("Y:");
			if(i==2) l[2]=new Label("Major Axis:");
			if(i==3) l[3]=new Label("Minor Axis:");
			add(l[i]);
			add(tf[i]);
			tf[i].addActionListener(this);
		}
	}
	public void paint(Graphics g)
	{
		g.drawOval(Integer.parseInt(tf[0].getText()),
				   Integer.parseInt(tf[1].getText()),
			       Integer.parseInt(tf[2].getText()),
				   Integer.parseInt(tf[3].getText()));
  	}
  	public void actionPerformed(ActionEvent e)
  	{
		repaint();
	}
}




