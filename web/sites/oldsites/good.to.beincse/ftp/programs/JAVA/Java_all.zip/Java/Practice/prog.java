import java.io.*;
class prog
{
	public static void main(String args[]) throws IOException
	{
		int opt;
		DataInputStream in=new DataInputStream(System.in);
		do
		{
			System.out.println("Enter 2 Numbers to find whether 1st is multiple of second:");
			int a=Integer.parseInt(in.readLine());
			int b=Integer.parseInt(in.readLine());
			if(a%b==0)
				System.out.println(a+" is multiple of "+b);
			else
				System.out.println(a+" is not multiple of "+b);
			System.out.println("Continue with another set:(1/0)?");
			opt=Integer.parseInt(in.readLine());
		}while(opt==1);
	}
}