//prog4
class prog4
{
	public static void main(String args[])
	{
		int n[]=new int[10];
		for(int i=0;i<10;i++)
			n[i]=(int)(Math.random()*400);
		greatest2(n);
	}
	static void greatest2(int no[])
	{
		int temp;
		for(int j=0;j<10;j++)
		System.out.println("unSorted "+no[j]);
		for(int i=0;i<10;i++)
		for(int j=i+1;j<10;j++)
		{
			if(no[i]>no[j])
			{
				temp=no[i];
				no[i]=no[j];
				no[j]=temp;
			}
		}
		for(int j=0;j<10;j++)
		System.out.println("Sorted "+no[j]);

		System.out.println("The Greatest among thee Randomly generate 10 no.s are "+no[8]+" "+no[9]);
	}
}



