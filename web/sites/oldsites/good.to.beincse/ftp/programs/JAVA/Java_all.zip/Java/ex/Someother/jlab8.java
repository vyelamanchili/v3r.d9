import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
/* <applet code = "jlab8.class" width = 250 height =200>
   </applet>
   */

   public class jlab8 extends JApplet
    {
     public void init()
      {
       JTabbedPane tp = new JTabbedPane();
       tp.addTab("Cities",new cities());
       tp.addTab("Languages",new languages());
       tp.addTab("Flavors",new flavors());
       getContentPane().add(tp);

       }
      class cities extends JPanel
       {
        public cities()
          {
            JButton b1 = new JButton("Vijayawada");
            add(b1);
            JButton b2 = new JButton("Hyderabad");
            add(b2);
            JButton b3 = new JButton("Secundarabad");
            add(b3);
            JButton b4 = new JButton("Guntur");
            add(b4);
            }
         }
      class languages extends JPanel
       {
         public languages()
          {
            JCheckBox c1 = new JCheckBox("C");
            add(c1);
            JCheckBox c2 = new JCheckBox("C++");
            add(c2);
            JCheckBox c3 = new JCheckBox("Java");
            add(c3);
            JCheckBox c4 = new JCheckBox("Pascal");
            add(c4);

            }
         }
      class flavors extends JPanel
       {
        public flavors()
          {
            JComboBox cb = new JComboBox();
            cb.addItem("Choclate");
            cb.addItem("Strawberry");
            cb.addItem("Mango");
            cb.addItem("Vanilla");
            add(cb);

            }
         }
       
      }




         

