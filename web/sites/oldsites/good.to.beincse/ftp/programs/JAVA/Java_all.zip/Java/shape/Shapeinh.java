package shape;
import java.applet.*;
import java.awt.*;
public class Shapeinh extends Applet
{
	public int x[]=new int[2];
	public TextField t;
	public Shape()
	{
		for(int i=0;i<2;i++)
			x[i]=100;
	}
}