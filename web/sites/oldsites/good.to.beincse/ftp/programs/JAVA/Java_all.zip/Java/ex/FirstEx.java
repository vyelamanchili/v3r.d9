// Everything is a class
// Class and file have the same name
public class FirstEx {

  /* The static main() method kicks things off
     Command-line parameters are passed as an array of Strings
     A String is an object, not a primitive type
     An array is also an object. */
  public static void main(String args[]) {
                         
    // Arrays have the publically accessible member variable length
    // System.out.println() is method to print line to console
    if (args.length != 1) {
      System.out.println("Parameter(s): radius (inches)");
      System.exit(1);
    }

    // Constants are declared as final
    final double PI = 3.14;

    double radius = Double.parseDouble(args[0]); // Converts String to double

    // + is String concatenation
    // All Java objects and primitive types have a String representation
    // There is no power operator
    String out = "The area of the circle is " + PI * radius * radius;
    System.out.println(out + " inches");
  }
}
