//Syllabus Program :: 16 :: Testing of Thread Priorities
import java.lang.Thread.*;
import java.lang.*;
import java.util.*;
class paraThread extends Thread
{
	int count=0;
	private char c;
	public paraThread(char p)
	{
		c=p;
	}
	public void run()
	{
		for(int i=0;i<100;i++)
		{
			count++;
			System.out.print(" "+c+" ");
		}
	}
}
class sb16copied
{
	public static void main(String a[])
	{
		paraThread t1=new paraThread('V');
		paraThread t2=new paraThread('3');
		paraThread t3=new paraThread('r');
		try
		{
			t1.setPriority(1);
			t2.setPriority(5);
			t3.setPriority(10);
		}catch(Exception e){}
		try
		{
			t1.join();
			t2.join();
			t3.join();}
		catch(Exception e){}
		t1.start();
		t2.start();
		t3.start();
		System.out.println("\nThread 1 Executed "+t1.count+" times.");
		System.out.println("\nThread 2 Executed "+t2.count+" times.");
		System.out.println("\nThread 3 Executed "+t3.count+" times.");
	}
}