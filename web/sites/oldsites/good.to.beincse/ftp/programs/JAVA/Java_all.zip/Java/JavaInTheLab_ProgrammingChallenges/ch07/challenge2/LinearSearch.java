// Exercise 7.31 Solution: LinearSearch.java
// Program recursively performs linear search of an array.

// Java core packages
import java.awt.*;
import java.awt.event.*;

// Java extension packages
import javax.swing.*;

public class LinearSearch extends JApplet
   implements ActionListener {

   int array[];
   JLabel enterLabel, resultLabel;
   JTextField enterField, resultField;

   // set up GUI components and initialize array
   public void init()
   {
      enterLabel = new JLabel( "Enter integer search key" );
      enterField = new JTextField( 10 );
      enterField.addActionListener( this );
      resultLabel = new JLabel( "Result" );
      resultField = new JTextField( 25 );
      resultField.setEditable( false );

      Container container = getContentPane();
      container.setLayout( new FlowLayout() );
      container.add( enterLabel );
      container.add( enterField );
      container.add( resultLabel );
      container.add( resultField );

      array = new int[ 100 ];

     // initialize array with even numbers 0 to 198
      for ( int counter = 0; counter < array.length; counter++ )
         array[ counter ] = 2 * counter;

   }  // end method init

   // obtain user input and call method linearSearch
   public void actionPerformed( ActionEvent actionEvent )
   {
      String stringKey = actionEvent.getActionCommand();
      int intKey = Integer.parseInt( stringKey );
      int element = linearSearch( array, array.length, intKey );

      if ( element != -1 )
         resultField.setText(
            "Found value in element " + element);

      else
         resultField.setText( "Value not found" );

   }  // end method actionPerformed

   // recursively search for key within parameter array
   public int linearSearch( int array2[], int size, int intKey )
   { 
      if ( size == 0 )
         return -1;

      else if ( array2[ --size ] == intKey )
         return size;

      else
         return linearSearch( array2, size, intKey );

   }  // end method linearSearch

}  // end class LinearSearch
