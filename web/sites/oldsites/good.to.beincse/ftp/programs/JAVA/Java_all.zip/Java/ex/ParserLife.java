public class ParserLife {
  public static void main(String[] args) {
    int x = Parser.string2Integer("3");  // Will not throw exception
  }
}
