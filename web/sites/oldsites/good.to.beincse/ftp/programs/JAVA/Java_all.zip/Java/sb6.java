// Syllabus Program #6:: Applet to find whether enetred no. is Prime No. and print prime  no. from 1 to 10,000

import java.applet.*;
import java.awt.*;
import java.lang.*;
import java.awt.event.*;

/*<applet code ="sb6.class" width=700 height=500></applet>*/

public class sb6 extends Applet implements ActionListener
{
	TextField t;
	public void init()
	{
		t=new TextField("Enter a No.");
		add(t);
		t.addActionListener(this);
	}
	public void paint(Graphics g)
	{
		int c=0,v=0;
		int x=Integer.parseInt(t.getText());
		for(int i=1;i<=x;i++)
			if(x%i==0)
				c++;
		if(c==2) t.setText(x+" is Prime");
		else t.setText(x+" is not Prime");
		for(int i=1;i<10000;i++)
		{
			c=0;
			for(int j=1;j<=i;j++)
				if(i%j==0)
					c++;
			if(c==2)
			{
				g.drawString(" "+i,10+v,10+v);	
				v+=10;
			}
		}
	}
	public void actionPerformed(ActionEvent e)
	{
		repaint();
	}
}