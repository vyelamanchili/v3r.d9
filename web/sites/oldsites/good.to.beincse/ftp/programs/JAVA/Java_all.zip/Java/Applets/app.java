//import java.lang.*;
import java.applet.*;
import java.awt.*;
import java.awt.event.*;
/*<applet code="app.class" width=500 height=500></applet>*/


class a extends Applet
{}
class b extends MouseAdapter
{}
class app extends b implements MouseListener,MouseMotionListener
{
	String s="Started";int x=0,y=0,i,j;
	app()
	{
		addMouseListener(this);
		addMouseMotionListener(this);
	}
	public void paint(Graphics g)
	{
		g.drawString(s,x,y);
		g.drawString("Length and breadth is "+(x-i)+"  "+(y-i),x+25,y+25);
		g.drawRect(i,j,x-i,y-j);
	}
/*	public void mouseClicked(MouseEvent e)
	{
		s="Mouse Clicked";
		repaint();
	}*/
	public void mousePressed(MouseEvent e)
	{
		s="Mouse Pressed";
		i=e.getX();
		j=e.getY();
		repaint();
	}
	public void mouseReleased(MouseEvent e)
	{
		s="Mouse Released";
		x=e.getX();
		y=e.getY();
		repaint();
	}
/*	public void mouseMoved(MouseEvent e)
	{
		s="Mouse Moving without Drawing";
		repaint();
	}*/
	public void mouseDragged(MouseEvent e)
	{
		s="Mouse Dragged";
		x=e.getX();
		y=e.getY();
		repaint();
	}
/*	public void mouseExited(MouseEvent e)
	{
		s="Mouse Exited the Window";
		repaint();
	}
	public void mouseEntered(MouseEvent e)
	{
		s="Mouse Enetered The Window";
		repaint();
	}*/
}