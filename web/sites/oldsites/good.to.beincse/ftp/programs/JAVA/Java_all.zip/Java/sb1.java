//Syllabus Book 1st Problem:: To Read 2 int and print if 1st is multipel of 2nd

import java.lang.*;
import java.io.*;

class sb1
{
	public static void main(String args[])  throws IOException
	{
		DataInputStream ip=new DataInputStream(System.in);
		System.out.println("Enetr 2 no.s:");
		
		String a=ip.readLine();
		int rd1=Integer.parseInt(a);
		
		a=ip.readLine();
		int rd2=Integer.parseInt(a);
		
		if(rd1%rd2==0)
			System.out.println(rd1+" is a Multiple of "+rd2);
		else
			System.out.println(rd1+" is not a Multiple of "+rd2);
	}
}