// Exercise 9.5 solution: Square.java
// Definition of class Square.

public class Square {
   private double sideLength;   // Square's side length
   private Point point;   // composition

   // no-argument constructor
   public Square()
   {
      point = new Point( 0, 0 );
      setSideLength( 0 );
   }
   
   // constructor
   public Square( int xValue, int yValue, double sidelength )
   {
      // instantiate point object
      point = new Point( xValue, yValue );
      setSideLength( sidelength );
   }

   // set sideLength
   public void setSideLength( double sidelength )
   {
      sideLength = ( sidelength < 0.0 ? 0.0 : sidelength );
   } 

   // return sideLength
   public double getSideLength()
   {
      return sideLength;
   } 

   // set x
   public void setX( int x )
   {
      point.setX( x );
   }

   // return x
   public int getX()
   {
      return point.getX();
   }

   // set y
   public void setY( int y )
   {
      point.setY( y );
   }

   // return y
   public int getY()
   {
      return point.getY();
   }

   // calculate and return circumference
   public double getCircumference()
   {
      return 4 * getSideLength();
   } 

   // calculate and return area
   public double getArea()
   {
      return getSideLength() * getSideLength();
   } 

   // return String representation of Square object
   public String toString()
   {
      return "Up-left point = " + point.toString() + "; Side = " + 
         getSideLength();
   } 

} // end class Square

/**************************************************************************
 * (C) Copyright 1992-2003 by Deitel & Associates, Inc. and               *
 * Prentice Hall. All Rights Reserved.                                    *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
