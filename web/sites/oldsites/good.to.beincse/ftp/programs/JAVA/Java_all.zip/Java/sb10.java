//Syllabus Programs ::10:: Pay Roll System
import java.lang.*;
import java.awt.*;
import java.io.*;
class sb10
{
	static String name[]={"Ranjeesh","Ram Kiran","Sai","Venkat","JaySimha"};
	static int id[]={1,2,3,4,5};
	static String mob[]={"December","July","August","August","May"};
	static int sal=10000;
	public static void main(String arg[]) throws IOException
         	{
		DataInputStream in=new DataInputStream(System.in);
                                int t;
		do{
		do{
		                System.out.println("Enter the Id:");
			t=Integer.parseInt(in.readLine());
		}while(invalid(t));
	                System.out.println("\nName : "+name[t-1]);
	                System.out.println("ID         : "+id[t-1]);
		incminfo(t);
		System.out.println("View Another?(1/0)");
		}while(Integer.parseInt(in.readLine())!=0);
	}
	static boolean invalid(int n)
	{
		for(int i=0;i<5;i++)
		if(id[i]==n)
			return(false);
		return(true);
	}
	static void incminfo(int n)
	{
		float bonus=0;
		System.out.println("Basic Salary : "+sal);
		System.out.println("DA	  : "+(40*(sal/100)));
		System.out.println("Others	  : "+(25*(sal/100)));
		if(mob[n-1].equals("August"))
		{
			bonus=1000;			
			System.out.println("Bonus	  : "+bonus);
		}
		else
			System.out.println("Bonus	  : "+bonus);
		System.out.println("Total	  : "+(bonus+sal+(25*(sal/100))+(40*(sal/100))));
	}
}
/*OUTPUT:
Enter the Id:1

Name : Ranjeesh
ID         : 1
Basic Salary : 10000
DA	  : 4000
Others	  : 2500
Bonus	  : 0.0
Total	  : 16500.0
View Another?(1/0)
1
Enter the Id:3

Name : Sai
ID         : 3
Basic Salary : 10000
DA	  : 4000
Others	  : 2500
Bonus	  : 1000.0
Total	  : 17500.0
View Another?(1/0)
0*/
		
