//prog5
//import java.lang.*;
class prog5
{
	public static void main(String as[])
	{
		int count=0;
		System.out.println("Pythogorean Triples are:");
		for(int i=1;i<=500;i++)
		for(int j=1;j<=500;j++)
		for(int k=1;k<=500;k++)
		{count++;
			if(((i*i)+(j*j))==(k*k))
				System.out.println("("+i+", "+j+", "+k+")");
		}
		System.out.println(count);
	}
}
class progtest
{
	public static void main(String as[])
	{
		int count=0;
		System.out.println("Pythogorean Triples are:");
		for(int i=1;i<=500;i++)
		for(int j=1;j<=500;j++)
		//for(int k=1;k<=500;k++)
		{count++;
			if(Math.sqrt((i*i)+(j*j)) instanceof Integer)
				System.out.println("("+i+", "+j+", "+Math.sqrt((i*i)+(j*j))+")");
		}
		System.out.println(count);
	}
}