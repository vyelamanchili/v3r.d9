import java.lang.*;
import java.awt.*;
import java.applet.*;

/*<applet code ="applt.class" width=500 height=500></applet>*/

public class applt extends Applet
{
	public void paint(Graphics g)
	{
		int x[]={20,15,30,35};
		g.drawArc(300,300,100,100,0,(360*(x[0]/100)));
		for(int i=1;i<4;i++)
		{
			g.drawArc(300,300,100,100,(360*(x[i-1]/100)),(360*(x[i]/100)));
		}
	}
}
		
		
		
		