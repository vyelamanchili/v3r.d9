// Syllabus Program, #8::Class Rectangle with Set-Get Methods
import java.lang.*;
import java.io.*;
class Rectangle
{
	float length,width;
	Rectangle()
	{
		length=1;width=1;
	}
	public static void main(String a[])
	{
		Rectangle r=new Rectangle();
		while(r.set());
		System.out.println("Area and Perimeter of rectangle are "+r.area()+" and "+r.perimeter());
	}
	float perimeter()
	{
		return(2*(length+width));
	}
	float area()
	{
		return(length*width);
	}
	boolean set()
	{
		System.out.println("Enter the Length and Width of Rectangle:");
		length=get();
		width=get();
		if(length<20 || width<20)
			return(true);
		else return(false);
	}
	float get()
	{	float g=0;
		try
		{
			DataInputStream in=new DataInputStream(System.in);
			g=Float.parseFloat(in.readLine());
		}
		catch(Exception e){}
		return(g);
	}
}
/*OutPut:
Enter the Length and Width of Rectangle:
10
19
Enter the Length and Width of Rectangle:
100
200
Area and Perimeter of rectangle are 20000.0 and 600.0*/