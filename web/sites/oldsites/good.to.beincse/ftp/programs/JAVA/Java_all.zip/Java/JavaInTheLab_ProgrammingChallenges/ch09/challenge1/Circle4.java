// Exercise 9.3 solution: Circle4.java
// Definition of class Circle4.

public class Circle4 {
   private double radius;  // Circle4's radius
   private Point3 point;   // composition

   // no-argument constructor
   public Circle4()
   {
      point = new Point3( 0, 0 );
      setRadius( 0 );
   }
   
   // constructor
   public Circle4( int xValue, int yValue, double radiusValue )
   {
      // instantiate point object
      point = new Point3( xValue, yValue );
      setRadius( radiusValue );
   }

   // set radius
   public void setRadius( double radiusValue )
   {
      radius = ( radiusValue < 0.0 ? 0.0 : radiusValue );
   } 

   // return radius
   public double getRadius()
   {
      return radius;
   } 

   // set x
   public void setX( int x )
   {
      point.setX( x );
   }

   // return x
   public int getX()
   {
      return point.getX();
   }

   // set y
   public void setY( int y )
   {
      point.setY( y );
   }

   // return y
   public int getY()
   {
      return point.getY();
   }

   // calculate and return diameter
   public double getDiameter()
   {
      return 2 * getRadius();
   } 

   // calculate and return circumference
   public double getCircumference()
   {
      return Math.PI * getDiameter();
   } 

   // calculate and return area
   public double getArea()
   {
      return Math.PI * getRadius() * getRadius();
   } 

   // return String representation of Circle4 object
   public String toString()
   {
      return "Center = " + point.toString() + "; Radius = " + getRadius();
   } 

} // end class Circle4

/**************************************************************************
 * (C) Copyright 1992-2003 by Deitel & Associates, Inc. and               *
 * Prentice Hall. All Rights Reserved.                                    *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
