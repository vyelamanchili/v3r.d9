import java.lang.*;
import java.awt.*;
import javax.swing.*;
/*<applet code=swng.class height=500 width=500></applet>*/
public class swng extends JApplet
{
	
	public void init()
	{
		
		add(jop);
	}		
	public void paint(Graphics g)
	{
		JOptionPan.showMessageDialog();
	}
}