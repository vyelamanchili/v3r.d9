import java.awt.*;
import java.applet.*;
import shape.*;
import java.awt.event.*;
/*<applet code=amo.class height=500 width=500></applet>*/
public class sb92 extends Shapeinh implements ActionListener
{
	public sb92()
	{
		t=new TextField(10);
		t.addActionListener(this);
		add(t);
	}
	public void paint(Graphics g)
	{
		Shape s;
		g.drawString("1.Triangle",50,100);
		g.drawString("2.Rectangle",100,100);
		g.drawString("3.Circle",150,100);
		int o=Integer.parseInt(t.getText());
		if(o==1)
		{
			s=new Triangle();
			s.repaint();
		}
		else if(o==2)
		{
			s=new Rect();
			s.repaint();
		}
		else if(o==3)
		{
			s=new ole();
			s.repaint();
		}
	}
	public void actionPerformed(ActionEvent e)
	{
		repaint();
	}
}