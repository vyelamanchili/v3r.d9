import java.lang.*;
class practice
{
	public static void main(String a[])
	{
		StringBuffer sb=new StringBuffer(a[0]);
		System.out.println("Length= "+sb.length());
		System.out.println("Capacity= "+sb.capacity());
	}
}