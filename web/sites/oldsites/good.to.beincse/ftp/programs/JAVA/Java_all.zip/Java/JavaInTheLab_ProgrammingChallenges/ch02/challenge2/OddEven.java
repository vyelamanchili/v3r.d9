// Exercise 2.27 Solution: OddEven.java
// Program that determines if a number is odd or even.

// Java extension packages
import javax.swing.JOptionPane;

public class OddEven {

   // main method begins execution of Java application
   public static void main( String args[] )
   {
      String input;    // string entered by user
      String result;   // output display string
      int number;      // number

      // read from user as a string
      input =
         JOptionPane.showInputDialog( "Enter integer:" );

      // convert number from type String to type int
      number = Integer.parseInt( input );

      // initialize result to empty String
      result = "";

      if ( number % 2 == 0 )
         result = "Number is even.";

      if ( number % 2 != 0 )
         result = "Number is odd.";

      // Display results
      JOptionPane.showMessageDialog(
         null, result, "Calculation Results",
         	JOptionPane.INFORMATION_MESSAGE );

      System.exit( 0 );  // terminate application

   }  // end method main

}  // end class OddEven
