import java.lang.*;
import java.io.*;
class Test
{
	public static void main(String a[]) throws IOException
	{
		DataInputStream x=new DataInputStream(System.in);
		int i=x.readInt();
		System.out.println(i);
//		int y=Integer.parseInt(S);
	//	System.out.println(y);
	}

}