import java.lang.*;
import java.applet.*;
import java.awt.*;
import shape.*;

public class mn extends Shape
{
	public int x[]=new int[2];
	TextField t;Label l;
	public mn()
	{
		t=new TextField();
		l=new Label("Enter Option:");
		add(t);
		t.add(l);
	}
	public void paint(Graphics g)
	{
		Shape s;
		g.drawString("1.Triangle",50,100);
		g.drawString("2.Rectangle",100,100);
		g.drawString("3.Circle",150,100);
		int o=Integer.parseInt(t.getText());
		if(o==1)
		{
			s=new Triangle();
			repaint();
		}
		if(o==2)
		{
			s=new Rectangle();
			repaint();
		}
		if(o==3)
		{
			s=new ole();
			repaint();
		}
	}
}