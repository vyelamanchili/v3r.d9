// Exercise 9.5 solution: Cube.java
// Cube class definition.

public class Cube {
   private double depth;  // Cube's depth
   private Square square;

   // no-argument constructor
   public Cube()
   {
      square = new Square( 0, 0, 0 );
      depth = 0;
   } 

   // constructor
   public Cube( int xValue, int yValue, double sideValue )
   {
      square = new Square( xValue, yValue, sideValue );
      setDepth( sideValue );
   } 

   // set Cube's depth
   public void setDepth( double depthValue )
   {
      depth = ( depthValue < 0.0 ? 0.0 : depthValue );
   } 

   // get Cube's depth
   public double getDepth()
   {
      return depth;
   } 

   // set x
   public void setX( int x )
   {
      square.setX( x );
   }

   // return x
   public int getX()
   {
      return square.getX();
   }

   // set y
   public void setY( int y )
   {
      square.setY( y );
   }

   // return y
   public int getY()
   {
      return square.getY();
   }

   // set side length
   public void setSideLength( double lengthValue )
   {
      square.setSideLength( lengthValue );
   } 

   // return side length
   public double getSideLength()
   {
      return square.getSideLength();
   } 

   // calculate Cube area
   public double getArea()
   {
      return 6 * square.getArea();
   } 

   // calculate Cube volume
   public double getVolume()
   {
      return square.getArea() * getDepth();
   } 

   // return String representation of Cube object
   public String toString()
   {
      return square.toString() + "; Depth = " + getDepth();
   } 
	
} // end class Cube

/**************************************************************************
 * (C) Copyright 1992-2003 by Deitel & Associates, Inc. and               *
 * Prentice Hall. All Rights Reserved.                                    *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/