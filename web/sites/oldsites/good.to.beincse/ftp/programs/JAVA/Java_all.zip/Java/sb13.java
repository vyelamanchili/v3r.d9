//Syllabus Program #13:: Using MouseListener to Draw rectangle when mouse dragged

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
/*<applet code = sb13.class width=700 height=500></applet>*/
public class sb13 extends Applet implements MouseMotionListener,MouseListener
{	TextField t;String S;int i,j,x,y;
	public void init()
	{	t=new TextField(15);
		addMouseMotionListener(this);
		addMouseListener(this);
		add(t);	
	}
	public void paint(Graphics g)
	{	t.setText(S);
		if(i<x && j<y)
			g.drawRect(i,j,x-i,y-j);
		else if(i>x && j>y)
			g.drawRect(x,y,i-x,j-y);
		else if(i>x && j<y)
			g.drawRect(x,j,i-x,y-j);
		else if(i<x && j>y)
			g.drawRect(i,y,x-i,j-y);
	}
	public void mouseMoved(MouseEvent e) {}
	public void mousePressed(MouseEvent e)
	{	S="Mouse Pressed";
		i=e.getX();
		j=e.getY();
		repaint();
	}
	public void mouseReleased(MouseEvent e)
	{	S="Mouse Released";
		x=e.getX();
		y=e.getY();
		repaint();
	}
	public void mouseClicked(MouseEvent e) {}
	public void mouseEntered(MouseEvent e)	{}
	public void mouseExited(MouseEvent e) {}
	public void mouseDragged(MouseEvent e)
	{	S="Mouse Dragged";
		x=e.getX();
		y=e.getY();
		repaint();
	}
}