// Exercise 8.8 Solution: SophisticatedRectangle.java
// Definition of class SophisticatedRectangle

// Java extension packages
import javax.swing.JOptionPane;

public class SophisticatedRectangle {
   private double x1, x2, x3, x4, y1, y2, y3, y4;

   // constructor
   public SophisticatedRectangle( double x1, double y1, double x2,
      double y2, double x3, double y3, double x4, double y4 )
   {
      setCoordinates( x1, y1, x2, y2, x3, y3, x4, y4 );
   }

   // check if coordinates are valid
   public void setCoordinates( double xInput1, double yInput1,
      double xInput2, double yInput2, double xInput3,
      double yInput3, double xInput4, double yInput4 )
   {
      x1 = ( xInput1 >= 0.0 && xInput1 <= 20.0 ? xInput1 : 1 );
      x2 = ( xInput2 >= 0.0 && xInput2 <= 20.0 ? xInput2 : 1 );
      x3 = ( xInput3 >= 0.0 && xInput3 <= 20.0 ? xInput3 : 1 );
      x4 = ( xInput4 >= 0.0 && xInput4 <= 20.0 ? xInput4 : 1 );
      y1 = ( yInput1 >= 0.0 && yInput1 <= 20.0 ? yInput1 : 1 );
      y2 = ( yInput2 >= 0.0 && yInput2 <= 20.0 ? yInput2 : 1 );
      y3 = ( yInput3 >= 0.0 && yInput3 <= 20.0 ? yInput3 : 1 );
      y4 = ( yInput4 >= 0.0 && yInput4 <= 20.0 ? yInput4 : 1 );

      if ( !isRectangle() )
         JOptionPane.showMessageDialog( null,
            "This is not a rectangle.", "Information",
            JOptionPane.INFORMATION_MESSAGE );

   }

   // calculate distance between two points
   public double distance( double x1, double y1,
      double x2, double y2 )
   {
      double distance;

      // calculate vertical lines
      if ( x1 == x2 )
         distance = y1 - y2 ;

      // calculate horizontal lines
      else if ( y1 == y2 )
         distance = x1 - x2 ;

      // calculate lines that aren't horizontal or vertical
      else
         distance = Math.sqrt( ( Math.pow( x1 - x2, 2 ) +
            Math.pow( y1 - y2, 2 ) ) );

      if ( distance < 0 )
         distance *= -1;

      return distance;
   }

   // check if coordinates specify a rectangle by determining if the
   // two diagonals are of the same length.
   public boolean isRectangle()
   {
      double side1 = distance( x1, y1, x2, y2 );
      double side2 = distance( x2, y2, x3, y3 );
      double side3 = distance( x3, y3, x4, y4 );

      if ( side1 * side1 + side2 * side2 ==
         side2 * side2 + side3 * side3 )
         return true;

      else
         return false;
   }

   // check if rectangle is a square
   public boolean isSquare()
   {
      return ( getLength() == getWidth() );
   }

   // get length of rectangle
   public double getLength()
   {
      double side1 = distance( x1, y1, x2, y2 );
      double side2 = distance( x2, y2, x3, y3 );

      return ( side1 > side2 ? side1 : side2 );
   }

   // get width of rectangle
   public double getWidth()
   {
      double side1 = distance( x1, y1, x2, y2 );
      double side2 = distance( x2, y2, x3, y3 );

      return ( side1 < side2 ? side1 : side2 );
   }

   // calculate perimeter
   public double perimeter()
   {
      return 2 * getLength() + 2 * getWidth();
   }

   // calculate area
   public double area()
   {
      return getLength() * getWidth();
   }

   // convert to String
   public String toString()
   {
       return ( "Length: " + getLength() + "\n" +
          " Width: " + getWidth()  + "\n" +
          " Perimeter: " + perimeter() + "\n" +
          " Area: " + area() );
   }

}  // end class SophisticatedRectangle