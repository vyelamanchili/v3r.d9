// Exercise 8.8 Solution: SophisticatedRectangleTest.java
// Program tests class SophisticatedRectangle.

// Java core packages
import java.awt.*;
import java.awt.event.*;

// Java extension packages
import javax.swing.*;

public class SophisticatedRectangleTest extends JApplet
   implements ActionListener {

   private JLabel x1Prompt, y1Prompt, x2Prompt, y2Prompt,
      x3Prompt, y3Prompt, x4Prompt, y4Prompt;
   private JTextField directions, x1Field, y1Field, x2Field,
      y2Field, x3Field, y3Field, x4Field, y4Field;
   private JLabel outputLabel;
   private JTextArea outputArea;

   // set up GUI components and instantiate new MyRectangle
   public void init()
   {
      x1Prompt = new JLabel( "x1:" );
      y1Prompt = new JLabel( "y1:" );
      x2Prompt = new JLabel( "x2:" );
      y2Prompt = new JLabel( "y2:" );
      x3Prompt = new JLabel( "x3:" );
      y3Prompt = new JLabel( "y3:" );
      x4Prompt = new JLabel( "x4:" );
      y4Prompt = new JLabel( "y4:" );

      directions = new JTextField(
         "Enter rectangle's coordinates in clockwise order.");
      directions.setEditable( false );

      // text fields for the four points' x and y values
      x1Field = new JTextField( 10 );
      y1Field = new JTextField( 10 );
      x2Field = new JTextField( 10 );
      y2Field = new JTextField( 10 );
      x3Field = new JTextField( 10 );
      y3Field = new JTextField( 10 );
      x4Field = new JTextField( 10 );
      y4Field = new JTextField( 10 );
      y4Field.addActionListener( this );

      // output area for rectangle information
      outputLabel = new JLabel( "Test Output" );
      outputArea = new JTextArea( 4, 10 );
      outputArea.setEditable( false );

      // add components to GUI
      Container container = getContentPane();
      container.setLayout( new FlowLayout() );
      container.add( directions );
      container.add( x1Prompt );
      container.add( x1Field );
      container.add( y1Prompt );
      container.add( y1Field );
      container.add( x2Prompt );
      container.add( x2Field );
      container.add( y2Prompt );
      container.add( y2Field );
      container.add( x3Prompt );
      container.add( x3Field );
      container.add( y3Prompt );
      container.add( y3Field );
      container.add( x4Prompt );
      container.add( x4Field );
      container.add( y4Prompt );
      container.add( y4Field );
      container.add( outputLabel );
      container.add( outputArea );

   }  // end method init

   // create rectangle with user input
   public void actionPerformed( ActionEvent actionEvent )
   {
      double x1, x2, x3, x4, y1, y2, y3, y4;

      x1 = Double.parseDouble( x1Field.getText() );
      x2 = Double.parseDouble( x2Field.getText() );
      x3 = Double.parseDouble( x3Field.getText() );
      x4 = Double.parseDouble( x4Field.getText() );
      y1 = Double.parseDouble( y1Field.getText() );
      y2 = Double.parseDouble( y2Field.getText() );
      y3 = Double.parseDouble( y3Field.getText() );
      y4 = Double.parseDouble( y4Field.getText() );

      // create a new shape with the points and determine whether
      // it is actually a rectangle.
      SophisticatedRectangle rectangle =
         new SophisticatedRectangle( x1, y1, x2, y2, x3, y3, x4, y4 );

      if ( rectangle.isRectangle() )
         outputArea.setText( rectangle.toString() );

      else
         outputArea.setText( "");

   }  // end method actionPerformed

} // end class RectangleTest